package com.sncr.verizon.appiumtests.vznft.photosandvideos.real;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import org.testng.annotations.Test;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;

/**
 * VZNFT-481: Edit Photos: Add Stickers/step 4: In Multi-Select Mode
 *
 * @author leletsn
 */
public class LocalyticsPVAllEditPhotoInMultiSelectMode extends BaseTestClass {

    @Test(testName = "VZNFT-481", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.REAL})
    public void testLocalyticsPVAllEditPhotoInMultiSelectMode() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        gridView.tapItemInSelectMode(vz_strings.DataType.PHOTO);
        baseControlsHelper.openContext(vz_strings.context_editPhoto);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_editPhotos);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_tagEvent + " is not 1 in logs ",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_editPhotos) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_source + " does not exists",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_source + " = \"" + vz_strings.logs_photoMultiSelectMenu + "\"") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_target + " does not exists ",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_target + " = \"" + vz_strings.logs_editPhoto + "\"") == 1);
    }
}
