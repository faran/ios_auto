/*
 * Step 2 VZNFT-10
 * Step 4 VZNFT-26
*/
package com.sncr.verizon.appiumtests.cleanuptests.cta;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LocalyticsHomeContactsCTA extends BaseTestClass {

    @Test(testName = "VZNFT-10", groups = {"vznft", GroupNames.CTA})
    public void testLocalyticsHomeContactsCTA() throws Exception {

        homeScreenView.fromHomeClickAt(vz_strings.home_cta_contacts);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagScreen);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_contacts + " does not exist",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_contacts + " " + vz_strings.logs_CTA) == 1);
    }

}
