// STEP 4
package com.sncr.verizon.appiumtests.IV.settings.myaccount;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.controls.DeleteMyAccountPage;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class VerifyMultipleContentsNavigation extends BaseTestClass {

    private SoftAssert softAssert = new SoftAssert();

    @Test(testName = "IV-4941", groups = {"release", GroupNames.MANAGE_STORAGE})
    public void testVerifyMultipleContentsNavigation() throws Exception {

        navigateToSelectedContentAndVerify(DeleteMyAccountPage.ContentType.PHOTOS, vz_strings.navi_Photosandvideos);
        navigateToSelectedContentAndVerify(DeleteMyAccountPage.ContentType.VIDEOS, vz_strings.navi_Photosandvideos);
        navigateToSelectedContentAndVerify(DeleteMyAccountPage.ContentType.SONGS, vz_strings.home_music);
        navigateToSelectedContentAndVerify(DeleteMyAccountPage.ContentType.DOCUMENTS, vz_strings.navi_documents);
        softAssert.assertAll();
    }

    private void navigateToSelectedContentAndVerify(DeleteMyAccountPage.ContentType contentType, String pageTitle) throws Exception {
        homeScreenView.navigateTo(vz_strings.navi_settings);
        baseControlsHelper.clickOn(vz_strings.my_Account);
        myAccountPage.navigateToDeleteMyAccount();
        deleteMyAccountPage.selectContent(contentType);
        softAssert.assertTrue(baseControlsHelper.getCountByName(pageTitle) > 0, pageTitle + " not displayed");
    }
}
