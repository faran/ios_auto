//https://jira.synchronoss.net:8443/jira/browse/VZNFT-69/step-3
//Minimum two photos has to be there in ALL

package com.sncr.verizon.appiumtests.vznft.publicshare;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by kram0003 on 26/02/18.
 */
public class PhotosAndVideosAllSelectMultiplePhotosShare extends BaseTestClass {

    @Test(testName = "VZNFT-69", groups = {"vznft", GroupNames.PUBLIC_SHARE})
    public void photosAndVideosSelectMultiplePhotos() throws Exception {

        homeScreenView.fromHomeClickAt(vz_strings.navi_Photosandvideos);
        baseControlsHelper.clickOn(vz_strings.tab_all);
        String contentSize = photosAndVideosView.ContentData(2, vz_strings.DataType.PHOTO);
        gridView.tapItemsInMultiSelectModeUniversal(2, vz_strings.DataType.PHOTO);
        photosAndVideosView.clickOnShareAndCopyShare(vz_strings.context_share);
        baseControlsHelper.waitForDismiss(vz_strings.toast_creatingSocialShareLink);

        String logs = localyticsHelper.getLogs();

        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SHARE_SEND_CONTENT + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND_CONTENT) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareItemShared + "  items size is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareItemShared + "\" = 2") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareContentType + " photo is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareContentType + "\" = " + "Photos") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareContentSize + " content size is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareContentSize + "\" = \"" + contentSize + "\"") == 1);
    }
}

