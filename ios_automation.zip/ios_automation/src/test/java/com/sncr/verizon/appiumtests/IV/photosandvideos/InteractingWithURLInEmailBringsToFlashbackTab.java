package com.sncr.verizon.appiumtests.IV.photosandvideos;

import com.sncr.verizon.appiumtests.constants.EmailAndMessageUtils;
import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.managers.iOSManager;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class InteractingWithURLInEmailBringsToFlashbackTab extends BaseTestClass {
    private SoftAssert softAssert = new SoftAssert();

    @Test(testName = "IV-3224", groups = {GroupNames.FLASHBACKS,GroupNames.PUSH_NOTIFICATIONS, "release"})
    public void testInteractingWithURLInEmailBringsToFlashbackTab() throws Exception {

        iOSManager.runAppInBackground(-1);
        EmailAndMessageUtils.deleteAllMails();
        EmailAndMessageUtils.sendEmail("vz", vz_strings.Deeplinks.FLASH_BACK, EmailAndMessageUtils.username);
        nativeIosAppsView.openMailBox();
        baseControlsHelper.clickOnNameContains(vz_strings.Deeplinks.FLASH_BACK);
        baseControlsHelper.clickOn(vz_strings.Deeplinks.FLASH_BACK);
        softAssert.assertTrue(baseControlsHelper.getValue(vz_strings.view_Flashbacks) != null, "Not navigated to flashbacks pane");
        homeScreenView.navigateTo(vz_strings.navi_home);
        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.verizon_cloud) >= 1, "Unable to navigate back to cloud app");
        softAssert.assertAll();
    }
}
