//VZNFT-23 - Step 4
package com.sncr.verizon.appiumtests.vznft.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LocalyticsMusicArtistsPlaySong extends BaseTestClass {

    @Test(testName = "VZNFT-23", groups = {"vznft", GroupNames.MUSIC})
    public void testLocalyticsMusicArtistsPlaySong() throws Exception {

        precondition.clickMusicHeadFromHome();
        musicView.selectTab(vz_strings.tab_artists);
        listView.selectFirstItem10();
        baseControlsHelper.clickOn(vz_strings.tab_songs);
        listView.selectNumberOfItems(2);
        baseControlsHelper.openContext(vz_strings.context_playSelected);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_mediaType);
        localyticsHelper.print(logs, vz_strings.logs_tagScreen);

        TestCase.assertTrue(vz_strings.logs_mediaTypeSong + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\" = " + vz_strings.logs_mediaTypeSong) == 1);

        TestCase.assertTrue(vz_strings.logs_musicArtistSongs + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_musicArtistSongs) == 1);
    }
}
