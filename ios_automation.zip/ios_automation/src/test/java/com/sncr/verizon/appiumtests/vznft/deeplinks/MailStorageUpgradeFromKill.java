//VZNFT-365
package com.sncr.verizon.appiumtests.vznft.deeplinks;

import com.sncr.verizon.appiumtests.constants.EmailAndMessageUtils;
import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.managers.iOSManager;
import org.testng.annotations.Test;

public class MailStorageUpgradeFromKill extends BaseTestClass {

    @Test(testName = "VZNFT-365", groups = {GroupNames.DEEPLINKS, "vznft"})
    public void testMailStorageUpgradeFromKill() throws Exception {
        iOSManager.terminateApp(vz_strings.BundleIds.VZ_ID);
        EmailAndMessageUtils.deleteAllMails();
        EmailAndMessageUtils.sendEmail("vz", vz_strings.Deeplinks.MANAGE_STORAGE, EmailAndMessageUtils.username);
        nativeIosAppsView.openMailBox();
        baseControlsHelper.clickOnNameContains(vz_strings.Deeplinks.MANAGE_STORAGE);
        baseControlsHelper.clickOn(vz_strings.Deeplinks.MANAGE_STORAGE);
        baseControlsHelper.waitForShow(vz_strings.settings_manageStorage);
    }
}
