//https://jira.synchronoss.net:8443/jira/browse/VZNFT-172
package com.sncr.verizon.appiumtests.vznft.home;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 31/07/18.
 */
public class HashIdOfLCIDOnCustomerIDForPremiumUsers extends BaseTestClass {
    @Test(testName = "VZNFT-172", groups = {"vznft", GroupNames.HOME})
    public void testBackUpPhotosVideosYesBackGroundPhotoNo() throws Exception {
        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_customer_id);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_customer_id + " does not exist", localyticsHelper.isExisted(logs, vz_strings.logs_customer_id));
    }
}
