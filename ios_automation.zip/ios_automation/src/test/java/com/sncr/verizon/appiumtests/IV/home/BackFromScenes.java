package com.sncr.verizon.appiumtests.IV.home;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class BackFromScenes extends BaseTestClass {

    @Test(testName = "IV-2572", groups = {"release", GroupNames.HOME})
    public void testBackFromScenes() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_home);
        homeScreenView.clickOnStory(vz_strings.carousel_story);
        baseControlsHelper.tapOnBackButton();
        TestCase.assertTrue("", baseControlsHelper.getCountByName(vz_strings.view_photoStories) > 0);
        TestCase.assertTrue("", baseControlsHelper.getCountByClassName("XCUIElementTypeCollectionView") > 0);
    }

}