package com.sncr.verizon.appiumtests.IV.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class SelectingVideoForPrint extends BaseTestClass {

    @Test(testName = "IV-2468", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI})
    public void testCloudPrintUnsupportedVideo() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);

        baseControlsHelper.openContext(vz_strings.context_select);
        gridView.selectWithScroll(vz_strings.DataType.VIDEO, 2, 5);

        baseControlsHelper.clickOn(vz_strings.context_icon_printShop);
        baseControlsHelper.waitForShow(vz_strings.button_ok);

        TestCase.assertTrue("Alert box is missing title:" + vz_strings.getText_videosNotSupportedTitle,
                baseControlsHelper.getTextFromAlertBox(0).equals(vz_strings.getText_videosNotSupportedTitle));
        TestCase.assertTrue("Alert box is missing body:" + vz_strings.getText_videosNotSupportedBody,
                baseControlsHelper.getTextFromAlertBox(1).equals(vz_strings.getText_videosNotSupportedBody));

        baseControlsHelper.clickOn(vz_strings.button_ok);

        TestCase.assertTrue("Did not return to photos and videos view with items selected",
                baseControlsHelper.getCountByName(vz_strings.button_cancel) > 0);

    }
}
