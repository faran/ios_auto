package com.sncr.verizon.appiumtests.IV.photosandvideos.downloads;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class DownloadEmptyAlbum extends BaseTestClass {

    @Test(testName = "IV-857", groups = {GroupNames.DOWNLOADS, GroupNames.PHOTOS_AND_VIDEOS, "release"})
    public void testDownloadEmptyAlbum() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_albums);
        precondition.deleteAllAlbums();
        precondition.createAlbum();
        photosAndVideosView.openAlbum();
        precondition.removeContentFromAlbum();

        photosAndVideosView.selectTab(vz_strings.tab_albums);
        gridView.selectAllAlbums();
        baseControlsHelper.openContext(vz_strings.context_download);

        TestCase.assertTrue("Alert message was not dispalyed",
                baseControlsHelper.getCountByClassName(vz_strings.XCUITypes.XCUI_ALERT) > 0);

        TestCase.assertTrue("Alert contains the wrong message",
                baseControlsHelper.getTextFromAlertBox(0).equals(vz_strings.text_download_empty_album_error_msg));
    }
}
