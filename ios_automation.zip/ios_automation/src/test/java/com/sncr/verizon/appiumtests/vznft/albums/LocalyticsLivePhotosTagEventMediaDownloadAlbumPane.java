//https://jira.synchronoss.net:8443/jira/browse/VZNFT-323
package com.sncr.verizon.appiumtests.vznft.albums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.driver.BaseDriver;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 02/11/18.
 */
public class LocalyticsLivePhotosTagEventMediaDownloadAlbumPane extends BaseTestClass {

    @Test(testName = "VZNFT-323", groups = {"vznft", GroupNames.ALBUMS})
    public void testLocalyticsLivePhotosTagEventMediaDownloadAlbumPane() throws Exception {

        try {
            doWsgGetTokenCall(msisdn,password);
            deletePlaylists(PlaylistTypes.PHOTO_VIDEO);
            Thread.sleep(2000);
            photosAndVideosView.uploadLivePhotoAndAddToAlbum();
            driver().launchApp();
            homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
            photosAndVideosView.openAlbum();
            gridView.tapItemInSelectMode(vz_strings.DataType.LIVEPHOTO);
            baseControlsHelper.openContext(vz_strings.context_download);
            Thread.sleep(5000);
            baseControlsHelper.waitForShow("1 file downloaded.");
            baseControlsHelper.tapOnBackButton();
            Thread.sleep(2000);
            String logs = localyticsHelper.getLogs();
            localyticsHelper.print(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaDownload);
            TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaDownload + " is not 1 in logs", localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaDownload) == 1);
            TestCase.assertTrue("Localytics of " + vz_strings.logs_count + " is not 1 in logs", localyticsHelper.getPatternMatch(logs, vz_strings.logs_count + " = " + "1") == 1);
            TestCase.assertTrue(vz_strings.logs_mediaType + " does not exist", localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + "\"" + vz_strings.name_livePhoto + "\"") == 1);
        } finally {
            settingsView.tapOnBackButtonAndSetWhatToBackup(true, 0);
            baseControlsHelper.tapOnBackButton();
            homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
            photosAndVideosView.selectTab(vz_strings.tab_all);
            gridView.tapItemInSelectMode(vz_strings.DataType.LIVEPHOTO);
            gridView.tapContextDelete();
            baseControlsHelper.clickOn(vz_strings.button_yes);
            baseControlsHelper.waitForShow(vz_strings.toast_itemDeleted);
            deletePlaylists(PlaylistTypes.PHOTO_VIDEO);
        }
    }
}
