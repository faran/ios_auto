package com.sncr.verizon.appiumtests.vznft.deeplinks.pushnotificaitons;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class PushNotificaitonKillAppAndSend extends BaseTestClass {

    @Test(testName = "VZNFT-169", groups = {"vznft", GroupNames.PUSH_NOTIFICATIONS})
    public void testPushNotificaitonKillAppAndSend() throws Exception {

        driver().terminateApp(vz_strings.BundleIds.VZ_ID);
        
        nativeIosAppsView.openDeeplink(vz_strings.Deeplinks.HOME);

        TestCase.assertTrue("Not open on home page", baseControlsHelper.getCountByName(vz_strings.verizon_cloud) > 0);
    }
}
