package com.sncr.verizon.appiumtests.IV.photosandvideos;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.openqa.selenium.ScreenOrientation;
import org.testng.annotations.Test;

public class VideoOrientationFromHome extends BaseTestClass {

    @Test(testName = "IV-286", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS})
    public void testVideoOrientationFromHome() throws Exception {

        homeScreenView.fromHomeClickOnGridCell(vz_strings.name_videoGrid);
        photosAndVideosView.playVideo();
        baseControlsHelper.setOrientation(ScreenOrientation.LANDSCAPE);
        baseControlsHelper.setOrientation(ScreenOrientation.PORTRAIT);

        TestCase.assertTrue("Video is not open",
                baseControlsHelper.getCountByName(vz_strings.name_video) != 0);
    }
}
