/*
 * VZNFT-19 - Step 3
 * */
package com.sncr.verizon.appiumtests.cleanuptests.cta;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class LocalyticsHMMusicCTA extends BaseTestClass {

    @BeforeMethod(groups = {"vznft", GroupNames.CTA})
    public void cleanUpMusics() throws Exception {
        if (doATPAuthCall(msisdn)) {
            if (getMediaCount(ContentType.MUSIC) > 0) {
                if (deleteAllFiles(ContentType.MUSIC)) {
                    driver().launchApp();
                }
            }
        }
    }

    @Test(testName = "VZNFT-19", groups = {"vznft", GroupNames.CTA})
    public void testLocalyticsHMMusicCTA() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_music);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagScreen);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaTypeMusic + " exists",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_mediaTypeMusic + " " + vz_strings.logs_CTA) == 1);
    }
}
