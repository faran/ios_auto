package com.sncr.verizon.appiumtests.IV.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class DeleteAlbumFromStory extends BaseTestClass {

    private SoftAssert softAssert = new SoftAssert();

    @Test(groups = {"release", GroupNames.SMART_ALBUMS})
    public void testSavedSystemGeneratedStoryToAnAlbum() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_stories);
        photosAndVideosView.openStory10();
        String storyName = baseControlsHelper.getNavBarText();
        baseControlsHelper.openContext(vz_strings.context_saveAsAlbum);
        baseControlsHelper.waitForShow(vz_strings.toast_storySavesToAlbums);
        baseControlsHelper.tapOnBackButton();

        softAssert.assertTrue(baseControlsHelper.getCountByName("Photos albums folder") < 1,
                "Albums not deleted");

        photosAndVideosView.selectTab(vz_strings.tab_stories);
        photosAndVideosView.openStory10();

        softAssert.assertTrue(baseControlsHelper.getCountByName(storyName) > 0,
                "Same album dont exist");
        softAssert.assertAll();
    }
}
