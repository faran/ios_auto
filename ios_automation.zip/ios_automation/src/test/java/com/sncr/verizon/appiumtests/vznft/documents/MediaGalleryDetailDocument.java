//https://jira.synchronoss.net:8443/jira/browse/VZNFT-146 #5
package com.sncr.verizon.appiumtests.vznft.documents;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class MediaGalleryDetailDocument extends BaseTestClass {

    @Test(testName = "VZNFT-146", groups = {"vznft", GroupNames.DOCUMENTS})
    public void testMediaGalleryDetailDocument() throws Exception {


        homeScreenView.navigateTo(vz_strings.navi_documents);
        baseControlsHelper.waitForShow(vz_strings.group_documents);
        Thread.sleep(5000);
        listView.selectFirstItem10();
        Thread.sleep(10000);
        baseControlsHelper.HorizontalSwipe();
        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_galleryDetail);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_galleryDetail + " does not exist",
                localyticsHelper.isExisted(logs, vz_strings.logs_galleryDetail));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_galleryDetail + " is not 1 in logs",
                localyticsHelper.getCountOf(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_galleryDetail) == 1);

    }
}
