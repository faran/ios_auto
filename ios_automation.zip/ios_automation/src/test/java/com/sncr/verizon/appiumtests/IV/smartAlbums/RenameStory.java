//IV-152
package com.sncr.verizon.appiumtests.IV.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class RenameStory extends BaseTestClass {

    @Test(testName = "IV-152", groups = {"release", GroupNames.SMART_ALBUMS})
    public void testRenameStory() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_stories);
        gridView.tapFolderInSelectMode10("Story-0");
        baseControlsHelper.openContext(vz_strings.context_renameStory);
        baseControlsHelper.setValuetoTextFieldByName("Renamed Story", vz_strings.alertTextField);
        baseControlsHelper.clickOn(vz_strings.button_ok);
        baseControlsHelper.tapOnBackButton();

        TestCase.assertTrue("Renamed story not found", baseControlsHelper.getCountByNameContains("Renamed Story") > 0);
    }

}
