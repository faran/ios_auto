//https://jira.synchronoss.net:8443/jira/browse/VZNFT-373
package com.sncr.verizon.appiumtests.vznft.settings;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 04/07/18.
 */
public class StorageUpgradeStepConfirmUpgrade extends BaseTestClass {

    @Test(testName = "VZNFT-373", groups = {"vznft", GroupNames.SETTINGS})
    public void testStorageUpgradeStepConfirmUpgrade() throws Exception {

        try {
            homeScreenView.navigateTo(vz_strings.navi_settings);
            baseControlsHelper.waitForPresent(vz_strings.settings_manageStorage);
            baseControlsHelper.clickOnNameContainsAndVisibile(vz_strings.settings_manageStorage);
            if (settingsView.getCurrentStoragePlan().equalsIgnoreCase(vz_strings.settings_manageStorage_oneTB_plan)) {
                settingsView.downgradeStorageTo500GB();
                settingsView.upgradeStorageToOneTB();
            } else settingsView.upgradeStorageToOneTB();
            String logs = localyticsHelper.getLogs();
            localyticsHelper.print(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_ManageStorage);
            TestCase.assertTrue("Localytics of " + vz_strings.logs_ManageStorage + " does not exist", localyticsHelper.isExisted(logs, vz_strings.logs_ManageStorage));
            TestCase.assertTrue("Localytics of " + vz_strings.logs_Storage_Step_Confirmation_Dialog + " does not exist", localyticsHelper.isExisted(logs, vz_strings.logs_Storage_Step_Confirmation_Dialog));
        } finally {
            settingsView.downgradeStorageTo500GB();
        }
    }
}
