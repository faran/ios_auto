package com.sncr.verizon.appiumtests.IV.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class OnTheGoPlaylist extends BaseTestClass {

    @Test(testName = "IV-707", groups = {"release", GroupNames.MUSIC})
    public void testOnTheGoPlaylist() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_music);
        musicView.selectTab(vz_strings.tab_playlists);
        baseControlsHelper.clickOn("On-The-Go");
        precondition.addSongToOnTheGo();

        TestCase.assertTrue("Song is not added ", baseControlsHelper.getCountInViewByPredicate("MusicView") > 0);
    }
}
