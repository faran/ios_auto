package com.sncr.verizon.appiumtests.IV.delete;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.controls.Ologger;
import junit.framework.TestCase;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.Map;

public class DeleteMediaNoConnection extends BaseTestClass {

    private SoftAssert softAssert = new SoftAssert();

    @Test(testName = "IV-104", groups = { GroupNames.DELETE, "release"})
    public void testDeleteMediaNoConnection() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);

        baseControlsHelper.openContext(vz_strings.context_select);
        gridView.selectWithScroll(vz_strings.DataType.PHOTO, 1, 4);

        nativeIosAppsView.turnOnAirplaneModeThroughSiri();
        Map preDelete = gridView.elementsInView();

        baseControlsHelper.openContext(vz_strings.context_delete);
        baseControlsHelper.clickOn(vz_strings.button_yes);

        baseControlsHelper.waitForShow(vz_strings.button_ok);
        String body = baseControlsHelper.getTextFromAlertBox(1);

        Ologger.log.debug("contents of popup body: " + body);

        softAssert.assertTrue(body.compareTo(vz_strings.dialog_delete_files_no_connection) == 0,
                "Text does not match");

        baseControlsHelper.clickOn(vz_strings.button_ok);
        Map postDelete = gridView.elementsInView();

        Ologger.log.debug("Contents of pre: " + preDelete, "contents of post" + postDelete);

        softAssert.assertTrue(preDelete.equals(postDelete), "Items pre/post delete do not match");

        softAssert.assertAll();
    }

    @AfterMethod(alwaysRun = true)
    public void disableAirplaneMode() throws Exception {
        nativeIosAppsView.disableAirplaneMode();
    }
}
