// STEP 3
package com.sncr.verizon.appiumtests.IV.settings.myaccount;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class VerifySelectingPhotoThumbnailNavigatingToPhotoDetailPage extends BaseTestClass {

    @Test(testName = "IV-4941", groups = {"release", GroupNames.MANAGE_STORAGE})
    public void testVerifySelectingPhotoThumbnailNavigatingToPhotoDetailPage() throws Exception {
        homeScreenView.navigateTo(vz_strings.navi_settings);
        baseControlsHelper.clickOn(vz_strings.my_Account);
        myAccountPage.navigateToDeleteMyAccount();
        deleteMyAccountPage.clickOnPhotoThumbnail(0);
        TestCase.assertTrue("Not navigated to photo detail page", baseControlsHelper.getCountByName(vz_strings.ab_btn_Download) > 0);
    }
}
