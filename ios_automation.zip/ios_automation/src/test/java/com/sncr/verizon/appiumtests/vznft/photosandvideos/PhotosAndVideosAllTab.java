//https://jira.synchronoss.net:8443/jira/browse/VZNFT-69/step-1
package com.sncr.verizon.appiumtests.vznft.photosandvideos;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by kram0003 on 26/02/18.
 */
public class PhotosAndVideosAllTab extends BaseTestClass {

    @Test(testName = "VZNFT-69", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS})
    public void photosAndVideosAllTab() throws Exception {

        homeScreenView.fromHomeClickAt(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);

        String logs = localyticsHelper.getLogs();

        TestCase.assertTrue("Localytics of " + vz_strings.logs_photosVideosAll + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_photosVideosAll) == 1);
    }
}
