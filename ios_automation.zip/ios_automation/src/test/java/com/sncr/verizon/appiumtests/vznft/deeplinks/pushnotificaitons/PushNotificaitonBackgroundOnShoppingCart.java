package com.sncr.verizon.appiumtests.vznft.deeplinks.pushnotificaitons;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class PushNotificaitonBackgroundOnShoppingCart extends BaseTestClass {

    @Test(testName = "VZNFT-278", groups = {"vznft", GroupNames.PUSH_NOTIFICATIONS})
    public void testPushNotificaitonBackgroundOnShoppingCart() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.removeAllProductFromCart();

        gridView.tapItemsInMultiSelectModeUniversal(1, vz_strings.DataType.PHOTO);
        photosAndVideosView.selectAllAddToCart();
        baseControlsHelper.waitForShow(vz_strings.text_cart);

        nativeIosAppsView.openDeeplink(vz_strings.Deeplinks.PRINTS_AND_GIFTS_CANVAS);

        baseControlsHelper.waitForShow(vz_strings.printsAndGifts_Canvas);

        baseControlsHelper.clickOn(vz_strings.button_exit);
        baseControlsHelper.clickOn(vz_strings.button_yes);
        baseControlsHelper.waitForShow(vz_strings.tab_all);

        TestCase.assertTrue("Should return to photos and videos", baseControlsHelper.isVisible(vz_strings.text_photosAndVideos));
    }
}
