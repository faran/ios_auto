package com.sncr.verizon.appiumtests.IV.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class PhotoBookVideoUnsupported extends BaseTestClass {

    @Test(testName = "IV-5137", groups = {GroupNames.FUJI, GroupNames.PHOTOBOOK, "release"})
    public void testPhotoBookVideoUnsupported() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        precondition.deleteAllAlbums();

        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.createAlbumByDataType(vz_strings.DataType.VIDEO, vz_strings.create_newAlbumName);
        photosAndVideosView.selectTab(vz_strings.tab_albums);
        photosAndVideosView.openAlbum();
        baseControlsHelper.waitForShow(vz_strings.button_smartAlbumPlay);

        baseControlsHelper.openContext(vz_strings.context_createPhotoBook);
        baseControlsHelper.waitForShow(vz_strings.button_ok);

        TestCase.assertTrue("Alert message title incorrect",
                baseControlsHelper.getTextFromAlertBox(0).equals(vz_strings.text_photobook_unsupported_video_title));

        TestCase.assertTrue("Alert message body incorrect",
                baseControlsHelper.getTextFromAlertBox(1).equals(vz_strings.text_photobook_unsupported_video_body));
    }
}
