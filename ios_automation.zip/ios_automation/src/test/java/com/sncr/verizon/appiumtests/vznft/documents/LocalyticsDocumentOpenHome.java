//VZNFT-3 #Step 1 VZNFT-109
package com.sncr.verizon.appiumtests.vznft.documents;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LocalyticsDocumentOpenHome extends BaseTestClass {

    @Test(testName = "VZNFT-109", groups = {"vznft", GroupNames.DOCUMENTS})
    public void testLocalyticsDocumentOpenHome() throws Exception {

        homeScreenView.fromHomeClickOnGridCell(vz_strings.name_docGrid);

        String logs = localyticsHelper.getLogs();

        TestCase.assertTrue("Localytics of " + vz_strings.logs_galleryDetail + " is not in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_galleryDetail) == 1);

        Thread.sleep(2000);
        baseControlsHelper.swipe( "right");

        localyticsHelper.print(logs, vz_strings.logs_mediaOpen);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaOpen + " is not in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaOpen) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + " is not in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + vz_strings.logs_mediaTypeDocument) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_page + " is not in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_page + " = " + "\"" + vz_strings.logs_homeScreen + "\"") == 1);
    }
}