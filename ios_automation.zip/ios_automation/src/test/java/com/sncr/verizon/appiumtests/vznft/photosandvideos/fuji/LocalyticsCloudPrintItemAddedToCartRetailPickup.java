//https://jira.synchronoss.net:8443/jira/browse/VZNFT-223
package com.sncr.verizon.appiumtests.vznft.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 13/11/18.
 */
public class LocalyticsCloudPrintItemAddedToCartRetailPickup extends BaseTestClass {

    @Test(testName = "VZNFT-223", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI})
    public void testLocalyticsCloudPrintItemAddedToCartRetailPickup() throws Exception {

        photosAndVideosView.addToCartThroughRetailPickUp(1, "18018");

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagEvent);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketCloudItemComposed + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_PrintAddedToCart) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketDeliveryType + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucketDeliveryType + "\"" + " = " + "\"" + vz_strings.logs_RetailPickup + "\"") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketPickupLocation + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucketPickupLocation + "\"" + " = " + vz_strings.logs_Walmart) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SUCCESSFUL + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.LOGS_STATUS + " = " + vz_strings.LOGS_SUCCESSFUL) == 1);
        TestCase.assertTrue("Localytics of " + "Duration" + " is not 1 in logs", localyticsHelper.isExisted(logs, "Duration" + " = "));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketItemBrowsed + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucketItemAdded + "\"" + " = " + "\"" +
                        vz_strings.logs_photoBucketItemFirstPrintSize + "\"") == 1);
    }
}
