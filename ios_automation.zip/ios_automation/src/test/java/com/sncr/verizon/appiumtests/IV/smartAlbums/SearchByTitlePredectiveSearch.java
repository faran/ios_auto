//IV-1116
package com.sncr.verizon.appiumtests.IV.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class SearchByTitlePredectiveSearch extends BaseTestClass {

    @Test(testName = "IV-1116", groups = {"release", GroupNames.SMART_ALBUMS})
    public void testSearchByTitlePredectiveSearch() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_stories);
        baseControlsHelper.clickOn(vz_strings.view_searchStoriesBar);

        baseControlsHelper.setValuetoTextFieldByName("o", vz_strings.view_searchStoriesBar);

        TestCase.assertTrue("Story not present ?", baseControlsHelper.getCountByName("Photos stories") > 0);

    }
}