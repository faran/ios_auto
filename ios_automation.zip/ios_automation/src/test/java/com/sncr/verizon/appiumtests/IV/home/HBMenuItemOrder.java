//IV-2463 step 2
package com.sncr.verizon.appiumtests.IV.home;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class HBMenuItemOrder extends BaseTestClass {

    @Test(testName = "IV-2463", groups = {"release", GroupNames.HOME})
    public void testHBMenuItemOrder() throws Exception{

        homeScreenView.navigateTo(vz_strings.navi_home);
        baseControlsHelper.clickOn(vz_strings.navi_icon);
        List<String> menuItemsOrdered = new ArrayList<>(Arrays.asList(vz_strings.menuItemsOrdered));
        TestCase.assertTrue(homeScreenView.menuOrder(menuItemsOrdered));
    }
}
