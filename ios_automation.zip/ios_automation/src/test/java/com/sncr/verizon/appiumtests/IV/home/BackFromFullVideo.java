package com.sncr.verizon.appiumtests.IV.home;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.annotations.Test;

public class BackFromFullVideo extends BaseTestClass {

    @Test(testName = "IV-2575", groups = {"release", GroupNames.HOME})
    public void testBackFromFullVideo() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_home);
        homeScreenView.clickOnStory(vz_strings.carousel_story);
        gridView.tapItem(vz_strings.DataType.VIDEO);
        homeScreenView.backToHome();

    }

}