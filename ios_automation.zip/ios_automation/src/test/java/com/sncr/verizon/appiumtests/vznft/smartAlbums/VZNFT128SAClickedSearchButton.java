//https://jira.synchronoss.net:8443/jira/browse/VZNFT-128
package com.sncr.verizon.appiumtests.vznft.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class VZNFT128SAClickedSearchButton extends BaseTestClass {

    @Test(testName = "VZNFT-128", groups = {"vznft", GroupNames.SMART_ALBUMS})
    public void testVZNFT128SAClickedSearchButton() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_stories);
        baseControlsHelper.clickOn(vz_strings.view_searchStoriesBar);
        baseControlsHelper.setValuetoTextFieldByName("St", vz_strings.view_searchStoriesBar);
        baseControlsHelper.clickOn(vz_strings.button_search);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_storiesSearch);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_storiesSearch + " is not 1 in logs",
                localyticsHelper.getCountOf(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_storiesSearch) == 2);
        TestCase.assertTrue(vz_strings.logs_step + " does not exist",
                localyticsHelper.isExisted(logs, vz_strings.logs_step + " = " + "\"" + vz_strings.logs_clickedSearchButton + "\""));
    }
}
