//https://jira.synchronoss.net:8443/jira/browse/VZNFT-69/step-5
package com.sncr.verizon.appiumtests.vznft.publicshare;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.SortAndFilter;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

import java.util.List;

/**
 * Created by kram0003 on 28/02/18.
 */
public class PhotoAndVideosAllPhtVidCpyShrLnk extends BaseTestClass {

    @Test(testName = "VZNFT-69", groups = {"vznft", GroupNames.PUBLIC_SHARE})
    public void photoAndVidoesPhtVidCpyShareLink() throws Exception {
        homeScreenView.fromHomeClickAt(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.sortBy(SortAndFilter.PHOTOS);
        String photoSize = photosAndVideosView.ContentData(1, vz_strings.DataType.PHOTO);
        photosAndVideosView.sortBy(SortAndFilter.VIDEOS);
        String videoSize = photosAndVideosView.ContentData(1, vz_strings.DataType.VIDEO);
        photosAndVideosView.sortBy(SortAndFilter.EVERYTHING);
        baseControlsHelper.openContext(vz_strings.context_select);
        gridView.selectWithScroll(vz_strings.DataType.PHOTO, 1, 4);
        gridView.selectWithScroll(vz_strings.DataType.VIDEO, 1, 4);
        photosAndVideosView.clickOnShareAndCopyShare(vz_strings.context_copyShareLink);
        baseControlsHelper.waitForDismiss(vz_strings.toast_creatingSocialShareLink);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagEvent);

        List<String> contenttype = localyticsHelper.dynamicCount(logs, vz_strings.logs_shareContentType);
        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SHARE_SEND_CONTENT + " is not 2 in logs",
                localyticsHelper.isExisted(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND_CONTENT));
        for (String contentstype : contenttype) {
            if ((contentstype.contains("Video")) || (contentstype.contains("Photo"))) {
                TestCase.assertTrue("Localytics of " + vz_strings.logs_shareContentType + " is not 1 in logs",
                        localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareContentType + "\" " + contentstype) == 1);
            } else TestCase.assertFalse("Localytics of " + vz_strings.logs_shareContentType + " not matches", true);
        }
        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SHARE_SEND + " is not 1 in logs",
                localyticsHelper.isExisted(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND));
        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SUCCESSFUL + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.LOGS_STATUS + " = " + vz_strings.LOGS_SUCCESSFUL) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareItemShared + "  items size is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareItemShared + "\" = 1") == 2);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareContentType + " photo is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareContentType + "\" = " + "Photos") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareContentType + " photo is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareContentType + "\" = " + "Videos") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareContentSize + " content size is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareContentSize + "\" = \"" + photoSize + "\"") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareContentSize + " content size is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareContentSize + "\" = \"" + videoSize + "\"") == 1);
    }
}


