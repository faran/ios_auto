//IV-4276 4/5
package com.sncr.verizon.appiumtests.IV.photosandvideos.real;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class CreateCollageMultiselectStory extends BaseTestClass {

    @Test(testName = "IV-4276", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.REAL})
    public void testCreateCollageMultiselectStory() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_stories);
        photosAndVideosView.openStory10();
        gridView.tapItemsInMultiSelectMode(2, vz_strings.DataType.PHOTO);
        baseControlsHelper.openContext(vz_strings.context_createcollage);
        String pageTitle = baseControlsHelper.getNameByIndexfromClassName(0, "XCUIElementTypeNavigationBar");
        TestCase.assertTrue("Create Collage view is not open", pageTitle.equals("Collage"));
    }
}
