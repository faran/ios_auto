/**
 * VZNFT-38
 * */
package com.sncr.verizon.appiumtests.vznft.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LocalyticsMusicFavoritesSongs extends BaseTestClass{

    @Test(testName = "VZNFT-38", groups = {"vznft", GroupNames.MUSIC})
    public void testLocalyticsMusicFavoritesSongs() throws Exception {

        precondition.clickMusicHeadFromHome();
        musicView.selectTab(vz_strings.tab_playlists);
        musicView.removeSongFromFavorites();
        musicView.selectTab(vz_strings.tab_songs);
        listView.selectFirstItem10();
        baseControlsHelper.openContext(vz_strings.context_addFavorite);

        StringBuilder stringBuilder = new StringBuilder(vz_strings.logs_count).append(" = ").append(1);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_favItemAdded);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_favItemAdded + " does not exist",
              localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_favItemAdded) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_count + " does not exist",
              localyticsHelper.isExisted(logs, stringBuilder.toString()));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + " does not exist",
              localyticsHelper.isExisted(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + vz_strings.logs_mediaTypeMusic));
    }
}
