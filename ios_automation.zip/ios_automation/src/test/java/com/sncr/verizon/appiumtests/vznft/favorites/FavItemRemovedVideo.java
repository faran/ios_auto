/**
 * VZNFT-174 - Step 1-2/1
 */
package com.sncr.verizon.appiumtests.vznft.favorites;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.SortAndFilter;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.constants.vz_strings.DataType;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

import java.util.Map;

public class FavItemRemovedVideo extends BaseTestClass {
    private int numOfDataTypesRemoved;

    @Test(testName = "VZNFT-174", groups = {"vznft", GroupNames.FAVORITES})
    public void testFavItemRemovedVideo() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_albums);
        precondition.createFavoriteAlbum(DataType.VIDEO, SortAndFilter.VIDEOS);
        photosAndVideosView.selectFavoriteAlbum();

        //Holds all the items that will be removed from favorites
        Map itemsInAlbum = gridView.elementsInView();

        photosAndVideosView.selectAllAction(vz_strings.context_removeFavorite);
        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_favItemRemoved);

        //We need to determine what data types were removed so we can check for them in logs
        if (!itemsInAlbum.get(DataType.PHOTO).equals(0)) {
            TestCase.assertTrue("Localytics of " + vz_strings.logs_count + " does not exist",
                    localyticsHelper.isExisted(logs, vz_strings.logs_count + " = " + itemsInAlbum.get(DataType.PHOTO)));
            TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + " does not exist",
                    localyticsHelper.isExisted(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + vz_strings.logs_mediaTypePhotos));
            numOfDataTypesRemoved++;
        }
        if (!itemsInAlbum.get(DataType.VIDEO).equals(0)) {
            TestCase.assertTrue("Localytics of " + vz_strings.logs_count + " does not exist",
                    localyticsHelper.isExisted(logs, vz_strings.logs_count + " = " + itemsInAlbum.get(DataType.VIDEO)));
            TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + " does not exist",
                    localyticsHelper.isExisted(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + vz_strings.logs_mediaTypeVideos));
            numOfDataTypesRemoved++;
        }
        if (!itemsInAlbum.get(DataType.STORY).equals(0)) {
            TestCase.assertTrue("Localytics of " + vz_strings.logs_count + " does not exist",
                    localyticsHelper.isExisted(logs, vz_strings.logs_count + " = " + itemsInAlbum.get(DataType.STORY)));
            TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + " does not exist",
                    localyticsHelper.isExisted(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + vz_strings.logs_mediaTypeStories));
            numOfDataTypesRemoved++;
        }

        //A favItemRemoved tag is generated for each dataclass which is removed from favorites
        TestCase.assertTrue("Localytics of " + vz_strings.logs_favItemRemoved + " does not exist",
                localyticsHelper.isExisted(logs, vz_strings.logs_favItemRemoved));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_tagEvent + " is not " + numOfDataTypesRemoved + " in logs",
                localyticsHelper.getCountOf(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_favItemRemoved) == numOfDataTypesRemoved);

    }
}

