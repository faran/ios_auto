package com.sncr.verizon.appiumtests.IV.photosandvideos.downloads;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.SortAndFilter;
import org.testng.annotations.Test;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;

import junit.framework.TestCase;
/**
 * @author leletsn
 *  IV-849-DownloadVideosFromAll
 */
public class DownloadVideosFromAllInDetailView extends BaseTestClass {
	public void pre_condition() throws Exception{
		homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
		photosAndVideosView.selectTab(vz_strings.tab_all);
		photosAndVideosView.setPickWheelFilter(SortAndFilter.VIDEOS);
		}
	
	@Test(testName = "IV-849", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.DOWNLOADS})
	public void testDownloadVideosFromAllDetailView() throws Exception {
		pre_condition();
		baseControlsHelper.clickOnNameLike(vz_strings.name_video);
		baseControlsHelper.clickOn(vz_strings.ab_btn_Download);
		photosAndVideosView.checkDownload();
		Thread.sleep(1000);
		TestCase.assertTrue("Download still in progress", baseControlsHelper.getCountByName(vz_strings.progressbar)==0);
		}
	}
