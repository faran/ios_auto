//IV-4818
package com.sncr.verizon.appiumtests.IV.photosandvideos;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

import static com.sncr.verizon.appiumtests.constants.vz_strings.tab_all;

public class DefaultNavPV extends BaseTestClass {

    @Test(testName = "IV-4818", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS})
    public void testDefaultNavPV() throws Exception {
        homeScreenView.navigateTo(vz_strings.navi_home);
        homeScreenView.fromHomeClickAt(vz_strings.home_photsAndVideos);
        TestCase.assertTrue("Are we not at PV All tab?", (baseControlsHelper.isSelected(tab_all)));

        homeScreenView.navigateTo(vz_strings.navi_home);
        homeScreenView.fromHomeClickAt(vz_strings.home_photsAndVideos);
        TestCase.assertTrue("Are we not at PV All tab?", (baseControlsHelper.isSelected(tab_all)));

    }
}
