//https://jira.synchronoss.net:8443/jira/browse/VZNFT-173 #3,4
package com.sncr.verizon.appiumtests.vznft.favorites;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class FavoriteItemAddedMusic extends BaseTestClass {

    @Test(testName = "VZNFT-173", groups = {"vznft", GroupNames.FAVORITES})
    public void testFavoriteItemAddedMusic() throws Exception {

        //If a favorite item is removed, two of the same tags which we are expecting are sent
        int itemCount = 1;

        homeScreenView.navigateTo(vz_strings.navi_music);
        musicView.selectTab(vz_strings.tab_playlists);
        //Increment the number of times we should see these tags
        if (baseControlsHelper.getCountByName(vz_strings.view_musicFavorites) != 0)
            itemCount++;

        musicView.removeSongFromFavorites();

        musicView.addSongToFavoritesFromSongs();

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_favItemAdded);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_favItemAdded + " does not exist",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_favItemAdded) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_count + " does not exist",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_count + " = " + "1") == itemCount);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + " does not exist",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + vz_strings.logs_mediaTypeMusic) == itemCount);
    }

}
