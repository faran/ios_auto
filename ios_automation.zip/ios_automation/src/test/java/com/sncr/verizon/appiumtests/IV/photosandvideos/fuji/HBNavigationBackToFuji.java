//IV-2463
package com.sncr.verizon.appiumtests.IV.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class HBNavigationBackToFuji extends BaseTestClass {

    @Test(testName = "IV-2463", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI})
    public void testHBNavigationBackToFuji() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        homeScreenView.navigateTo(vz_strings.navi_printshop);
        baseControlsHelper.waitForDismiss(vz_strings.spinner);
        if(baseControlsHelper.getCountByName(vz_strings.button_acceptContinue) > 0)
            baseControlsHelper.clickOn(vz_strings.button_acceptContinue);
        String pageTitle = baseControlsHelper.getNameByIndexfromClassName(0, "XCUIElementTypeNavigationBar");
        TestCase.assertTrue("Fuji view is not open", pageTitle.equals(vz_strings.navi_printshop));
    }
}
