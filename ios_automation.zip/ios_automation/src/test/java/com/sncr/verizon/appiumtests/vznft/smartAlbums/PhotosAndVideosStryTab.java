//https://jira.synchronoss.net:8443/jira/browse/VZNFT-73/step-1
package com.sncr.verizon.appiumtests.vznft.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by kram0003 on 06/03/18.
 */
public class PhotosAndVideosStryTab extends BaseTestClass {

    @Test(testName = "VZNFT-73", groups = {"vznft", GroupNames.SMART_ALBUMS})
    public void PhotosAndVideosStoryTab() throws Exception {

        homeScreenView.fromHomeClickAt(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_stories);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagScreen);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_photosVideosAll + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_photosVideosStories) == 1);
    }
}
