//https://jira.synchronoss.net:8443/jira/browse/IV-2473
package com.sncr.verizon.appiumtests.IV.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/*
 * IV-2473 Launch Fuji Print Service via cart icon - no items in shopping cart.
 * */

public class IV2473LaunchPrintServiceViaCart extends BaseTestClass {

    @Test(testName = "IV-2473", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI})
    public void testIV2473LaunchPrintServiceViaCart() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        baseControlsHelper.clickOn(vz_strings.button_cartIcon);
        baseControlsHelper.waitForDismiss(vz_strings.spinner);
        if (baseControlsHelper.getCountByName(vz_strings.text_printsAndGifts) != 0) {
            baseControlsHelper.clickOn(vz_strings.button_exit);
            baseControlsHelper.clickOn(vz_strings.button_yes);
            baseControlsHelper.waitForShow(vz_strings.tab_all);
            TestCase.assertTrue("Photos and Videos screen missing ", baseControlsHelper.isVisible(vz_strings.text_photosAndVideos));
        } else {
            TestCase.assertTrue("Cart screen not found", ("Cart").equals(baseControlsHelper.getTextByNameContains("Cart")));
        }
    }
}

