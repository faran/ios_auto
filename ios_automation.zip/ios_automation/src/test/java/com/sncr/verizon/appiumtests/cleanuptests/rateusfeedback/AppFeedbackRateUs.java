package com.sncr.verizon.appiumtests.cleanuptests.rateusfeedback;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class AppFeedbackRateUs extends BaseTestClass {

    private SoftAssert softAssert = new SoftAssert();

    @Test(testName = "VZNFT-80", groups = {"vznft", GroupNames.RATE_US_FEEDBACK})
    public void testAppFeedbackRateUs() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        for (int i = 0; i <= 15; i++) {
            gridView.tapItem(vz_strings.DataType.PHOTO);
            if (baseControlsHelper.getCountByName(vz_strings.button_rateNotNow) > 0) {
                break;
            }
            baseControlsHelper.tapOnBackButton();
        }
        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagScreen);
        softAssert.assertTrue(localyticsHelper.getCountOf(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logsRateUs) == 1,
                "Localytics of " + vz_strings.logs_tagScreen + " is not 1 in logs");
        baseControlsHelper.clickOn(vz_strings.rating_stars);
        baseControlsHelper.clickOn(vz_strings.button_cancel);
        softAssert.assertAll();
    }
}
