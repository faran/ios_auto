package com.sncr.verizon.appiumtests.IV.home;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.constants.vz_strings.DataType;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.annotations.Test;

public class BackFromFullPhoto extends BaseTestClass {

    @Test(testName = "IV-2573", groups = {"release", GroupNames.HOME})
    public void testBackFromFullPhoto() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_home);
        homeScreenView.clickOnStory(vz_strings.carousel_story);
        gridView.tapItem(DataType.PHOTO);
        homeScreenView.backToHome();

    }

}