/**
 * VZNFT-31 - Step 2
 * */
package com.sncr.verizon.appiumtests.vznft.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LocalyticsMusicFavoritesPlaySelected extends BaseTestClass{

    @Test(testName = "VZNFT-31", groups = {"vznft", GroupNames.MUSIC})
        public void testLocalyticsMusicPlaylistsPlaySelected() throws Exception {

            precondition.clickMusicHeadFromHome();
            musicView.selectTab(vz_strings.tab_playlists);
            precondition.addSongToFavoriteFromSongs();
            baseControlsHelper.clickOn("Favorites");
            musicView.clickOnAllElementsInMusicList(vz_strings.MusicView.Favorites);
            baseControlsHelper.openContext(vz_strings.context_playSelected);

            String logs = localyticsHelper.getLogs();
            localyticsHelper.print(logs, vz_strings.logs_tagScreen);

            TestCase.assertTrue("Localytics of " + vz_strings.logs_tagEvent + " is not 1 in logs",
                    localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaPlay) == 1);
            TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + " is not 1 in logs",
                    localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\" = " + vz_strings.logs_mediaTypeSong) == 1);
        }
}
