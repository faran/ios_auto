package com.sncr.verizon.appiumtests.IV.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class CloudMusicPlayGenre extends BaseTestClass {

    @Test(testName = "IV-742", groups = {"release", GroupNames.MUSIC})
    public void testCloudMusicPlayGenre() throws Exception {


        homeScreenView.navigateTo(vz_strings.navi_music);
        playMusicFromGenres();
        musicView.selectTab(vz_strings.tab_playlists);
        baseControlsHelper.clickOn("On-The-Go");
        //when some song is playing it hides the number of song which i am asserting
        TestCase.assertTrue("Atleast one song should be playing ", baseControlsHelper.getCountByName("1") == 0);

    }

    public void playMusicFromGenres() throws Exception {

        musicView.selectTab(vz_strings.tab_genres);
        baseControlsHelper.clickOn("Unknown Genre");
        listView.selectFirstItem10();

    }
}
