//IV-295
package com.sncr.verizon.appiumtests.IV.photosandvideos;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.constants.vz_strings.DataType;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class AllPhotosVideosSelectContextMenu extends BaseTestClass {

    @Test(testName = "IV-295", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.CONTEXT_MENU})
    public void testAllPhotosVideosSelectContextMenu() throws Exception {


        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        gridView.tapItemInSelectMode(DataType.PHOTO);
        baseControlsHelper.openContext(null);

        TestCase.assertTrue("Options missing ", contextualMenu.verifyOptions(vz_strings.DataType.PHOTO, vz_strings.view_photoAll, true));
    }
}
