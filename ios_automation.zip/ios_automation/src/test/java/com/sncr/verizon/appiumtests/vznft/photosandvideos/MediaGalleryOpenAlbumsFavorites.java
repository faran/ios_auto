/**
 * VZNFT-177 Step 2
 */
package com.sncr.verizon.appiumtests.vznft.photosandvideos;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.SortAndFilter;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class MediaGalleryOpenAlbumsFavorites extends BaseTestClass {

    @Test(testName = "VZNFT-177", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS})
    public void testMediaGalleryOpenAlbumsFavorites() throws Exception {

        homeScreenView.fromHomeClickAt(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_albums);
        precondition.createFavoriteAlbum(vz_strings.DataType.PHOTO, SortAndFilter.PHOTOS);
        photosAndVideosView.selectFavoriteAlbum();

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagEvent);

        //Checking for two tags since precondition opens album, generating a tag
        TestCase.assertTrue("Localytics of " + vz_strings.logs_tagEvent + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaGalleryOpen) == 2);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_page + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_page + " = " + vz_strings.logs_album) == 2);
    }
}
