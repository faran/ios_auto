//https://jira.synchronoss.net:8443/jira/browse/VZNFT-306
package com.sncr.verizon.appiumtests.vznft.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.EmailAndMessageUtils;
import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.managers.iOSManager;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 21/01/19.
 */
public class AppBackgroundedOnSameScreenWhereExternalLinkWillNavigate extends BaseTestClass {

    @Test(testName = "VZNFT-306", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI, GroupNames.DEEPLINKS})
    public void testAppBackgroundedOnSameScreenWhereExternalLinkWillNavigate() throws Exception {

        iOSManager.runAppInBackground(-1);
        EmailAndMessageUtils.deleteAllMails();
        EmailAndMessageUtils.sendEmail("vz", vz_strings.Deeplinks.HOME, EmailAndMessageUtils.username);

        nativeIosAppsView.openMailBox();
        baseControlsHelper.clickOnNameContains(vz_strings.Deeplinks.HOME);
        baseControlsHelper.clickOn(vz_strings.Deeplinks.HOME);

        TestCase.assertTrue("Navigation back to cloud app is not possible", baseControlsHelper.getCountByName(vz_strings.verizon_cloud) > 0);
    }
}
