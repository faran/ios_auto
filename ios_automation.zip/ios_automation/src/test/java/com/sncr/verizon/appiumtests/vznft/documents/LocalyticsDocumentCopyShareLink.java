package com.sncr.verizon.appiumtests.vznft.documents;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LocalyticsDocumentCopyShareLink extends BaseTestClass {

    @Test(groups = {"vznft", GroupNames.DOCUMENTS})
    public void testLocalyticsDocumentCopyShareLink() throws Exception {


        homeScreenView.navigateTo(vz_strings.navi_documents);
        listView.selectFirstItemInSelectMode10();
        baseControlsHelper.openContext(vz_strings.context_copyShareLink);
        baseControlsHelper.waitForDismiss(vz_strings.toast_creatingSocialShareLink);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.LOGS_SHARE_SEND_CONTENT);

        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SHARE_SEND_CONTENT + " does not exist",
                localyticsHelper.isExisted(logs, vz_strings.LOGS_SHARE_SEND_CONTENT));
        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SHARE_SEND_CONTENT + " is not 1 in logs",
                localyticsHelper.getCountOf(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND_CONTENT) == 1);


    }
}
