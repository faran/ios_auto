//IV-714
package com.sncr.verizon.appiumtests.IV.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class MusicFavoritesContextMenu extends BaseTestClass {

    @Test(testName = "IV-714", groups = {"release", GroupNames.MUSIC, GroupNames.CONTEXT_MENU})
    public void testMusicFavoritesContextMenu() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_music);
        musicView.selectTab(vz_strings.tab_playlists);
        precondition.addSongToFavoriteFromSongs();
        baseControlsHelper.clickOn("Favorites");
        baseControlsHelper.openContext(null);
        TestCase.assertTrue("Options missing ", contextualMenu.verifyOptions(null,
                vz_strings.view_insideMusicPlaylist, true));
    }
}
