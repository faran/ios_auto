package com.sncr.verizon.appiumtests.IV.photosandvideos;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.managers.iOSManager;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class InteractingWithURLInSMSBringsToFlashbackTab extends BaseTestClass {
    private SoftAssert softAssert = new SoftAssert();

    @Test(testName = "IV-3226", groups = {GroupNames.FLASHBACKS, GroupNames.PUSH_NOTIFICATIONS, "release"})
    public void testInteractingWithURLInSMSBringsToFlashbackTab() throws Exception {

        iOSManager.runAppInBackground(-1);
        nativeIosAppsView.generateSMS(vz_strings.Deeplinks.FLASH_BACK);
        baseControlsHelper.clickOnNameContains(vz_strings.Deeplinks.FLASH_BACK);
        baseControlsHelper.clickOnLabelContainsAndType(vz_strings.Deeplinks.FLASH_BACK, "XCUIElementTypeOther");
        softAssert.assertTrue(baseControlsHelper.getValue(vz_strings.view_Flashbacks) != null,"Not navigated to flashbacks pane");
        homeScreenView.navigateTo(vz_strings.navi_home);
        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.verizon_cloud) >=1,"Unable to navigate back to cloud app");
        softAssert.assertAll();
    }
}
