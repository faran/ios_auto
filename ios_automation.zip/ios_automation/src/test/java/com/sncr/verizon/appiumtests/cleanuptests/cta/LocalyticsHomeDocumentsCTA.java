/*
 * Step 2 VZNFT-6
 */
package com.sncr.verizon.appiumtests.cleanuptests.cta;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.controls.Ologger;
import junit.framework.TestCase;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class LocalyticsHomeDocumentsCTA extends BaseTestClass {


    @BeforeMethod(groups = {"vznft", GroupNames.CTA})
    public void cleanUpDocuments() throws Exception {
        if (doATPAuthCall(msisdn)) {
            if (getMediaCount(ContentType.DOCUMENTS) > 0) {
                if (deleteAllFiles(ContentType.DOCUMENTS)) {
                    Ologger.log.info("All documents cleared");
                    driver().launchApp();
                }
            }
        }
    }

    @Test(testName = "VZNFT-6", groups = {"vznft", GroupNames.CTA})
    public void testLocalyticsHomeDocumentsCTA() throws Exception {

        if (!baseControlsHelper.isClickable(driver().findElementByAccessibilityId(vz_strings.home_cta_documents))) {
            baseControlsHelper.scroll(vz_strings.home_cta_documents, "down");
        }
        homeScreenView.fromHomeClickAt(vz_strings.home_cta_documents);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagScreen);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaTypeDocument + " does not exist",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_mediaTypeDocument + " " + vz_strings.logs_CTA) == 1);
    }

}
