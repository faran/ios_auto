//IV-117
package com.sncr.verizon.appiumtests.IV.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class CreateStoryFromFullVideo extends BaseTestClass {

    @Test(testName = "IV-117", groups = {"release", GroupNames.SMART_ALBUMS})
    public void testCreateStoryFromFullVideo() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        gridView.selectWithScroll(vz_strings.DataType.VIDEO, 1, 4);
        baseControlsHelper.clickOn(vz_strings.b_btn_CreateStory);
        baseControlsHelper.waitForShow("Edit scenes");

        for (int i = 0; i < vz_strings.realPlayerSave.length; i++) {
            TestCase.assertTrue(vz_strings.realPlayerSave[i] + " is not found.",
                    baseControlsHelper.getCountByName(vz_strings.realPlayerSave[i]) != 0);
        }
    }
}
