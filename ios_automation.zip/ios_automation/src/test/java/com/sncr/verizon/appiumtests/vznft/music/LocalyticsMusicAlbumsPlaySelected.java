//VZNFT-21 - Step3
package com.sncr.verizon.appiumtests.vznft.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LocalyticsMusicAlbumsPlaySelected extends BaseTestClass {

    @Test(testName = "VZNFT-21", groups = {"vznft", GroupNames.MUSIC})
    public void testLocalyticsMusicAlbumsPlaySelected() throws Exception {

        precondition.clickMusicHeadFromHome();
        listView.selectFirstItemInSelectMode10();
        baseControlsHelper.openContext(vz_strings.context_playSelected);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_mediaPlay);

        TestCase.assertTrue(vz_strings.logs_tagEvent + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaPlay) == 1);
        TestCase.assertTrue(vz_strings.logs_mediaType + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\" = " + vz_strings.logs_mediaTypeSong) == 1);
    }
}
