package com.sncr.verizon.appiumtests.vznft.deeplinks.pushnotificaitons;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class PushNotificationBackgroundOnSameScreenPushTakesTo extends BaseTestClass {

    SoftAssert softAssert = new SoftAssert();

    @Test(testName = "VZNFT-283", groups = {GroupNames.PUSH_NOTIFICATIONS, "vznft"})
    public void testPushNotificationBackgroundOnSameScreenPushTakesTo() throws Exception {

        //Using settings here instead of fuji deeplink to reduce complexity
        homeScreenView.navigateTo(vz_strings.navi_settings);

        nativeIosAppsView.openDeeplink(vz_strings.Deeplinks.SETTINGS);

        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.navi_settings) > 0,
                "Did not navigate to settings");

        homeScreenView.backToHome();
        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.verizon_cloud) > 0,
                "Was not able to navigate back home");

        softAssert.assertAll();
    }
}
