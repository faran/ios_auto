package com.sncr.verizon.appiumtests.IV.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class MusicAlbumMultiSelectAddToExistingPlaylist extends BaseTestClass {

    @Test(testName = "IV-721", groups = {GroupNames.MUSIC, "release"})
    public void testMusicAlbumMultiSelectAddToExistingPlaylist() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_music);
        musicView.selectTab(vz_strings.tab_playlists);

        musicView.deletePlaylist(vz_strings.create_newAlbumName);
        musicView.newPl(vz_strings.create_newAlbumName);

        musicView.selectTab(vz_strings.tab_albums);
        musicView.addToPlaylistFromContextMenu(vz_strings.create_newAlbumName);

        musicView.selectTab(vz_strings.tab_playlists);
        musicView.openPlaylist(vz_strings.create_newAlbumName);
        baseControlsHelper.waitForShow("1");

        TestCase.assertTrue("",
                baseControlsHelper.getCountByNameContains(vz_strings.mtype_Any_Playlists) > 0);

    }
}
