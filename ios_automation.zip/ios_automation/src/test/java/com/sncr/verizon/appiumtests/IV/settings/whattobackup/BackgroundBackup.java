/**
 * Test URL: https://jira.synchronoss.net:8443/jira/browse/IV-2342
 *
 * @author Alen Kalac
 */

package com.sncr.verizon.appiumtests.IV.settings.whattobackup;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class BackgroundBackup extends BaseTestClass {

    @Test(testName = "IV-2342", groups = {"release", GroupNames.SETTINGS, GroupNames.WHAT_TO_BACKUP})
    public void testBackgroundBackupLabelAndText() throws Exception {
        homeScreenView.navigateTo(vz_strings.navi_settings);
        baseControlsHelper.clickOn(vz_strings.settings_whatToBackUp);

        baseControlsHelper.clickOnNameContains("Learn more");

        int labelCount = baseControlsHelper.getCountByName(vz_strings.text_background_backup_label);
        TestCase.assertTrue("Missing Label: ", labelCount != 0);

        String textValue = baseControlsHelper.getTextByNameContains("iPhone");

        TestCase.assertTrue("Text Does't Match", textValue.contains(vz_strings.text_background_backup_text));
    }
}
