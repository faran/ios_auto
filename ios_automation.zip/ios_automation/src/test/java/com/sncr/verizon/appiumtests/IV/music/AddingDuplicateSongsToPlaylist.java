package com.sncr.verizon.appiumtests.IV.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class AddingDuplicateSongsToPlaylist extends BaseTestClass {

    @Test(testName = "IV-699", groups = {"release", GroupNames.MUSIC})
    public void testAddingDuplicateSongsToPlaylist() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_music);
        musicView.selectTab(vz_strings.tab_playlists);
        musicView.deletePlaylist(vz_strings.view_musicPlaylists);
        precondition.addNewPL();
        musicView.openPlaylist(vz_strings.view_musicPlaylists);

        int numOfSongsInPlaylistAfterCreation = listView.getCountInSection(0);

        baseControlsHelper.tapOnBackButton();
        musicView.selectTab(vz_strings.tab_songs);
        musicView.addToPlaylistFromContextMenu(vz_strings.view_musicPlaylists);
        musicView.selectTab(vz_strings.tab_playlists);
        musicView.openPlaylist(vz_strings.view_musicPlaylists);

        TestCase.assertTrue("Duplicate song was added to playlist", numOfSongsInPlaylistAfterCreation == listView.getCountInSection(0));
    }
}
