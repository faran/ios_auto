package com.sncr.verizon.appiumtests.IV.photosandvideos;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.openqa.selenium.ScreenOrientation;
import org.testng.annotations.Test;

public class PhotoOrientationFromHome extends BaseTestClass {

    @Test(testName = "IV-285", groups = {"release", "snapshot", GroupNames.PHOTOS_AND_VIDEOS})
    public void testPhotoOrientation() throws Exception {

        homeScreenView.fromHomeClickOnGridCell(vz_strings.name_photoGrid);
        baseControlsHelper.setOrientation(ScreenOrientation.LANDSCAPE);
        baseControlsHelper.setOrientation(ScreenOrientation.PORTRAIT);

        TestCase.assertTrue("Photo is not open",
                baseControlsHelper.getCountByClassName("XCUIElementTypeScrollView") != 0);
    }
}
