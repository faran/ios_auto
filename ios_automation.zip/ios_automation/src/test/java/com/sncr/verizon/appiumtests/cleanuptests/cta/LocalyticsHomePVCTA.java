/*
 * VZNFT-75 - Step 2
 * */
package com.sncr.verizon.appiumtests.cleanuptests.cta;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.HelperUtilities;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.controls.Ologger;
import junit.framework.TestCase;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class LocalyticsHomePVCTA extends BaseTestClass {

    @BeforeMethod(groups = {"vznft", GroupNames.CTA})
    public void cleanUpPhotosAndVideos() throws Exception {
        homeScreenView.navigateTo(vz_strings.navi_settings);
        settingsView.setWhatNotToBackUp(HelperUtilities.setArguments("", vz_strings.settings_whatToBackUp_Photos, vz_strings.settings_whatToBackUp_Videos));
        if (doATPAuthCall(msisdn)) {
            if (getMediaCount(ContentType.PHOTOS) > 0) {
                if (deleteAllFiles(ContentType.PHOTOS)) {
                    Ologger.log.info("Photos cleared");
                }
            }
            if (getMediaCount(ContentType.VIDEOS) > 0) {
                if (deleteAllFiles(ContentType.VIDEOS)) {
                    Ologger.log.info("Videos cleared");
                }
            }
        }
    }

    @Test(testName = "VZNFT-75", groups = {"vznft", GroupNames.CTA})
    public void testLocalyticsHMPVCTA() throws Exception {

        driver().launchApp();
        baseControlsHelper.waitForShow(vz_strings.home_cta_pv);
        baseControlsHelper.clickOnNameContains(vz_strings.home_photsAndVideos);
        baseControlsHelper.waitForShow(vz_strings.logs_whatToBackupPhotos);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagScreen);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaTypeDocument + " does not exist",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_mediaTypePhotosAndVideos + " " + vz_strings.logs_CTA) == 1);
    }

    @AfterMethod(groups = {"vznft", GroupNames.CTA})
    public void enableDataClasses() throws Exception {
        homeScreenView.navigateTo(vz_strings.navi_settings);
        settingsView.setWhatToBackUp(HelperUtilities.setArguments("", vz_strings.settings_whatToBackUp_Photos, vz_strings.settings_whatToBackUp_Videos));
    }
}
