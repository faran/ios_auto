//VZNFT-23 - Step 1
package com.sncr.verizon.appiumtests.vznft.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LocalyticsMusicArtistsAlbums extends BaseTestClass {

    @Test(testName = "VZNFT-23", groups = {"vznft", GroupNames.MUSIC})
    public void testLocalyticsMusicArtistsAlbums() throws Exception {

        precondition.clickMusicHeadFromHome();
        musicView.selectTab(vz_strings.tab_artists);

        String logs = localyticsHelper.getLogs();
        TestCase.assertTrue("Localytics of " + vz_strings.logs_musicArtists + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_musicArtists) == 1);
        localyticsHelper.print(logs, vz_strings.logs_musicArtistAlbums);
    }
}
