package com.sncr.verizon.appiumtests.vznft.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.List;

public class MediaDownloadStory extends BaseTestClass {
    public String itemCount = "";
    public String mediaType = "";
    private SoftAssert softAssert = new SoftAssert();

    @BeforeMethod
    public void getMediaInfo() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_stories);
        gridView.tapFolderInSelectMode10("Story-0");
        photosAndVideosView.clickOnShareAndCopyShare(vz_strings.context_copyShareLink);
        baseControlsHelper.waitForDismiss(vz_strings.toast_creatingSocialShareLink);
        String logs = localyticsHelper.getLogs();
        List<String> itemsShared = localyticsHelper.dynamicCount(logs, "" + vz_strings.logs_shareItemShared + "");
        List<String> contentType = localyticsHelper.dynamicCount(logs, "" + vz_strings.logs_shareContentType + "");
        String regex = "\\[|\\]";
        itemCount = itemsShared.get(0).replace(regex, "").replace("= ", "");
        mediaType = contentType.get(0).replace(regex, "").replace("= ", "");
        driver().launchApp();
    }

    @Test(testName = "VZNFT-143", groups = {"vznft", GroupNames.SMART_ALBUMS})
    public void testMediaDownloadStory() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_stories);
        gridView.tapFolderInSelectMode10("Story-0");
        baseControlsHelper.openContext(vz_strings.context_download);

        String logs = localyticsHelper.getLogs();

        softAssert.assertTrue(localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaDownload) == 1,
                "Localytics of " + vz_strings.logs_mediaDownload + " is not 1 in logs");
        softAssert.assertTrue(localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + vz_strings.logs_mediaTypeStory) == 1,
                "Localytics of " + vz_strings.logs_mediaTypeStory + " is not 1 in logs");
        softAssert.assertTrue(localyticsHelper.getPatternMatch(logs, vz_strings.logs_count + " = " + "1") == 1,
                "Localytics of " + vz_strings.logs_count + " does not exist");
        baseControlsHelper.waitForDismiss(vz_strings.progressbar, 300);

        logs = localyticsHelper.getLogs();

        softAssert.assertTrue(localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + mediaType) == 1,
                "Localytics of " + vz_strings.logs_mediaTypePhotos + " is not 1 in logs");
        softAssert.assertTrue(localyticsHelper.getPatternMatch(logs, vz_strings.logs_count + " = " + "1") == 1,
                "Localytics of " + vz_strings.logs_count + " does not exist");
        softAssert.assertTrue(localyticsHelper.getPatternMatch(logs, vz_strings.logs_count + " = " + itemCount) == 1,
                "Localytics of " + vz_strings.logs_count + " does not exist");
        softAssert.assertAll();
    }
}
