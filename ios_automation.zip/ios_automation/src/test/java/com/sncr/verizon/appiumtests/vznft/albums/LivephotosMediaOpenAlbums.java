package com.sncr.verizon.appiumtests.vznft.albums;
/*
 * Step 2 VZNFT-482
 */

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LivephotosMediaOpenAlbums extends BaseTestClass {

    @Test(testName = "VZNFT-482", groups = {"vznft", GroupNames.ALBUMS})
    public void testLivephotosMediaOpenAlbums() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_albums);
        precondition.removeAllFavoritesFromAlbum();
        precondition.deleteAllAlbums();
        System.out.println("--Create Live Photo Album--");
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.createAlbumByDataType(vz_strings.DataType.LIVEPHOTO, "AppiumLivePhotoAlbum");
        photosAndVideosView.selectTab(vz_strings.tab_albums);
        photosAndVideosView.openAlbum();
        gridView.tapItem(vz_strings.DataType.LIVEPHOTO);

        String logs = localyticsHelper.getLogs();
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaOpen + " does not exist", localyticsHelper.isExisted(logs, vz_strings.logs_mediaOpen));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaOpen + " is not 1 in logs", localyticsHelper.getCountOf(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaOpen) == 1);
        TestCase.assertTrue(vz_strings.logs_mediaType + " does not exist", localyticsHelper.isExisted(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + "\"" + vz_strings.logs_mediaTypeLivePhoto + "\""));
        TestCase.assertTrue(vz_strings.logs_page + " does not exist", localyticsHelper.isExisted(logs, vz_strings.logs_page + " = " + "\"" + vz_strings.logs_photosVideosAlbums + "\""));
        localyticsHelper.print(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaOpen);
    }
}
