package com.sncr.verizon.appiumtests.vznft.photosandvideos.real;
import com.sncr.verizon.appiumtests.constants.GroupNames;
import org.testng.annotations.Test;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;

import static com.sncr.verizon.appiumtests.constants.vz_strings.ab_btn_Edit;

/**
 * @author leletsn
 *  VZNFT-481: Edit Photos: Add Stickers/step 3: In a Full view
 */
public class LocalyticsPVAllEditPhoto extends BaseTestClass{

	@Test(testName = "VZNFT-481", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.REAL})
  public void testLocalyticsPVAllEditPhoto() throws Exception {

	  homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
	  photosAndVideosView.selectTab(vz_strings.tab_all);
	  baseControlsHelper.clickOnNameLike(vz_strings.name_photo);
	  baseControlsHelper.clickOn(ab_btn_Edit);
	  
	  String logs = localyticsHelper.getLogs();
	  localyticsHelper.print(logs, vz_strings.logs_editPhotos);

	  TestCase.assertTrue("Localytics of " +vz_strings.logs_tagEvent + " is not 1 in logs",
			  localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_editPhotos) == 1);
	  TestCase.assertTrue("Localytics of " +vz_strings.logs_source + " does not exist",
			  localyticsHelper.getPatternMatch(logs, vz_strings.logs_source + " = \"" +vz_strings.logs_photoDetailMenu+ "\"")==1);
	  TestCase.assertTrue("Localytics of "+vz_strings.logs_target+" does not exist",
			  localyticsHelper.getPatternMatch(logs, vz_strings.logs_target + " = \"" +vz_strings.logs_editPhoto+ "\"")==1);
	  }
  }