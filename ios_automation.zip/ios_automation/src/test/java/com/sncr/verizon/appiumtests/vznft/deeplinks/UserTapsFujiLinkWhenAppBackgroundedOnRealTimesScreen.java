//https://jira.synchronoss.net:8443/jira/browse/VZNFT-317
package com.sncr.verizon.appiumtests.vznft.deeplinks;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 06/12/18.
 */
public class UserTapsFujiLinkWhenAppBackgroundedOnRealTimesScreen extends BaseTestClass {

    @Test(testName = "VZNFT-317", groups = {"vznft", GroupNames.DEEPLINKS})
    public void testUserTapsFujiLinkWhenAppBackgroundedOnRealTimesScreen() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_stories);
        photosAndVideosView.openStory10();
        baseControlsHelper.clickOn(vz_strings.story_HeroImage);

        nativeIosAppsView.navigateToFujiCanvasFromMail();

        TestCase.assertTrue("Real time player screen not displayed", baseControlsHelper.getCountByName(vz_strings.button_save) == 1);

        baseControlsHelper.tapOnBackButton();
        TestCase.assertTrue("Hero image not displayed", baseControlsHelper.getCountByName(vz_strings.story_HeroImage) == 1);
    }
}