package com.sncr.verizon.appiumtests.IV.photosandvideos;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class VideoOpenFromHome extends BaseTestClass {

    @Test(testName = "IV-287", groups = {"release", "snapshot", GroupNames.PHOTOS_AND_VIDEOS})
    public void testVideoOpenFromHome() throws Exception {

        homeScreenView.fromHomeClickOnGridCell(vz_strings.name_videoGrid);
        photosAndVideosView.playVideo();
        baseControlsHelper.waitForShow(vz_strings.name_video);

        TestCase.assertTrue("Video is not open",
                baseControlsHelper.getCountByName(vz_strings.name_video) != 0);
    }
}
