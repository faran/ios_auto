//https://jira.synchronoss.net:8443/jira/browse/VZNFT-312
package com.sncr.verizon.appiumtests.vznft.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 17/01/19.
 */
public class FujiWebLinkBackgroundedOnHomeScreen extends BaseTestClass {

    @Test(testName = "VZNFT-312", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI})
    public void testFujiWebLinkBackgroundedOnHomeScreen() throws Exception {

        nativeIosAppsView.navigateToFujiCanvasFromMail();

        TestCase.assertTrue("Fuji screen not displayed", baseControlsHelper.getCountByName(vz_strings.button_exit) == 1);

        baseControlsHelper.tapOnBackButton();
        baseControlsHelper.clickOn(vz_strings.button_yes);
        baseControlsHelper.waitForDismiss(vz_strings.spinner);

        TestCase.assertTrue("Navigation back to cloud app is not possible", baseControlsHelper.getCountByName(vz_strings.verizon_cloud) > 0);
    }
}
