//https://jira.synchronoss.net:8443/jira/browse/VZNFT-335 - Step-4
package com.sncr.verizon.appiumtests.vznft.allFiles;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.HelperUtilities;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 30/10/2018.
 */
public class LocalyticsLivePhotosMediaPlayAllFiles extends BaseTestClass {

    private boolean itemUploaded = false;

    @BeforeMethod
    public void uploadPhoto() throws Exception {
        if(baseControlsHelper.getCountByName(vz_strings.navi_icon) > 0) {
            precondition.uploadLivePhotos(1);
            itemUploaded = true;
        }
    }

    @Test(testName = "VZNFT-335", groups = {"vznft", GroupNames.ALL_FILES})
    public void testLocalyticsLivePhotosMediaPlayAllFiles() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_allFiles);
        allFilesView.clickOnFirstElementOfMobileRepo();

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaPlay);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaPlay + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaPlay) == 1);
        TestCase.assertTrue(vz_strings.logs_mediaType + " does not exist",
                localyticsHelper.isExisted(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + "\"" + vz_strings.logs_mediaTypeLivePhoto + "\""));
    }

    @AfterMethod
    public void deletePhoto() throws Exception {
        if(itemUploaded)
            postconditions.deleteUploadedFiles(0, 0, 1);
        homeScreenView.navigateTo(vz_strings.navi_settings);
        settingsView.setWhatToBackUp(HelperUtilities.setArguments(vz_strings.settings_whatToBackUp_Contacts, vz_strings.settings_whatToBackUp_Photos, vz_strings.settings_whatToBackUp_Videos));

    }
}
