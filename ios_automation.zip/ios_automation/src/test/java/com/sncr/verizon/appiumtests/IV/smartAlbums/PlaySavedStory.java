//IV-125
package com.sncr.verizon.appiumtests.IV.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.SortAndFilter;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.annotations.Test;

public class PlaySavedStory extends BaseTestClass {

    @Test(testName = "IV-125", groups = {"release", GroupNames.SMART_ALBUMS})
    public void testPlaySavedStory() throws Exception {
        precondition.enablePhotoVideoBackup();
        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.setPickWheelFilter(SortAndFilter.SAVED_STORIES);
        if (baseControlsHelper.getCountByNameLike("Saved Story") < 1) {
            preCond();
            homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
            baseControlsHelper.clickOn(vz_strings.tab_all);
        }
        baseControlsHelper.clickOnNameLike(vz_strings.name_savedStory);
        photosAndVideosView.playVideo();
        baseControlsHelper.waitForShowByTypeAndLabel("XCUIElementTypeButton", "Play");
    }

    public void preCond() throws Exception {
        createStory();
        uploadSavedStory();
    }

    public void createStory() throws Exception {
        baseControlsHelper.openContext(vz_strings.context_select);
        gridView.tapItem(vz_strings.DataType.PHOTO);
        baseControlsHelper.openContext(vz_strings.context_createStory);
        baseControlsHelper.waitForShow("Edit scenes");
        baseControlsHelper.clickOn(vz_strings.button_saveIt);
        baseControlsHelper.clearValueOnTextfieldByName("rpai_first_text_field");
        baseControlsHelper.setValuetoTextFieldByName("Temporary", "rpai_first_text_field");
        baseControlsHelper.clickOn(vz_strings.button_save);
        baseControlsHelper.waitForContent();
        baseControlsHelper.waitForDismiss(vz_strings.progressbar);
    }

    public void uploadSavedStory() throws Exception {
        homeScreenView.navigateTo(vz_strings.navi_home);
        homeScreenView.backUpNow();
        photosAndVideosView.checkDownload();
    }
}
