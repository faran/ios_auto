package com.sncr.verizon.appiumtests.IV.photosandvideos.flashbacks;

import com.sncr.verizon.appiumtests.accountdata.GalleryItemExists;
import com.sncr.verizon.appiumtests.accountdata.UploadsItems;
import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.HelperUtilities;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.Ologger;
import junit.framework.TestCase;
import org.testng.annotations.Test;

import static com.sncr.verizon.appiumtests.constants.vz_serverConfigs.photoFileName;

public class FlashbackExists extends GalleryItemExists implements UploadsItems {

    @Test(groups = {"release", "vznft", GroupNames.FLASHBACK_EXISTS})
    public void testFlashBackCheck() throws Exception {
        TestCase.assertTrue(testItemsExist());
    }


    @Override
    public boolean areItemsPresent() throws Exception {
        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_flashbacks);
        return !photosAndVideosView.isNoFlashBackTextPresent();
    }

    @Override
    public void uploadItems() throws Exception {

        Ologger.log.info("No flashbacks present on cloud");
        doWsgGetTokenCall(msisdn, password);

        if (Integer.parseInt(searchFile("name:" + photoFileName)) > 0)
            deleteRepoFile(photoFileName);
        precondition.generateFlashBack(HelperUtilities.setArguments(photoFileName), 0, 0, 1);

        filesToUpload.add(photoFileName);
    }
}
