////https://jira.synchronoss.net:8443/jira/browse/VZNFT-125
package com.sncr.verizon.appiumtests.vznft.publicshare;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class PhotosCopyShareLink extends BaseTestClass {

    @Test(testName = "VZNFT-125", groups = {"vznft", GroupNames.PUBLIC_SHARE})
    public void testPhotosCopyShareLink() throws Exception {


        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        gridView.tapItemInSelectMode(vz_strings.DataType.PHOTO);
        baseControlsHelper.openContext(vz_strings.context_copyShareLink);
        baseControlsHelper.clickOn(vz_strings.button_yesRemindMeNextTime);
        if (baseControlsHelper.getCountByName(vz_strings.button_ok) > 0) {
            baseControlsHelper.clickOn(vz_strings.button_ok);
        }
        baseControlsHelper.waitForDismiss(vz_strings.toast_shareLinkCopied);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.LOGS_SHARE_SEND);

        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SHARE_SEND_CONTENT + " is not 1 in logs", localyticsHelper.getCountOf(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND_CONTENT) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareContentSize + " does not exist", localyticsHelper.isExisted(logs, vz_strings.logs_shareContentSize));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareContentType + " does not exist", localyticsHelper.getCountOf(logs, "\"" + vz_strings.logs_shareContentType + "\"" + " = " + vz_strings.logs_mediaTypePhotos) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareItemShared + " does not exist", localyticsHelper.getCountOf(logs, "\"" + vz_strings.logs_shareItemShared + "\"" + " = " + "1") == 1);

        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SHARE_SEND + " is not 1 in logs", localyticsHelper.isExisted(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND));
        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SUCCESSFUL + " is not 1 in logs", localyticsHelper.getCountOf(logs, vz_strings.LOGS_STATUS + " = " + vz_strings.LOGS_SUCCESSFUL) == 1);

    }
}
