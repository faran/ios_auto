//https://jira.synchronoss.net:8443/jira/browse/VZNFT-486
package com.sncr.verizon.appiumtests.vznft.home;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 07/01/19.
 */
public class VerifyFriendlyMessagesAreNotDisplayedInAppError extends BaseTestClass {

    @Test(testName = "VZNFT-486", groups = {"vznft", GroupNames.HOME})
    public void testVerifyFriendlyMessagesAreNotDisplayedInAppError() throws Exception {

        try {
            settingsView.enableOnlyPhotosAndVideosBackup();
            baseControlsHelper.tapOnBackButton();
            homeScreenView.navigateTo(vz_strings.navi_home);
            nativeIosAppsView.turnOnAirplaneModeThroughSiri();
            homeScreenView.backUpNow();
            baseControlsHelper.clickOn(vz_strings.button_ok);
            String logs = localyticsHelper.getLogs();

            TestCase.assertTrue("Localytics of " + vz_strings.logs_airplane_mode_warning_message + " is not 0 in logs",
                    localyticsHelper.getPatternMatch(logs, vz_strings.logs_airplane_mode_warning_message) == 1);

        } finally {
            nativeIosAppsView.disableAirplaneMode();
            driver().launchApp();
            settingsView.tapOnBackButtonAndSetWhatToBackup(true, 0);
        }
    }
}
