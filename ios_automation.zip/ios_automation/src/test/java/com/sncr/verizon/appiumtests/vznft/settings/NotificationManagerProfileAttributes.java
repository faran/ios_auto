//https://jira.synchronoss.net:8443/jira/browse/VZNFT-551
package com.sncr.verizon.appiumtests.vznft.settings;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 04/12/18.
 */
public class NotificationManagerProfileAttributes extends BaseTestClass {

    @Test(testName = "VZNFT-551", groups = {"vznft", GroupNames.SETTINGS})
    public void testNotificationManagerProfileAttributes() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_settings);
        baseControlsHelper.clickOn(vz_strings.settings_Notification_Manager);
        Thread.sleep(5000);
        settingsView.toggleAllNotificationOptions();
        settingsView.toggleAllNotificationOptions();
        String logs = localyticsHelper.getLogs();

        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaDownload + " is not 1 in logs", localyticsHelper.getPatternMatch(logs, vz_strings.logs_Notification_Flashbacks) == 2);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaDownload + " is not 1 in logs", localyticsHelper.getPatternMatch(logs, vz_strings.logs_Notification_Prints_And_Gifts) == 2);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaDownload + " is not 1 in logs", localyticsHelper.getPatternMatch(logs, vz_strings.logs_Notification_Stories) == 2);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaDownload + " is not 1 in logs", localyticsHelper.getPatternMatch(logs, vz_strings.logs_value_disabled) == 3);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaDownload + " is not 1 in logs", localyticsHelper.getPatternMatch(logs, vz_strings.logs_value_enabled) == 3);
    }
}
