package com.sncr.verizon.appiumtests.vznft.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

import static com.sncr.verizon.appiumtests.constants.vz_strings.logs_mediaTypeSong;

public class MusicAlbumShare extends BaseTestClass {

    @Test(testName = "VZNFT-22", groups = {"vznft", GroupNames.MUSIC})
    public void testMusicAlbumShare() throws Exception {

        homeScreenView.fromHomeClickAt(vz_strings.navi_music);
        musicView.shareMusic();

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagEvent);

        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SHARE_SEND_CONTENT + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND_CONTENT) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareContentSize + " does not exist", localyticsHelper.isExisted(logs, vz_strings.logs_shareContentSize));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareItemShared + "  items size is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareItemShared + "\" = 1") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareContentType + " photo is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareContentType + "\" = " + logs_mediaTypeSong) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_target + " is not 1", localyticsHelper.getPatternMatch(logs, vz_strings.logs_target + " = "
                + "\"" + vz_strings.logs_NotApplicable + "\"") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SHARE_SEND + " is not 1 in logs",
                localyticsHelper.isExisted(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND));
        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SUCCESSFUL + " is not 1 in logs",
                localyticsHelper.getCountOf(logs, vz_strings.LOGS_STATUS + " = " + vz_strings.LOGS_SUCCESSFUL) == 1);
    }
}
