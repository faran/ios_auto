// STEP 1 & 2
package com.sncr.verizon.appiumtests.IV.settings.myaccount;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class ConfirmDeletePage extends BaseTestClass {

    private SoftAssert softAssert = new SoftAssert();

    @Test(testName = "IV-4941", groups = {"release", GroupNames.MANAGE_STORAGE})
    public void testConfirmDeletePage() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_settings);
        String currentQuotaUsage = settingsView.getQuotaUsage();
        baseControlsHelper.waitForDismiss(vz_strings.spinner);
        baseControlsHelper.tapOnBackButton();
        baseControlsHelper.clickOn(vz_strings.my_Account);
        myAccountPage.navigateToDeleteMyAccount();
        deleteMyAccountPage.setParagraph(currentQuotaUsage);
        softAssert.assertTrue(deleteMyAccountPage.isSameQuotaDisplayedAsMangeStorage(currentQuotaUsage),"Quota not same");
        softAssert.assertTrue(deleteMyAccountPage.isParagraphDisplayed(),"Paragraph not displayed");
        deleteMyAccountPage.verifyAllMentionedFeatureDisplayed();
        softAssert.assertTrue(deleteMyAccountPage.getPhotoThumbnailsCount() > 0,"Photo thumbnails not displayed");
        baseControlsHelper.tapOnBackButton();
        softAssert.assertTrue(myAccountPage.isMyAccountPageDisplayed(),"My account page not displayed");
        myAccountPage.navigateToDeleteMyAccount();
        deleteMyAccountPage.clickOnNextButton();
        if(surveyPage.isSurveyScreenDisplayed()){
            softAssert.assertTrue(surveyPage.isSurveyScreenDisplayed(),"Survey screen not displayed");
            surveyPage.selectUnsubscribeOptionAndContinue();
        }
        baseControlsHelper.tapOnBackButton();
        softAssert.assertTrue(deleteMyAccountPage.isDeleteMyAccountPageDisplayed(),"Delete My account page not displayed");
        softAssert.assertAll();
    }
}
