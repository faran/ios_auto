package com.sncr.verizon.appiumtests.IV.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class CloudMusicPlayerQueue extends BaseTestClass {

    @Test(testName = "IV-710", groups = {"release", GroupNames.MUSIC})
    public void testCloudMusicPlayerQueue() throws Exception {


        homeScreenView.navigateTo(vz_strings.navi_music);
        musicView.selectTab(vz_strings.tab_playlists);
        preConditionPl();
        baseControlsHelper.clickOn(vz_strings.view_musicPlaylists);
        preCondition();
        baseControlsHelper.openContext(vz_strings.context_playPlaylist);
        musicView.openPlaylist("On-The-Go");

        TestCase.assertTrue("Song 1 is not being played ? ", baseControlsHelper.getCountByNameContains("playButton.png") > 0);
    }

    private void preConditionPl() throws Exception {

        System.out.println("--Start Preconditions Pl--");
        if (baseControlsHelper.getCountByName(vz_strings.view_musicPlaylists) < 1) {
            musicView.newPl(vz_strings.view_musicPlaylists);
        }
        System.out.println("--End Preconditions Pl--");
    }

    private void preCondition() throws Exception {

        System.out.println("--Start Preconditions--");
        if (baseControlsHelper.getCountByName(vz_strings.view_emptyPlaylist) != 0) {
            musicView.addSongToPlaylist();
        }
        System.out.println("--End Preconditions--");
    }

}