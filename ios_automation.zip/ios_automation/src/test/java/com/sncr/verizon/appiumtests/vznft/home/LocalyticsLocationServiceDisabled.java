//https://jira.synchronoss.net:8443/jira/browse/VZNFT-351 #Step 2 & 3
package com.sncr.verizon.appiumtests.vznft.home;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.driver.BaseDriver;
import com.sncr.verizon.appiumtests.managers.iOSManager;
import junit.framework.TestCase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

import java.lang.invoke.MethodHandles;

/**
 * Created by ssam0003 on 18/09/18.
 */
public class LocalyticsLocationServiceDisabled extends BaseTestClass {
    private final static Logger logger = LogManager.getLogger(MethodHandles.lookup().lookupClass());

    @Test(testName = "VZNFT-351", groups = {"vznft", GroupNames.HOME})
    public void testLocalyticsLocationServiceDisabled() throws Exception {
        try {
            if (nativeIosAppsView.isLocationServiceEnabled() != 0) nativeIosAppsView.toggleLocationServices("off");
            else logger.info("Location services already in disabled state");
            driver().launchApp();
            iOSManager.runAppInBackground(5);
            String logs = localyticsHelper.getLogs();
            localyticsHelper.print(logs, "attr" + " = " + "\"" + vz_strings.logs_location_services + "\"");
            localyticsHelper.print(logs, "value" + " = " + vz_strings.logs_disbled);
            TestCase.assertTrue("Localytics of " + vz_strings.logs_location_services + " does not exist",
                    localyticsHelper.getPatternMatch(logs, "attr" + " = " + "\"" + vz_strings.logs_location_services + "\"") == 1);
            TestCase.assertTrue("Localytics of " + vz_strings.logs_disbled + " does not exist",
                    localyticsHelper.getPatternMatch(logs, "value" + " = " + vz_strings.logs_disbled) == 1);
        } finally {
            BaseDriver.getDriver().terminateApp(vz_strings.BundleIds.VZ_ID);
            if (nativeIosAppsView.isLocationServiceEnabled() != 1) nativeIosAppsView.toggleLocationServices("On");
        }
    }
}
