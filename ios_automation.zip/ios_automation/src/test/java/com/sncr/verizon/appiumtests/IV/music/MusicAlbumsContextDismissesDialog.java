package com.sncr.verizon.appiumtests.IV.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * @author asdr0001 Alex
 * https://jira.synchronoss.net:8443/jira/browse/IV-709
 * Test case completed until If user selects "No" will dismisses the dialog
 */

public class MusicAlbumsContextDismissesDialog extends BaseTestClass {

    @Test(testName = "IV-709", groups = {"release", GroupNames.MUSIC, "release"})
    public void testAlbumViewMultiselectDelete() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_music);
        musicView.selectTab(vz_strings.tab_albums);

        listView.selectFirstItemInSelectMode10();
        baseControlsHelper.openContext(vz_strings.context_delete);

        TestCase.assertTrue(vz_strings.dialog_delete_album, baseControlsHelper.getCountByName(vz_strings.dialog_delete_album) != 0);
        TestCase.assertTrue("Are you sure you want ... ", baseControlsHelper.getCountByName(vz_strings.dialog_message) != 0);

        baseControlsHelper.clickOn(vz_strings.button_no);


    }

}
