package com.sncr.verizon.appiumtests.vznft.photosandvideos.photobook;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class CreatePhotoBook extends BaseTestClass {

    @Test(testName = "VZNFT-566", groups = {"vznft", GroupNames.FUJI, GroupNames.PHOTOBOOK})
    public void testCreatePhotoBook() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        precondition.deleteAllAlbums();
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.createAlbumByDataType(vz_strings.DataType.PHOTO, vz_strings.create_newAlbumName);
        photosAndVideosView.selectTab(vz_strings.tab_albums);
        photosAndVideosView.openAlbum();
        baseControlsHelper.waitForShow(vz_strings.button_smartAlbumPlay);
        baseControlsHelper.openContext(vz_strings.context_createPhotoBook);
        baseControlsHelper.waitForShow(vz_strings.spinner);

        String logs = localyticsHelper.getLogs();

        TestCase.assertTrue("Localytics of " + vz_strings.context_createPhotoBook + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.context_createPhotoBook) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketNumber + "  items size is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucketNumber + "\" = 1") == 1);
    }
}
