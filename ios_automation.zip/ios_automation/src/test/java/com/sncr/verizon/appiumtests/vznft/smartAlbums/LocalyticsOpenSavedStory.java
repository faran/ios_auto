//VZNFT-485 step-5
package com.sncr.verizon.appiumtests.vznft.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.SortAndFilter;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LocalyticsOpenSavedStory extends BaseTestClass {

    @Test(testName = "VZNFT-485", groups = {"vznft", GroupNames.SMART_ALBUMS})
    public void testLocalyticsOpenSavedStory() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.setPickWheelFilter(SortAndFilter.SAVED_STORIES);
        baseControlsHelper.waitForShow(vz_strings.filter_FilteredBySavedStories );
        baseControlsHelper.clickOnNameLike(vz_strings.name_savedStory);
        baseControlsHelper.waitForShow(vz_strings.button_play);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_mediaOpen);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaOpen +" is not 1",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_mediaOpen) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + " is not 1",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + vz_strings.logs_story) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_page + " is not 1",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_page + " = " +"\"" + vz_strings.logs_photosVideosAll + "\"") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_galleryDetail + " is not 1",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_galleryDetail) == 1);
    }
}
