package com.sncr.verizon.appiumtests.IV.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class PhotoBookMixedUnsupportedOnlyPhotosSentToFuji extends BaseTestClass {

    private final int NUM_PHOTOS = 1;

    @Test(testName = "IV-5137", groups = {GroupNames.FUJI, GroupNames.PHOTOBOOK, "release"})
    public void testPhotoBookMixedUnsupportedOnlyPhotosSentToFuji() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.removeAllProductFromCart();
        precondition.deleteAllAlbums();

        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.createAlbumByDataType(vz_strings.DataType.VIDEO, vz_strings.create_newAlbumName);
        photosAndVideosView.addItemsToExistingAlbum(vz_strings.DataType.PHOTO, NUM_PHOTOS);
        photosAndVideosView.selectTab(vz_strings.tab_albums);
        photosAndVideosView.openAlbum();

        baseControlsHelper.openContext(vz_strings.context_createPhotoBook);
        baseControlsHelper.clickOn(vz_strings.button_gotIt);

        baseControlsHelper.waitForDismiss(vz_strings.spinner);

        baseControlsHelper.waitForShowByClassName(vz_strings.XCUITypes.XCUI_COLLECTION);

        int numPhotosPassedToFuji = baseControlsHelper.getCountChildClassInParentClass(vz_strings.XCUITypes.XCUI_CELL, vz_strings.XCUITypes.XCUI_COLLECTION);

        //ignore First icon which is a button to add more images
        numPhotosPassedToFuji = numPhotosPassedToFuji - 1;

        TestCase.assertTrue(numPhotosPassedToFuji == NUM_PHOTOS);
    }
}
