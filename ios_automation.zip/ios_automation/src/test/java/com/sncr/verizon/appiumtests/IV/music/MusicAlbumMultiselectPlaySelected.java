package com.sncr.verizon.appiumtests.IV.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class MusicAlbumMultiselectPlaySelected extends BaseTestClass {

    @Test(testName = "IV-716", groups = {GroupNames.MUSIC, "release"})
    public void testMusicAlbumMultiselectPlaySelected() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_music);
        musicView.selectTab(vz_strings.tab_albums);

        listView.selectFirstItemInSelectMode10();
        baseControlsHelper.openContext(vz_strings.context_playSelected);
        baseControlsHelper.waitForShow(vz_strings.button_pauseButton);

        TestCase.assertTrue("Selected Album did not play after selecting \"Play Selected\" in context menu",
                baseControlsHelper.getCountByName(vz_strings.button_pauseButton) > 0);
    }
}
