package com.sncr.verizon.appiumtests.vznft.photosandvideos.real;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import org.testng.annotations.Test;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;

/**
 * VZNFT-480: Edit Photos-Create Collage
 *
 * @author leletsn
 */
public class LocalyticsPVAllCreateCollage extends BaseTestClass {

    @Test(testName = "VZNFT-480", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.REAL})
    public void testLocalyticsPVAllCreateCollage() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        gridView.tapItemsInMultiSelectModeUniversal(2, vz_strings.DataType.PHOTO);
        baseControlsHelper.openContext(vz_strings.context_createcollage);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_editPhotos);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_tagEvent + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_editPhotos) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_source + " does not exits",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_source + " = \"" + vz_strings.logs_photoMultiSelectMenu + "\"") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_target + " does not exits",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_target + " = " + vz_strings.logs_collage) == 1);
    }
}