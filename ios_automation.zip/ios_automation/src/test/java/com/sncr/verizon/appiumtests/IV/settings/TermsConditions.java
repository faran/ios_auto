package com.sncr.verizon.appiumtests.IV.settings;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class TermsConditions extends BaseTestClass {

    @Test(testName = "IV-95", groups = {"release", GroupNames.SETTINGS})
    public void testTermsConditions() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_settings);
        baseControlsHelper.clickOn(vz_strings.settings_about);
        baseControlsHelper.clickOn(vz_strings.about_tc);
        TestCase.assertTrue("Terms & Conditions headings not found", baseControlsHelper.getCountByName(vz_strings.about_tc) != 0);

    }
}
