package com.sncr.verizon.appiumtests.wl.provisioning;

import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class WLLogin extends BaseTestClass {

    @Parameters({"mdn", "mdnpass"})
    @Test(groups = {"release", "snapshot", "wl"})
    public void testWLLogin(@Optional("18009000142") String mdn, @Optional("p@ssword") String mdnpass) throws Exception {

        if (baseControlsHelper.getCountByName(vz_strings.navi_icon) != 0) {
            System.out.println("Already logged in");
        } else {
            System.out.println("Whitelabel Provisioning...");
            provisioningView.buttonGetStarted();
            provisioningView.enterUserName(mdn);
            provisioningView.enterPassword(mdnpass);
            provisioningView.clickLogin();

            baseControlsHelper.waitForShow(vz_strings.navi_icon);
        }
    }
}
