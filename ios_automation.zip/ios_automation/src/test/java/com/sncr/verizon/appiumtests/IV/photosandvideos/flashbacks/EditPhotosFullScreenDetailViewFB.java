//IV-4275 step 3 - part 3/5
package com.sncr.verizon.appiumtests.IV.photosandvideos.flashbacks;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.HelperUtilities;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

import java.lang.invoke.MethodHandles;
import java.security.acl.Group;

import static com.sncr.verizon.appiumtests.constants.vz_serverConfigs.photoFileName;
import static com.sncr.verizon.appiumtests.constants.vz_strings.ab_btn_Edit;

public class EditPhotosFullScreenDetailViewFB extends BaseTestClass {

    @Test(testName = "IV-4275", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.REAL, GroupNames.FLASHBACKS})
    public void testEditPhotosFullScreenDetailViewFB() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_flashbacks);
        gridView.tapItem(vz_strings.DataType.PHOTO);
        baseControlsHelper.clickOn(ab_btn_Edit);

        String pageTitle = baseControlsHelper.getNameByIndexfromClassName(0, "XCUIElementTypeNavigationBar");
        TestCase.assertTrue("Edit Photo view is not open", pageTitle.equals("Edit Photo"));
    }
}
