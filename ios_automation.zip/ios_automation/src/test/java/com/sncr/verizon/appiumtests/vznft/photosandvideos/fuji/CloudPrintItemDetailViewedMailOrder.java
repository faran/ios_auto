//https://jira.synchronoss.net:8443/jira/browse/VZNFT-247
//https://jira.synchronoss.net:8443/jira/browse/VZNFT-224
package com.sncr.verizon.appiumtests.vznft.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class CloudPrintItemDetailViewedMailOrder extends BaseTestClass {

    @Test(testName = "VZNFT-247", groups = {"vznft", GroupNames.FUJI, GroupNames.PHOTOS_AND_VIDEOS})
    public void testCloudPrintItemDetailViewedMailOrder() throws Exception {

        homeScreenView.navigateTo(vz_strings.home_photsAndVideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.removeAllProductFromCart();
        gridView.tapItemsInMultiSelectModeUniversal(1, vz_strings.DataType.PHOTO);
        photosAndVideosView.clickPrintsAndGift(vz_strings.context_printAndGifts, vz_strings.context_icon_printShop);

        baseControlsHelper.waitForDismiss(vz_strings.spinner);
        baseControlsHelper.clickOn(vz_strings.button_getItDelievred);
        baseControlsHelper.clickOn(vz_strings.printsAndGifts_HomeAndOffice);
        baseControlsHelper.scroll(vz_strings.printsAndGifts_Mousepad, "down");
        baseControlsHelper.clickOn(vz_strings.printsAndGifts_Mousepad);
        baseControlsHelper.clickOn(vz_strings.photoBucket_infoIcon);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_photoBucketCloudItemDetail);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketDeliveryType + " is not 1",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucketDeliveryType + "\"" + " = " +
                        "\"" + vz_strings.logs_photoBucketMailOrder + "\"") == 1);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketItemBrowsed + " is not 1",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucketItemBrowsed + "\"" + " = " +
                    "\"" + vz_strings.logs_photobucketItem_PhotoMousePad + "\"") == 1);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_source + " is not 1",
                localyticsHelper.getPatternMatch(logs, "(^|[ ])" + vz_strings.logs_source + " = " +
                        "\"" + vz_strings.logs_photoBucketSource_ProductList + "\"") == 1);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketPickupLocation + " is not 1",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucketPickupLocation + "\"" + " = " +
                        "\"" + vz_strings.logs_NotApplicable + "\"" ) == 1);

    }
}
