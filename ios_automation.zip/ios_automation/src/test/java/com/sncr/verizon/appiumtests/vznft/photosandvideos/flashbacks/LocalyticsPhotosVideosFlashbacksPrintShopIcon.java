package com.sncr.verizon.appiumtests.vznft.photosandvideos.flashbacks;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import org.testng.annotations.Test;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;

/**
 * @author leletsn
 * VZNFT-237
 */

public class LocalyticsPhotosVideosFlashbacksPrintShopIcon extends BaseTestClass {

    @Test(testName = "VZNFT-237", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI, GroupNames.FLASHBACKS})
    public void testLocalyticsPhotosVideosFlashbacksPrintShopIcon() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_flashbacks);
        photosAndVideosView.accessPrintShopFromIcon();

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_photoBucketEntry);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketEntry + " does not exist",
                localyticsHelper.isExisted(logs, vz_strings.logs_photoBucketEntry));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketEntry + " is not 1 in logs",
                localyticsHelper.getCountOf(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_photoBucketEntry) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketEntryPoint + " does not exist",
                localyticsHelper.isExisted(logs, "\"" + vz_strings.logs_photoBucketEntryPoint + "\" = \"" + vz_strings.logs_photosVideosFlashBacksNavigationBar + "\""));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketNumber + " does not exist",
                localyticsHelper.isExisted(logs, vz_strings.logs_photoBucketNumber));

    }
}

