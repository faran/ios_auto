//VZNFT-109 #Step 5
package com.sncr.verizon.appiumtests.vznft.home;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;


public class LocalyticsStoriesOpenHome extends BaseTestClass {

    @Test(testName = "VZNFT-109", groups = {"vznft", GroupNames.HOME})
    public void testLocalyticsStoriesOpenHome() throws  Exception{

        homeScreenView.navigateTo(vz_strings.navi_home);
        homeScreenView.clickOnStory(vz_strings.carousel_story);

        //Click on first available photo
        baseControlsHelper.clickOnNameContainsAndVisibile("Photo ");
        String logs = localyticsHelper.getLogs();
        TestCase.assertTrue("Localytics of " + vz_strings.logs_storyDetail + " is not in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_storyDetail ) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaOpen+ " is not in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaOpen) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + " is not in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + vz_strings.logs_mediaTypePhoto) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_page + " is not in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_page + " = " + "\"" + vz_strings.logs_photosVideosStories + "\"") == 1);

        localyticsHelper.print(logs, vz_strings.logs_mediaOpen);
        homeScreenView.backToHome();
    }
}
