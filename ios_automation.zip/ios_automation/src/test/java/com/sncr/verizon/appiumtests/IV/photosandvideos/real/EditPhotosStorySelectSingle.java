///IV-4708 steps 1,2,3 part 4/5, 4
package com.sncr.verizon.appiumtests.IV.photosandvideos.real;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

import static com.sncr.verizon.appiumtests.constants.vz_strings.ab_btn_Edit;

public class EditPhotosStorySelectSingle extends BaseTestClass {

    @Test(testName = "IV-4708", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.REAL})
    public void testEditPhotosStorySelectSingle() throws Exception{

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_stories);
        photosAndVideosView.openStory10();
        baseControlsHelper.waitForContent();
        gridView.tapItemInSelectMode(vz_strings.DataType.PHOTO);
        baseControlsHelper.openContext(vz_strings.context_editPhoto);

        String pageTitle = baseControlsHelper.getNameByIndexfromClassName(0, "XCUIElementTypeNavigationBar");
        TestCase.assertTrue("Edit photo view is not open", pageTitle.equals("Edit Photo"));
    }
}
