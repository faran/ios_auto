package com.sncr.verizon.appiumtests.IV.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class CreateStroyOptionShouldNotBeSeen extends BaseTestClass {

    @Test(testName = "IV-114", groups = {"release", GroupNames.SMART_ALBUMS})
    public void testCreateStroyOptionShouldNotBeSeen() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_allFiles);
        baseControlsHelper.clickOn(vz_strings.folder_mobile);
        baseControlsHelper.clickOn(vz_strings.Vz_configs.DEVICE_NAME);
        listView.selectFirstItemInSelectMode10();
        baseControlsHelper.openContext(null);

        TestCase.assertTrue("Create Story present ?", baseControlsHelper.getCountByName(vz_strings.context_createStory) == 0);
    }
}