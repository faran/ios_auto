//https://jira.synchronoss.net:8443/jira/browse/VZNFT-112
package com.sncr.verizon.appiumtests.vznft.backup;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.driver.BaseDriver;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 07/12/18.
 */
public class BackupSuccess extends BaseTestClass {

    @Test(testName = "VZNFT-112", groups = {"vznft", GroupNames.BACKUP})
    public void testBackupSuccess() throws Exception {

        try {
            settingsView.enableOnlyPhotosBackup();
            nativeIosAppsView.capturePhotos(1);
            driver().launchApp();
            homeScreenView.backUp();
            String logs = localyticsHelper.getLogs();
            localyticsHelper.print(logs, vz_strings.logs_tagEvent);
            TestCase.assertTrue("Localytics of " + vz_strings.logs_backup_complete + " is not 1 in logs", localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_backup_complete) == 1);
            TestCase.assertTrue("Localytics of " + vz_strings.LOGS_STATUS + " is not 1 in logs", localyticsHelper.getPatternMatch(logs, vz_strings.LOGS_STATUS + " = " + vz_strings.LOGS_SUCCESSFUL) == 1);
            TestCase.assertTrue("Localytics of " + vz_strings.logs_media + " is not 1 in logs", localyticsHelper.getPatternMatch(logs, vz_strings.logs_backup_type + " = " + vz_strings.logs_media) == 1);
        } finally {
            settingsView.tapOnBackButtonAndSetWhatToBackup(true, 0);
        }
    }
}
