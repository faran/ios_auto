//https://jira.synchronoss.net:8443/jira/browse/IV-2817
package com.sncr.verizon.appiumtests.IV.home;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

import static com.sncr.verizon.appiumtests.constants.vz_strings.tab_nowPlaying;
import static com.sncr.verizon.appiumtests.constants.vz_strings.verizon_cloud;

public class PlaySongFromHomeScreen extends BaseTestClass {

    @Test(testName = "IV-2817", groups = {"release", GroupNames.HOME})
    public void testPlaySongFromHomeScreen() throws Exception {

        homeScreenView.fromHomeClickOnGridCell(vz_strings.name_musicGrid);
        TestCase.assertTrue("Are we not at home music screen?",
                baseControlsHelper.isSelected(tab_nowPlaying));

        homeScreenView.navigateTo(vz_strings.navi_home);
        TestCase.assertTrue("Are we back at home screen?",
                baseControlsHelper.getCountByName(verizon_cloud) > 0);
    }
}
