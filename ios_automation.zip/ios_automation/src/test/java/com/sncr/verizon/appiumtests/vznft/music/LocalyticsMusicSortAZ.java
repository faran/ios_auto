/**
 * VZNFT-29 - Step 5
 * */
package com.sncr.verizon.appiumtests.vznft.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * VZNFt-29 Music - tagScreen: Music Songs
 *
 * @author leletsn
 */

public class LocalyticsMusicSortAZ extends BaseTestClass{

    @Test(testName = "VZNFT-29", groups = {"vznft", GroupNames.MUSIC})
    public void testLocalyticsMusicSortAZ() throws Exception {

      precondition.clickMusicHeadFromHome();
      musicView.selectTab(vz_strings.tab_songs);
      baseControlsHelper.openContext(vz_strings.context_sort);
      baseControlsHelper.setPickerValue(vz_strings.sort_AtoZ);

      String logs = localyticsHelper.getLogs();
      localyticsHelper.print(logs, vz_strings.logs_sortMedia);

      TestCase.assertTrue("Localytics of " + vz_strings.logs_tagEvent + " is not 1 in logs",
              localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_sortMedia) == 1);

      TestCase.assertTrue("Localytics of " + vz_strings.logs_sortOption + " is not 1 in logs",
              localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_sortOption + "\" = " + "\"" + vz_strings.logs_sortAtoZ + "\"") == 1);


    }
}
