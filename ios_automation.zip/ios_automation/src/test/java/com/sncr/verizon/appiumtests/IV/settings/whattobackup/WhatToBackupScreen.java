//https://jira.synchronoss.net:8443/jira/browse/IV-2343
package com.sncr.verizon.appiumtests.IV.settings.whattobackup;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.HelperUtilities;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 17/05/18.
 */
public class WhatToBackupScreen extends BaseTestClass {

    @Test(testName = "IV-2343", groups = {"release", GroupNames.SETTINGS, GroupNames.WHAT_TO_BACKUP})
    public void testWhatToBackupScreen() throws Exception {
        homeScreenView.navigateTo(vz_strings.navi_settings);
        settingsView.setWhatToBackUp(HelperUtilities.setArguments("", vz_strings.settings_whatToBackUp_Photos));
        TestCase.assertEquals("Background photo backup option not displayed", true, baseControlsHelper.isVisible(vz_strings.settings_WhatToBackUp_BackGroundPhotoBackUp));
        TestCase.assertEquals("Toggle is not enabled", "1", baseControlsHelper.getValueByIndexfromClassName(3, "XCUIElementTypeSwitch"));
        TestCase.assertEquals(vz_strings.settings_WhatToBackUp_CloudBackupPhotosText + " not displayed",
                vz_strings.settings_WhatToBackUp_CloudBackupPhotosText, baseControlsHelper.getTextByNameContains("Let the Cloud"));
    }
}
