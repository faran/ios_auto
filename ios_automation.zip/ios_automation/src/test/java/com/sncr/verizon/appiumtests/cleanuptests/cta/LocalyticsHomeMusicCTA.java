/*
 * VZNFT-19 - Step 4
 * */
package com.sncr.verizon.appiumtests.cleanuptests.cta;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.controls.Ologger;
import junit.framework.TestCase;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class LocalyticsHomeMusicCTA extends BaseTestClass {

    @BeforeMethod(groups = {"vznft", GroupNames.CTA})
    public void cleanUpMusics() throws Exception {
        if (doATPAuthCall(msisdn)) {
            if (getMediaCount(ContentType.MUSIC) > 0) {
                if (deleteAllFiles(ContentType.MUSIC)) {
                    Ologger.log.info("All musics cleared");
                    driver().launchApp();
                }
            }
        }
    }

    @Test(testName = "VZNFT-19", groups = {"vznft", GroupNames.CTA})
    public void testLocalyticsHomeMusicCTA() throws Exception {

        if (!baseControlsHelper.isClickable(driver().findElementByAccessibilityId(vz_strings.home_cta_music))) {
            baseControlsHelper.scroll(vz_strings.home_cta_music, "down");
        }
        homeScreenView.fromHomeClickAt(vz_strings.home_cta_music);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagScreen);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaTypeMusic + " does not exists",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_mediaTypeMusic + " " + vz_strings.logs_CTA) == 1);
    }
}
