//VZNFT-4 STEP-3
package com.sncr.verizon.appiumtests.vznft.publicshare;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.servercalls.VZServerRequests;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class ShareSendContentEventForDocumentOpenCopyShareLink extends BaseTestClass {
    private SoftAssert softAssert = new SoftAssert();

    @BeforeMethod(groups = {"vznft", GroupNames.DOCUMENTS})
    public void uploadDocuments() throws Exception {
        if (doWsgGetTokenCall(msisdn, password)) {
            if (getMediaCount(ContentType.DOCUMENTS) < 1) {
                VZServerRequests server = new VZServerRequests();
                server.uploadFile(vz_strings.DataType.DOCUMENT);
            }
        }
    }

    @Test(testName = "VZNFT-4", groups = {"vznft", GroupNames.DOCUMENTS})
    public void testShareSendContentEventForDocumentOpenCopyShareLink() throws Exception {
        String logs;

        homeScreenView.navigateTo(vz_strings.navi_documents);
        listView.selectFirstItem10();

        logs = localyticsHelper.getLogs();
        softAssert.assertTrue(localyticsHelper.getPatternMatch(logs,
                vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaOpen) == 1, "Localytics of " + vz_strings.logs_mediaOpen + " is not in logs");
        baseControlsHelper.openContext(vz_strings.context_copyShareLink);

        logs = localyticsHelper.getLogs();

        softAssert.assertTrue(localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND_CONTENT) == 1,
                vz_strings.LOGS_SHARE_SEND_CONTENT + " is not 1 in logs");
        softAssert.assertTrue(localyticsHelper.getPatternMatch(logs, vz_strings.logs_shareContentSize) == 1,
                "Localytics of " + vz_strings.logs_shareContentSize + " does not exist");
        softAssert.assertTrue(localyticsHelper.getPatternMatch(logs,
                "\"" + vz_strings.logs_shareContentType + "\"" + " = " + vz_strings.logs_mediaTypeDocument) == 1,
                "Localytics of " + vz_strings.logs_shareContentType + " is not 1 in logs");
        softAssert.assertTrue(localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareItemShared + "\"" + " = " + "1") == 1,
                "Localytics of " + vz_strings.logs_shareItemShared + " does not exist");
        softAssert.assertTrue(localyticsHelper.getPatternMatch(logs, vz_strings.logs_target + " = "
                + "\"" + vz_strings.logs_NotApplicable + "\"") == 1, "Localytics of " + vz_strings.logs_target + " is not 1");

        softAssert.assertTrue(localyticsHelper.isExisted(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND),
                vz_strings.LOGS_SHARE_SEND + " is not 1 in logs");
        softAssert.assertTrue(localyticsHelper.getPatternMatch(logs, vz_strings.LOGS_STATUS + " = " + vz_strings.LOGS_SUCCESSFUL) == 1,
                "Localytics of " + vz_strings.LOGS_SUCCESSFUL + " is not 1 in logs");
        softAssert.assertAll();
    }
}
