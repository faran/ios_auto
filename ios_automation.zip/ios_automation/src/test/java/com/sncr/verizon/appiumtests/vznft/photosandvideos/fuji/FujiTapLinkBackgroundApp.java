//https://jira.synchronoss.net:8443/jira/browse/VZNFT-310
package com.sncr.verizon.appiumtests.vznft.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.EmailAndMessageUtils;
import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.managers.iOSManager;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class FujiTapLinkBackgroundApp extends BaseTestClass {

    @Test(testName = "VZNFT-310", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI})
    public void testFujiTapLinkBackgroundApp() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.removeAllProductFromCart();

        gridView.tapItemsInMultiSelectModeUniversal(1, vz_strings.DataType.PHOTO);
        photosAndVideosView.selectAllAddToCart();

        iOSManager.runAppInBackground(-1);
        EmailAndMessageUtils.deleteAllMails();
        EmailAndMessageUtils.sendEmail("vz", vz_strings.Deeplinks.PRINTS_AND_GIFTS_CANVAS, EmailAndMessageUtils.username);

        nativeIosAppsView.openMailBox();
        baseControlsHelper.clickOnNameContains(vz_strings.Deeplinks.PRINTS_AND_GIFTS_CANVAS);
        baseControlsHelper.clickOn(vz_strings.Deeplinks.PRINTS_AND_GIFTS_CANVAS);

        TestCase.assertTrue("text CANVAS not found after clicking deep link", baseControlsHelper.getCountByName(vz_strings.printsAndGifts_Canvas) == 1);
    }

}
