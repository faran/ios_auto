//https://jira.synchronoss.net:8443/jira/browse/VZNFT-72/step-12
//https://jira.synchronoss.net:8443/jira/browse/VPCIOS-7224
package com.sncr.verizon.appiumtests.vznft.albums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by kram0003 on 23/02/18.
 */
public class AlbumSelectAllDownload extends BaseTestClass {

    @Test(testName = "VZNFT-72", groups = {"vznft", GroupNames.ALBUMS})
    public void albumSelectAllDownload() throws Exception {

        homeScreenView.fromHomeClickAt(vz_strings.navi_Photosandvideos);
        precondition.deleteAllAlbums();
        photosAndVideosView.createAlbum(vz_strings.create_newAlbumName);
        Thread.sleep(2000);
        if (photosAndVideosView.ifAnyAlbumExists()) {
            gridView.selectAllAlbums();
            baseControlsHelper.openContext(vz_strings.context_download);
        }
        photosAndVideosView.checkDownload();

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagEvent);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaDownload + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaDownload) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + " Media type is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\" = " + vz_strings.logs_album) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + " Media type is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\" = " + vz_strings.logs_mediaTypePhotos) == 1);
    }
}
