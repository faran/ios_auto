package com.sncr.verizon.appiumtests.IV.smartAlbums;

import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;

public class RealTimeAppPromptOtherNotifications extends BaseTestClass {

    //Deprecated from 16.5.16
    public void testRealTimeAppPromptOtherNotifications() throws Exception {


        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_stories);

        TestCase.assertTrue("Notifications missing", baseControlsHelper.getCountByName("Enjoy your Stories even more with RealTimes! Tap here to download the free app that works with Cloud! ") != 0);

    }
}