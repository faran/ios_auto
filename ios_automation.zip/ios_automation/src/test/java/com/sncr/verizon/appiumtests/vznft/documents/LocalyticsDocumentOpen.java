//VZNFT-3 #Step 2,3 //VZNFT-109 Step2
package com.sncr.verizon.appiumtests.vznft.documents;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LocalyticsDocumentOpen extends BaseTestClass {

    @Test(testName="VZNFT-3", groups = {"vznft", GroupNames.DOCUMENTS})
    public void testLocalyticsDocumentOpen() throws Exception {

        homeScreenView.fromHomeClickAt(vz_strings.home_documents);
        listView.selectFirstItem10();

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_mediaOpen);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaOpen + " is not in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaOpen) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + " is not in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + vz_strings.logs_mediaTypeDocument) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_page + " is not in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_page + " = " + "\"" + vz_strings.logs_allDocuments + "\"") == 1);
    }
}
