/**
 * VZNFT-140 Step/Scenario 2
 * */
package com.sncr.verizon.appiumtests.vznft.photosandvideos.real;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class RealTimesViewCarousel extends BaseTestClass{

    @Test(testName = "VZNFT-140", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.REAL})
    public void testRealTimesViewCarousel() throws Exception {

        homeScreenView.clickOnStory(vz_strings.carousel_story);
        baseControlsHelper.clickOn(vz_strings.button_smartAlbumPlay);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagScreen);

        TestCase.assertTrue(vz_strings.logs_mediaOpen + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_realtimeView) == 1);
    }
}
