//IV-702
package com.sncr.verizon.appiumtests.IV.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class MediaPlayerQueueSelectContextualMenuOptions extends BaseTestClass {

    @Test(testName = "IV-702", groups = {"release", GroupNames.MUSIC, GroupNames.CONTEXT_MENU})
    public void testMeidaPlayerQueueSelectContextualMenuOptions() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_music);
        musicView.selectTab(vz_strings.tab_playlists);
        precondition.removeAllFavorites(vz_strings.DataType.MUSIC);
        musicView.selectTab(vz_strings.tab_songs);
        Thread.sleep(2000);
        listView.selectFirstItem10();
        baseControlsHelper.openContext(vz_strings.context_showQueue);
        baseControlsHelper.openContext(vz_strings.context_select);
        Thread.sleep(2000);
        listView.selectFirstItem10();

        baseControlsHelper.openContext(null);

        TestCase.assertTrue("Options missing ", contextualMenu.verifyOptions(vz_strings.DataType.MUSIC,
                vz_strings.view_musicPlayerQueue, false));
    }
}
