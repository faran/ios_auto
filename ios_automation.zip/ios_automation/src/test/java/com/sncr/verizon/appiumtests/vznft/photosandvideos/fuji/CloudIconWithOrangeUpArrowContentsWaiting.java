//https://jira.synchronoss.net:8443/jira/browse/VZNFT-124
package com.sncr.verizon.appiumtests.vznft.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.driver.BaseDriver;
import junit.framework.TestCase;
import org.testng.annotations.Test;

import static com.sncr.verizon.appiumtests.constants.vz_serverConfigs.screenshotPath;

/**
 * Created by ssam0003 on 13/12/18.
 */
public class CloudIconWithOrangeUpArrowContentsWaiting extends BaseTestClass {
    String path = testDataDirectory + screenshotPath;
    String expectedImage = path + "content_wait.png";
    String actualImage = path + "content_wait_icon.png";

    @Test(testName = "VZNFT-124", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI})
    public void testCloudIconWithOrangeUpArrowContentsWaiting() throws Exception {
        try {
            settingsView.enableOnlyPhotosBackup();
            nativeIosAppsView.capturePhotos(1);
            driver().launchApp();
            homeScreenView.captureContentWaitIcon(path, "png", "content_wait_icon");
            TestCase.assertTrue(!baseControlsHelper.compareImageByBlinkDiff(0.1, expectedImage, actualImage).contains("FAIL"));
            homeScreenView.backUp();
            String logs = localyticsHelper.getLogs();
            TestCase.assertTrue("Localytics of " + vz_strings.logs_homeScreenBackupIconClicked + " does not exist", localyticsHelper.getPatternMatch(logs, vz_strings.logs_homeScreenBackupIconClicked) == 1);
            TestCase.assertTrue("Localytics of " + vz_strings.logs_button_state + " does not exist", localyticsHelper.getPatternMatch(logs, vz_strings.logs_button_state + " = " + vz_strings.logs_waiting) == 1);
        } finally {
            settingsView.tapOnBackButtonAndSetWhatToBackup(true, 0);
            baseControlsHelper.tapOnBackButton();
            homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
            photosAndVideosView.selectTab(vz_strings.tab_all);
            gridView.tapItemInSelectMode(vz_strings.DataType.PHOTO);
            gridView.tapContextDelete();
            baseControlsHelper.clickOn(vz_strings.button_yes);
            baseControlsHelper.waitForShow(vz_strings.toast_itemDeleted);
            Thread.sleep(2000);
        }
    }
}
