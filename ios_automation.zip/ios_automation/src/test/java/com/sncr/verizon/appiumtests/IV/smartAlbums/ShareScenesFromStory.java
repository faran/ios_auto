//IV-137
package com.sncr.verizon.appiumtests.IV.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class ShareScenesFromStory extends BaseTestClass {

    @Test(testName = "IV-137", groups = {"release", GroupNames.SMART_ALBUMS})
    public void testShareScenesFromStory() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_stories);
        photosAndVideosView.openStory10();
        gridView.tapItemsInSelectMode();
        baseControlsHelper.openContext(vz_strings.context_share);
        baseControlsHelper.clickOn(vz_strings.button_yesRemindMeNextTime);
        baseControlsHelper.waitForDismiss(vz_strings.toast_creatingSocialShareLink);
        baseControlsHelper.waitForShow("Cancel");

        TestCase.assertTrue("Message not seen", baseControlsHelper.getCountByName("Message") > 0);

    }
}
