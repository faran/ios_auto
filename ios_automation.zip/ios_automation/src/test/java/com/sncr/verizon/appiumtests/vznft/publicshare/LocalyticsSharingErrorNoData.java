//https://jira.synchronoss.net:8443/jira/browse/VZNFT-208
package com.sncr.verizon.appiumtests.vznft.publicshare;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.driver.BaseDriver;
import junit.framework.TestCase;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class LocalyticsSharingErrorNoData extends BaseTestClass {

    @Test(testName = "VZNFT-208", groups = {"vznft", GroupNames.PUBLIC_SHARE})
    public void testLocalyticsSharingErrorNoData() throws Exception {

        nativeIosAppsView.turnOnAirplaneModeThroughSiri();
        //Bring app to foreground
        BaseDriver.getDriver().activateApp(vz_strings.BundleIds.VZ_ID);
        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        gridView.tapItemsInMultiSelectModeUniversal(1, vz_strings.DataType.PHOTO);
        baseControlsHelper.openContext(vz_strings.context_share);
        baseControlsHelper.clickOn(vz_strings.button_yesRemindMeNextTime);

        baseControlsHelper.waitForShowByClassName(vz_strings.XCUITypes.XCUI_ALERT);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_appError);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_appError + " is not 1",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_appError) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_message + " is not 1",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_NoConnection_generic_message) == 1);
    }

    @AfterMethod(alwaysRun = true)
    public void disableAirPlaneMode() throws Exception {
        nativeIosAppsView.disableAirplaneMode();
    }

}
