package com.sncr.verizon.appiumtests.IV.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class SaveSysGenStoryToAlbumFromScenes extends BaseTestClass {

    @Test(testName = "IV-2242", groups = {"release", GroupNames.SMART_ALBUMS})
    public void testSavedSystemGeneratedStoryToAnAlbum() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_albums);
        precondition.deleteAllAlbums();
        photosAndVideosView.selectTab(vz_strings.tab_stories);
        photosAndVideosView.openStory10();
        baseControlsHelper.openContext(vz_strings.context_saveAsAlbum);
        baseControlsHelper.waitForShow(vz_strings.toast_storySavesToAlbums);
        baseControlsHelper.tapOnBackButton();
        photosAndVideosView.selectTab(vz_strings.tab_albums);

        TestCase.assertTrue("No items",
                baseControlsHelper.getCountByName("Photos albums folder") > 0);
    }
}
