//https://jira.synchronoss.net:8443/jira/browse/IV-94/Step-1
package com.sncr.verizon.appiumtests.IV.settings;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by kram0003 on 05/04/18.
 */
public class SettingsScreen extends BaseTestClass {

    @Test(testName = "IV-94", groups = {"release", GroupNames.SETTINGS})
    public void settingScreen() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_settings);
        TestCase.assertTrue( "Settings page items are not available", settingsView.elementVisibleSettings(vz_strings.navi_settings));
    }
}
