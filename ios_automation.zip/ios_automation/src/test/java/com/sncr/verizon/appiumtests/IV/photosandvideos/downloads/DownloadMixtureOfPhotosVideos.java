package com.sncr.verizon.appiumtests.IV.photosandvideos.downloads;
import com.sncr.verizon.appiumtests.constants.GroupNames;
import org.testng.annotations.Test;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
/** @author leletsn
 * IV-860: DownloadMixtureOfPhotosVideos
 */
public class DownloadMixtureOfPhotosVideos extends BaseTestClass{

	@Test(testName = "IV-860", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.DOWNLOADS})
	   public void testDownloadMixtureOfPhotosVideos() throws Exception {

		   homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
		   photosAndVideosView.selectTab(vz_strings.tab_all);
		   baseControlsHelper.openContext(vz_strings.context_select);
		   gridView.tapItems();
		   baseControlsHelper.openContext(vz_strings.context_download);
		   photosAndVideosView.checkDownload();
		   Thread.sleep(1000);
		   TestCase.assertTrue("Download still in progress", baseControlsHelper.getCountByName(vz_strings.progressbar)==0);
	}
}