package com.sncr.verizon.appiumtests.IV.photosandvideos;

import com.sncr.verizon.appiumtests.accountdata.GalleryItemExists;
import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.Ologger;
import com.sncr.verizon.appiumtests.accountdata.UploadsItems;
import com.sncr.verizon.appiumtests.servercalls.VZServerRequests;
import junit.framework.TestCase;
import org.testng.annotations.Test;

import java.util.ArrayList;

/**
 * Check if photos are present on homescreen
 * if no photos are present, upload photos.
 * Delete uploaded files after suite is completed.
 */
public class PhotoExists extends GalleryItemExists implements UploadsItems {

    /**
     * Uploads two photos
     * retrieves files to upload from path declared in getFilesToUpload method.
     * Stores uploaded files in arrayList filesToUpload so they can later be deleted.
     *
     * @throws Exception
     * @see com.sncr.verizon.appiumtests.controls.Preconditions#createAndUploadPhotosToCloud(int)
     * @see VZServerRequests#uploadFiles(vz_strings.DataType, ArrayList)
     */
    @Override
    public void uploadItems() throws Exception {

        if (doWsgGetTokenCall(msisdn, password)) {
            filesToUpload.addAll(precondition.createAndUploadPhotosToCloud(2));
        }
    }

    @Test(groups = {"vznft", "snapshot", "release", GroupNames.PHOTO_EXISTS})
    public void testPhotosExist() throws Exception {
        TestCase.assertTrue(testItemsExist());
    }

    /**
     * Check if two photos are present on the homescreen
     *
     * @return true if items are present, false otherwise
     * @throws Exception
     */
    @Override
    public boolean areItemsPresent() throws Exception {

        if (baseControlsHelper.getCountByName(vz_strings.text_photosAndVideos) == 0) {
            baseControlsHelper.swipe("up");
            Thread.sleep(2000);
        }

        return baseControlsHelper.getCountByNameLike(vz_strings.name_photoGrid) >= 2;
    }
}
