package com.sncr.verizon.appiumtests.IV.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class NamingUserCreatedPlaylistInvalid extends BaseTestClass {

    @Test(testName = "IV-703", groups = {"release", GroupNames.MUSIC})
    public void testNamingUserCreatedPlaylist() throws Exception {


        homeScreenView.navigateTo(vz_strings.navi_music);
        musicView.selectTab(vz_strings.tab_playlists);
        baseControlsHelper.openContext(vz_strings.context_newPlaylist);
        baseControlsHelper.setValuetoTextFieldByName("NEW_.*&", vz_strings.alertTextField);
        baseControlsHelper.clickOn(vz_strings.context_addPlaylist);

        TestCase.assertTrue("Invalid character pop up not present ? ", baseControlsHelper.getCountByName(vz_strings.playlistName_req) > 0);

    }
}