//VZNFT-21 - Step1
package com.sncr.verizon.appiumtests.vznft.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LocalyticsMusicAlbums extends BaseTestClass {

    @Test(testName = "VZNFT-21", groups = {"vznft", GroupNames.MUSIC})
    public void testLocalyticsMusicAlbums() throws Exception {

        precondition.clickMusicHeadFromHome();

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_musicAlbums);

        TestCase.assertTrue(vz_strings.logs_musicAlbums + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_musicAlbums) == 1);
    }
}
