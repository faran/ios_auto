//https://jira.synchronoss.net:8443/jira/browse/IV-2286
package com.sncr.verizon.appiumtests.IV.photosandvideos;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by kram0003 on 29/01/18.
 */
public class StorySearchYear extends BaseTestClass {

    @Test(testName = "IV-2286", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS})
    public void storySearchYear_IV_2386() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_stories);
        if (baseControlsHelper.getCountByName(vz_strings.emptyPhotosViewIcon) == 0) {
            TestCase.assertTrue("Stories are not displaying proper", photosAndVideosView.search("Year"));
        } else
            TestCase.assertTrue("No Stories are avaliable", baseControlsHelper.getCountByName(vz_strings.emptyPhotosViewIcon) != 0);
    }
}
