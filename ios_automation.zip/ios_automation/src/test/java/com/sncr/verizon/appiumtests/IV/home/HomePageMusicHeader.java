package com.sncr.verizon.appiumtests.IV.home;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * @author asdr0001
 * https://jira.synchronoss.net:8443/jira/browse/IV-1086
 */
public class HomePageMusicHeader extends BaseTestClass {
    @Test(testName = "IV-1086", groups = {"release", GroupNames.HOME})
    public void testHomePageMusicHeader() throws Exception {
        precondition.clickMusicHeadFromHome();
        TestCase.assertTrue("Album is not selected ",
                baseControlsHelper.isSelectedByTypeAndName("XCUIElementTypeButton", vz_strings.tab_albums));
    }
}
