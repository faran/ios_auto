package com.sncr.verizon.appiumtests.IV.photosandvideos.flashbacks;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.HelperUtilities;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.managers.iOSManager;
import junit.framework.TestCase;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static com.sncr.verizon.appiumtests.constants.vz_serverConfigs.photoFileName;

/**
 * Created by ssam0003 on 12/02/19.
 */
public class FlashbacksAfterKillingApp extends BaseTestClass {

    @Test(testName = "IV-3819", groups = {GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FLASHBACKS, "release"})
    public void testFlashbacksAfterKillingApp() throws Exception {
        driver().launchApp();
        TestCase.assertTrue("Carousel flashbacks not displayed", baseControlsHelper.getCountByNameContains(vz_strings.carousel_flashbacks) > 0);
        iOSManager.terminateApp(vz_strings.BundleIds.VZ_ID);
        driver().launchApp();
        TestCase.assertTrue("Carousel flashbacks not displayed", baseControlsHelper.getCountByNameContains(vz_strings.carousel_flashbacks) > 0);
    }
}
