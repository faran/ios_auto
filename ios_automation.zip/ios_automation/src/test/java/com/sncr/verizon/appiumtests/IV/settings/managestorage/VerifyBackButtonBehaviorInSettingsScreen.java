package com.sncr.verizon.appiumtests.IV.settings.managestorage;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class VerifyBackButtonBehaviorInSettingsScreen extends BaseTestClass {

    private SoftAssert softAssert = new SoftAssert();

    @Test(testName = "IV-2759", groups = {GroupNames.MANAGE_STORAGE, "release"})
    public void testVerifyBackButtonBehaviorInSettingsScreen() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_settings);
        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.my_Account) != 0, "Settings page not displayed");
        baseControlsHelper.waitForPresent(vz_strings.settings_manageStorage);
        baseControlsHelper.clickOnNameContainsAndVisibile(vz_strings.settings_manageStorage);
        baseControlsHelper.waitForDismiss(vz_strings.spinner);
        Thread.sleep(2000);
        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.currentPlan) != 0, "Current Plan not displayed");
        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.availablePlans) != 0, "Available plans not displayed");
        baseControlsHelper.tapOnBackButton();
        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.logs_settings_screen) != 0, "Settings screen not displayed");
        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.my_Account) != 0, "Unable to return to settings page");
        softAssert.assertAll();
    }
}
