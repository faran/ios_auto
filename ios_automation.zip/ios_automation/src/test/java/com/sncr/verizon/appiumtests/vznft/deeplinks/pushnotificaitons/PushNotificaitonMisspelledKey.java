package com.sncr.verizon.appiumtests.vznft.deeplinks.pushnotificaitons;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class PushNotificaitonMisspelledKey extends BaseTestClass {

    @Test(testName = "VZNFT-156", groups = {"vznft", GroupNames.PUSH_NOTIFICATIONS})
    public void testPushNotificaitonMisspelledKey() throws Exception{

        nativeIosAppsView.openDeeplink(vz_strings.Deeplinks.INVALID_LINK);

        TestCase.assertTrue("Not open on home page", baseControlsHelper.getCountByName(vz_strings.verizon_cloud) > 0);
    }
}
