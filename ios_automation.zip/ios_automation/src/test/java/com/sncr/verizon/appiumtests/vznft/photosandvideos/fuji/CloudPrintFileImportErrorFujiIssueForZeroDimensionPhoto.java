//https://jira.synchronoss.net:8443/jira/browse/VZNFT-270
package com.sncr.verizon.appiumtests.vznft.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.SortAndFilter;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.servercalls.VZServerRequests;
import junit.framework.TestCase;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static com.sncr.verizon.appiumtests.constants.vz_serverConfigs.zeroDimensionPhotoName;
import static com.sncr.verizon.appiumtests.constants.vz_strings.somePhotoCannotBePrintedPopUp;

/**
 * Created by ssam0003 on 22/01/19.
 */
public class CloudPrintFileImportErrorFujiIssueForZeroDimensionPhoto extends BaseTestClass {

    private boolean fileUploaded = false;

    @BeforeMethod
    public void uploadPhoto() throws Exception {
        fileUploaded = doWsgGetTokenCall(msisdn, password);
        VZServerRequests vzServerRequests = new VZServerRequests();
        vzServerRequests.uploadFile(vz_strings.DataType.PHOTO, zeroDimensionPhotoName);
    }

    @Test(testName = "VZNFT-270", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI})
    public void testCloudPrintFileImportErrorFujiIssueForZeroDimensionPhoto() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.sortBy(SortAndFilter.DATE_UPLOADED);
        gridView.tapItemInSelectMode(vz_strings.DataType.PHOTO);
        baseControlsHelper.clickOn(vz_strings.context_icon_printShop);
        baseControlsHelper.waitForDismiss(vz_strings.spinner);

        TestCase.assertTrue("Import error download box not displayed", baseControlsHelper.isVisible(somePhotoCannotBePrintedPopUp));

        String logs = localyticsHelper.getLogs();

        TestCase.assertTrue("Localytics of " + vz_strings.cloudPrintFileImportError + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.cloudPrintFileImportError) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_HEIC + " is not in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_HEIC + " = " + "0") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_JPEG + " is not in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_JPEG + " = " + "1") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_PNG + " is not in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_PNG + " = " + "0") == 1);
        TestCase.assertTrue("Localytics of " + "clv" + " does not exist",
                localyticsHelper.isExisted(logs, "and clv: (null)"));
    }

    @AfterMethod
    public void deleteFile() throws Exception {
        if(fileUploaded)
            deleteRepoFile(zeroDimensionPhotoName);
    }
}
