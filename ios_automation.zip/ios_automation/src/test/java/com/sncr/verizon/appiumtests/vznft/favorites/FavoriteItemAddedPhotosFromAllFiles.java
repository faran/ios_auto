package com.sncr.verizon.appiumtests.vznft.favorites;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.servercalls.VZServerRequests;
import junit.framework.TestCase;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class FavoriteItemAddedPhotosFromAllFiles extends BaseTestClass {

    @BeforeMethod(groups = {"vznft", GroupNames.FAVORITES})
    private void uploadPhotos() throws Exception {
        if (doWsgGetTokenCall(msisdn, password)) {
            VZServerRequests vzServerRequests = new VZServerRequests();
            vzServerRequests.deleteRepo(repoName);
            driver().launchApp();
            Thread.sleep(5000);
            homeScreenView.navigateTo(vz_strings.navi_home);
            homeScreenView.navigateTo(vz_strings.navi_allFiles);
            vzServerRequests.createRepo(repoName);
            vzServerRequests.uploadFile(vz_strings.DataType.PHOTO);
        }

    }

    @Test(testName = "VZNFT-173", description = "STEP-7", groups = {"vznft", GroupNames.FAVORITES})
    public void testFavoriteItemAddedPhotosFromAllFiles() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        precondition.removeAllFavoritesFromAlbum();
        homeScreenView.navigateTo(vz_strings.navi_allFiles);
        baseControlsHelper.clickOn(repoName);
        listView.selectFirstItemInSelectMode10();
        baseControlsHelper.openContext(vz_strings.context_addFavorite);
        baseControlsHelper.waitForDismiss(vz_strings.toast_addtoFavorite);

        String logs = localyticsHelper.getLogs();

        TestCase.assertTrue("Localytics of " + vz_strings.logs_favItemAdded + " does not exist",
                localyticsHelper.isExisted(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_favItemAdded));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_count + " does not exist",
                localyticsHelper.isExisted(logs, vz_strings.logs_count + " = " + "1"));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + " does not exist",
                localyticsHelper.isExisted(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + vz_strings.logs_mediaTypePhotos));

    }
}
