//VZNFT-366
package com.sncr.verizon.appiumtests.vznft.deeplinks;

import com.sncr.verizon.appiumtests.constants.EmailAndMessageUtils;
import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.managers.iOSManager;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class MailStorageUpgradeFromBackground extends BaseTestClass {

    @Test(testName = "VZNFT-366", groups = {GroupNames.DEEPLINKS, "vznft"})
    public void testMailStorageUpgradeFromBackground() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_settings);
        baseControlsHelper.waitForPresent(vz_strings.settings_manageStorage);
        baseControlsHelper.clickOnNameContainsAndVisibile(vz_strings.settings_manageStorage);

        iOSManager.runAppInBackground(-1);
        EmailAndMessageUtils.deleteAllMails();
        EmailAndMessageUtils.sendEmail("vz", vz_strings.Deeplinks.MANAGE_STORAGE, EmailAndMessageUtils.username);

        nativeIosAppsView.openMailBox();
        baseControlsHelper.clickOnNameContains(vz_strings.Deeplinks.MANAGE_STORAGE);
        baseControlsHelper.clickOn(vz_strings.Deeplinks.MANAGE_STORAGE);
        baseControlsHelper.waitForShow(vz_strings.settings_manageStorage);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_appLaunch);

        TestCase.assertTrue("Localytics of tag " + vz_strings.logs_appLaunch + " is missing",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_appLaunch) == 1);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_source  + " is missing",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_source + " = " + "\"" + vz_strings.logs_deeplink + "\"") == 1);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_sourceApplication + " is missing",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_sourceApplication + "\"" + " = " +
                        "\"" + vz_strings.BundleIds.APL_MAIL + "\"") == 1);

        TestCase.assertTrue("Localytics of " + " is missing",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_target + " = " + "\"" + vz_strings.logs_ManageStorage + "\"" ) == 1);
    }
}
