//https://jira.synchronoss.net:8443/jira/browse/VZNFT-60
package com.sncr.verizon.appiumtests.vznft.backup;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.driver.BaseDriver;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 10/12/18.
 */
public class CancelBackupByClickingOnXOnNotificationBar extends BaseTestClass {

    @Test(testName = "VZNFT-60", groups = {"vznft", GroupNames.BACKUP})
    public void testCancelBackupByClickingOnXOnNotificationBar() throws Exception {

        try {
            settingsView.enableOnlyPhotosBackup();
            nativeIosAppsView.capturePhotos(2);
            driver().launchApp();
            homeScreenView.cancelBackup();

            String logs = localyticsHelper.getLogs();
            localyticsHelper.print(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_homeScreenBackupIconClicked);

            TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaDownload + " is not 1 in logs",
                    localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_homeScreenBackupIconClicked) == 2);
            TestCase.assertTrue("Localytics of " + vz_strings.logs_button_state + " does not exist",
                    localyticsHelper.getPatternMatch(logs, vz_strings.logs_button_state + " = " + vz_strings.logs_waiting) == 2);
            TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaDownload + " is not 1 in logs",
                    localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_backup_complete) == 1);
            TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SUCCESSFUL + " is not 1 in logs",
                    localyticsHelper.getPatternMatch(logs, vz_strings.LOGS_STATUS + " = " + vz_strings.LOGS_CANCELLED) == 1);
            TestCase.assertTrue("Localytics of " + vz_strings.logs_backup_complete + " is not 1 in logs",
                    localyticsHelper.getPatternMatch(logs, vz_strings.logs_backup_type + " = " + vz_strings.logs_media) == 1);

        } finally {
            settingsView.tapOnBackButtonAndSetWhatToBackup(true, 0);
        }
    }
}
