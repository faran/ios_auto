package com.sncr.verizon.appiumtests.cleanuptests.allfiles;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.servercalls.VZServerRequests;
import junit.framework.TestCase;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

public class AllFilesCopyShareLink extends BaseTestClass {

    @BeforeMethod(groups = {"vznft", GroupNames.ALL_FILES, GroupNames.PHOTOS_AND_VIDEOS})
    public void beforeMethod() throws Exception {
        if (doATPAuthCall(msisdn)) {
            VZServerRequests vzServerRequests = new VZServerRequests();
            vzServerRequests.deleteRepo(repoName);
            driver().launchApp();
            Thread.sleep(5000);
            homeScreenView.navigateTo(vz_strings.navi_home);
            homeScreenView.navigateTo(vz_strings.navi_allFiles);
            vzServerRequests.createRepo(repoName);
            ArrayList<String> filesToUpload = new ArrayList<>();
            Files.list(Paths.get(testDataDirectory + "/images"))
                    .filter(Files::isRegularFile)
                    .forEach(path -> filesToUpload.add(path.getFileName().toString()));
            vzServerRequests.uploadFiles(vz_strings.DataType.PHOTO, filesToUpload);
            driver().launchApp();
            homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        }
    }

    @Test(testName = "VZNFT-58", groups = {"vznft", GroupNames.ALL_FILES, GroupNames.PHOTOS_AND_VIDEOS})
    public void testAllFilesCopyShareLink() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_allFiles);
        allFilesView.selectMultiplePhotosAndCopyShareLink(repoName, 3);

        String logs = localyticsHelper.getLogs();

        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SHARE_SEND_CONTENT + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND_CONTENT) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareContentSize + " does not exist", localyticsHelper.isExisted(logs, vz_strings.logs_shareContentSize));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareItemShared + "  items size is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareItemShared + "\" = 3") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareContentType + " photo is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareContentType + "\" = " + "Photos") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_target + " is not 1", localyticsHelper.getPatternMatch(logs, vz_strings.logs_target + " = "
                + "\"" + vz_strings.logs_NotApplicable + "\"") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SHARE_SEND + " is not 1 in logs",
                localyticsHelper.isExisted(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND));
        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SUCCESSFUL + " is not 1 in logs",
                localyticsHelper.getCountOf(logs, vz_strings.LOGS_STATUS + " = " + vz_strings.LOGS_SUCCESSFUL) == 1);
    }
}
