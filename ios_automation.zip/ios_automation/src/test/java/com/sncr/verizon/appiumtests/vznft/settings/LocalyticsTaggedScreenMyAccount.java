//https://jira.synchronoss.net:8443/jira/browse/VZNFT-495
package com.sncr.verizon.appiumtests.vznft.settings;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 31/10/2018.
 */
public class LocalyticsTaggedScreenMyAccount extends BaseTestClass {

    @Test(testName = "VZNFT-495", groups = {"vznft", GroupNames.SETTINGS})
    public void testLocalyticsTaggedScreenMyAccount() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_settings);
        baseControlsHelper.clickOn(vz_strings.my_Account);
        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagScreen + ": " + vz_strings.my_Account);
        TestCase.assertTrue("Localytics of " + vz_strings.my_Account + " not exists",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.my_Account + "") == 1);
    }
}
