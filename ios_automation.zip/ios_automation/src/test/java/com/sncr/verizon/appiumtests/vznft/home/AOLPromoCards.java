package com.sncr.verizon.appiumtests.vznft.home;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

import static com.sncr.verizon.appiumtests.constants.vz_strings.*;

/**
 * Created by ssam0003 on 06/02/19.
 */
public class AOLPromoCards extends BaseTestClass {

    @Test(testName = "VZNFT-484", groups = {"vznft", GroupNames.HOME})
    public void testAOLPromoCards() throws Exception {
        if (baseControlsHelper.getCountByName(promoCard_Dismiss) > 0) {
            baseControlsHelper.clickOn(promoCard_Dismiss);
            String logs = localyticsHelper.getLogs();
            TestCase.assertTrue("Localytics of " + promoCard_Clicked + " does not exist", localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + promoCard_Clicked) == 1);
            TestCase.assertTrue("Localytics of " + logs_buttonClicked + " does not exist", localyticsHelper.getPatternMatch(logs, logs_buttonClicked + " = " + vz_strings.button_dismiss) == 1);
            TestCase.assertTrue("Localytics of " + logs_ALO_Card + " does not exist", localyticsHelper.getPatternMatch(logs, logs_ALO_Card) == 1);
        }
    }
}
