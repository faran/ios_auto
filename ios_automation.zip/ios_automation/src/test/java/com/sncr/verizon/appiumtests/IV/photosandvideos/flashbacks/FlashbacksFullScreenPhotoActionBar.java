package com.sncr.verizon.appiumtests.IV.photosandvideos.flashbacks;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class FlashbacksFullScreenPhotoActionBar extends BaseTestClass {

    @Test(testName = "IV-2398", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.CONTEXT_MENU, GroupNames.FLASHBACKS})
    public void testFlashbacksFullScreenPhotoContextMenu() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_flashbacks);

        //Enter fullscreen photo view within flashback
        gridView.tapItem(vz_strings.DataType.PHOTO);

        Thread.sleep(1000);

        //Check action bar items
        TestCase.assertTrue("Action bar Edit not displayed",
                baseControlsHelper.getCountByNameContains(vz_strings.ab_btn_Edit) > 0);

        TestCase.assertTrue("Action bar Add not displayed",
                baseControlsHelper.getCountByNameContains(vz_strings.ab_btn_Add) > 0);

        TestCase.assertTrue("Action bar Fav not displayed",
                baseControlsHelper.getCountByNameContains(vz_strings.ab_btn_UnFav) > 0);

        TestCase.assertTrue("Action bar Share not displayed",
                baseControlsHelper.getCountByNameContains(vz_strings.ab_btn_Share) > 0);

        TestCase.assertTrue("Action bar Download not displayed",
                baseControlsHelper.getCountByNameContains(vz_strings.ab_btn_Download) > 0);

    }
}
