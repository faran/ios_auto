//IV-257
package com.sncr.verizon.appiumtests.IV.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class NoShareInMusicPlayList extends BaseTestClass {

    @Test(testName = "IV-257", groups = {"release", GroupNames.MUSIC})
    public void testNoShareInMusicPlayList() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_music);
        musicView.selectTab(vz_strings.tab_playlists);
        listView.selectItemInSelectMode10("section - 0, row - 0");
        baseControlsHelper.openContext(null);

        TestCase.assertTrue("Share present in context menu", baseControlsHelper.getCountByName(vz_strings.context_share) == 0);
    }
}