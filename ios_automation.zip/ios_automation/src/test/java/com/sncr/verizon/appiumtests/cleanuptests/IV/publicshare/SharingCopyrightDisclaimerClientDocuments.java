package com.sncr.verizon.appiumtests.cleanuptests.IV.publicshare;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.controls.SharePane;
import com.sncr.verizon.appiumtests.servercalls.VZServerRequests;
import junit.framework.TestCase;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SharingCopyrightDisclaimerClientDocuments extends BaseTestClass {

    @BeforeMethod(groups = {"release", GroupNames.PUBLIC_SHARE})
    public void deleteMessages() throws Exception {
        if (doWsgGetTokenCall(msisdn,password)) {
            VZServerRequests server = new VZServerRequests();
            server.uploadFile(vz_strings.DataType.DOCUMENT);
        }
        nativeIosAppsView.deleteAllSMS();
    }

    @Test(testName = "IV-2859", groups = {"release", GroupNames.PUBLIC_SHARE})
    public void testSharingCopyrightDisclaimerClientDocuments() throws Exception {

        driver().launchApp();
        homeScreenView.navigateTo(vz_strings.navi_documents);
        documentsView.shareDocuments(1);
        sharePane.selectOption(SharePane.OptionType.MESSAGE);
        baseControlsHelper.setValuetoTextFieldByName(msisdn, vz_strings.native_message_receiver);
        baseControlsHelper.clickOn(vz_strings.keypad_Return_Key);
        baseControlsHelper.clickOn(vz_strings.native_message_sendButton);
        baseControlsHelper.waitForDismiss(vz_strings.success_toast);
        nativeIosAppsView.openSharedLink();
        TestCase.assertTrue("Document not displayed", baseControlsHelper.getCountByName(vz_strings.printsAndGifts_selectAll) > 0);
    }
}
