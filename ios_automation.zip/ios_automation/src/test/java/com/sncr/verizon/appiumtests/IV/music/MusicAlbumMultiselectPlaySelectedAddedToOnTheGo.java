package com.sncr.verizon.appiumtests.IV.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class MusicAlbumMultiselectPlaySelectedAddedToOnTheGo extends BaseTestClass {

    @Test(testName = "IV-716", groups = {GroupNames.MUSIC, "release"})
    public void testMusicAlbumMultiselectPlaySelectedAddedToOnTheGo() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_music);
        musicView.selectTab(vz_strings.tab_albums);

        listView.selectFirstItemInSelectMode10();
        baseControlsHelper.openContext(vz_strings.context_playSelected);
        baseControlsHelper.waitForShow(vz_strings.button_pauseButton);

        musicView.selectTab(vz_strings.tab_playlists);
        musicView.openPlaylist("On-The-Go");

        TestCase.assertTrue("Playlist On-The-Go is empty",
                baseControlsHelper.getCountByName(vz_strings.button_icon_playButton) > 0);
    }
}
