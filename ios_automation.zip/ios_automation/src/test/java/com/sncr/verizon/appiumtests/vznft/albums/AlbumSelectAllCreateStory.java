//https://jira.synchronoss.net:8443/jira/browse/VZNFT-72/step-2
package com.sncr.verizon.appiumtests.vznft.albums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by kram0003 on 22/02/18.
 */
public class AlbumSelectAllCreateStory extends BaseTestClass {

    @Test(testName = "VZNFT-72", groups = {"vznft", GroupNames.ALBUMS})
    public void albumSelectAllCreateStory() throws Exception {

        homeScreenView.fromHomeClickAt(vz_strings.navi_Photosandvideos);
        precondition.deleteAllAlbums();
        precondition.createAlbum();
        photosAndVideosView.openAlbum();
        gridView.clickAllElements();
        baseControlsHelper.openContext(vz_strings.context_createStory);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagEvent);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_realtimesLaunched + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_realtimesLaunched) == 1);
    }
}
