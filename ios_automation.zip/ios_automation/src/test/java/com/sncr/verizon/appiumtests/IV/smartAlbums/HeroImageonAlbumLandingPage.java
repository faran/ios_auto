//IV-168
package com.sncr.verizon.appiumtests.IV.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class HeroImageonAlbumLandingPage extends BaseTestClass {

    @Test(testName = "IV-168", groups = {"release", GroupNames.SMART_ALBUMS})
    public void testHeroImageonAlbumLandingPage() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_stories);
        baseControlsHelper.clickOnLabelBeginswith("Story-0");
        TestCase.assertTrue("Hero Image, Icon. Missing ?", baseControlsHelper.getCountByName("bt stories white") > 0);
    }
}