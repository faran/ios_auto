//VZNFT-21 - Step2
//https://jira.synchronoss.net:8443/jira/browse/VPCIOS-5634
package com.sncr.verizon.appiumtests.vznft.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LocalyticsMusicAlbumsPlayAll extends BaseTestClass {

    @Test(testName = "VZNFT-21", groups = {"vznft", GroupNames.MUSIC})
    public void testLocalyticsMusicAlbumsPlayAll() throws Exception {

        precondition.clickMusicHeadFromHome();
        baseControlsHelper.openContext(vz_strings.context_playAll);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_mediaPlay);

        TestCase.assertTrue(vz_strings.logs_tagEvent + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaPlay) == 1);
        TestCase.assertTrue(vz_strings.logs_mediaTypeSong + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\" = " + vz_strings.logs_mediaTypeSong) == 1);
    }
}
