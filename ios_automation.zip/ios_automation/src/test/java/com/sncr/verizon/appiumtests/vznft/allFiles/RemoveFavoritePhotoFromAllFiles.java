//https://jira.synchronoss.net:8443/jira/browse/VZNFT-174/step-9
package com.sncr.verizon.appiumtests.vznft.allFiles;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.servercalls.VZServerRequests;
import junit.framework.TestCase;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static com.sncr.verizon.appiumtests.constants.vz_serverConfigs.photoFileName;
import static com.sncr.verizon.appiumtests.constants.vz_strings.logs_mediaTypePhotos;

/**
 * Created by kram0003 on 10/04/18.
 */
public class RemoveFavoritePhotoFromAllFiles extends BaseTestClass {

    @BeforeMethod(groups = {"vznft", GroupNames.ALL_FILES})
    private void uploadPhoto() throws Exception {
        if (doWsgGetTokenCall(msisdn, password)) {
            VZServerRequests vzServerRequests = new VZServerRequests();
            vzServerRequests.deleteRepo(repoName);
            driver().launchApp();
            Thread.sleep(6000);
            homeScreenView.navigateTo(vz_strings.navi_home);
            homeScreenView.navigateTo(vz_strings.navi_allFiles);
            vzServerRequests.createRepo(repoName);
            vzServerRequests.uploadFile(vz_strings.DataType.PHOTO);
        }
        driver().launchApp();
        homeScreenView.navigateTo(vz_strings.navi_allFiles);
        baseControlsHelper.clickOn(repoName);
        listView.removeFavorites();
        listView.multiFavorite(1);
    }

    @Test(testName = "VZNFT-174", description = "STEP-9(1)", groups = {"vznft", GroupNames.ALL_FILES})
    public void testRemoveFavoritePhotoFromAllFiles() throws Exception {

        listView.SelectMultiItem(1);
        baseControlsHelper.openContext(vz_strings.context_removeFavorite);
        baseControlsHelper.waitForDismiss(vz_strings.toast_removeFromFavorite);

        String logs = localyticsHelper.getLogs();

        TestCase.assertTrue("Localytics of " + vz_strings.logs_tagEvent + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_favItemRemoved) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\" = " + logs_mediaTypePhotos) == 2);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_count + "  is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_count + " = 1") == 2);
    }

    @AfterMethod(groups = {"vznft", GroupNames.ALL_FILES})
    private void cleanUp() throws Exception {
        deleteRepoFile(photoFileName);
    }
}
