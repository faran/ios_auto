//https://jira.synchronoss.net:8443/jira/browse/IV-157
package com.sncr.verizon.appiumtests.IV.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.openqa.selenium.Point;
import org.openqa.selenium.ScreenOrientation;
import org.testng.annotations.Test;

public class HeroImageInLandscape extends BaseTestClass {

    @Test(testName = "IV-157", groups = {"release", GroupNames.SMART_ALBUMS})
    public void testHeroImageInLandscape() throws Exception{

        try{
            baseControlsHelper.setOrientation(ScreenOrientation.LANDSCAPE);
            homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
            photosAndVideosView.selectTab(vz_strings.tab_stories);
            photosAndVideosView.openStory10();
            Point playButton = baseControlsHelper.getCoordinatesByID(vz_strings.button_playstory_nav);
            Point center = baseControlsHelper.getCenterByID(baseControlsHelper.getNavBarText());
            TestCase.assertTrue("Play button is missing",
                    baseControlsHelper.getCountByName(vz_strings.button_playstory_nav) == 1);
            TestCase.assertTrue("Play button not on top right hand side",
                    playButton.x > center.x+200 && playButton.y <= 50);
            TestCase.assertTrue("Hero image is present in landscape view",
                    baseControlsHelper.getCountByName(vz_strings.story_HeroImage) < 1);
        }
        finally{
            baseControlsHelper.setOrientation(ScreenOrientation.PORTRAIT);
        }
    }

}
