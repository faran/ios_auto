//IV-2398
package com.sncr.verizon.appiumtests.IV.photosandvideos.flashbacks;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.HelperUtilities;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.lang.invoke.MethodHandles;

import static com.sncr.verizon.appiumtests.constants.vz_serverConfigs.photoFileName;

public class FlashbacksFullScreenPhotoContextMenu extends BaseTestClass {

    private SoftAssert softAssert = new SoftAssert();

    @Test(testName = "IV-2398", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.CONTEXT_MENU, GroupNames.FLASHBACKS})
    public void testFlashbacksFullScreenPhotoContextMenu() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_flashbacks);

        //Enter fullscreen photo view within flashback
        gridView.tapItem(vz_strings.DataType.PHOTO);

        //Check print icon is outside context menu
        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.context_icon_printShop) > 0, "Prints & Gifts Icon is missing");

        //Check context menu options
        baseControlsHelper.openContext(null);
        softAssert.assertTrue(contextualMenu.verifyOptions(null, vz_strings.view_Flashbacks, true), "Options missing ");

        softAssert.assertAll();
    }
}
