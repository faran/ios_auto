//https://jira.synchronoss.net:8443/jira/browse/VZNFT-200
package com.sncr.verizon.appiumtests.vznft.photosandvideos;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LocalyticsPhotosVideosFlashbacks extends BaseTestClass {

    @Test(testName = "VZNFT-200", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS})
    public void test() throws Exception{

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_flashbacks);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_photosVideosFlashBacks);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_photosVideosFlashBacks + " is not 1",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen
                        + ": " + vz_strings.logs_photosVideosFlashBacks) == 1);
    }
}
