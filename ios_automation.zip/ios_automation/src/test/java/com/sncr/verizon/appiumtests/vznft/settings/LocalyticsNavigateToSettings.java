//VZNFT-11 step 2
package com.sncr.verizon.appiumtests.vznft.settings;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LocalyticsNavigateToSettings extends BaseTestClass {

    @Test(testName = "VZNFT-11", groups = {"vznft", GroupNames.SETTINGS})
    public void testLocalyticsNavigateToSettings() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_settings);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagScreen);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_tagScreen + " was not found",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_settings_screen) == 1);
    }
}
