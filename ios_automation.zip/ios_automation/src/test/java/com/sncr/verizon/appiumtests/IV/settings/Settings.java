package com.sncr.verizon.appiumtests.IV.settings;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class Settings extends BaseTestClass {

    @Test(testName = "IV-3386", groups = {"release", GroupNames.SETTINGS})
    public void testSettings() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_settings);

        TestCase.assertTrue("What to Back Up missing? ",
                baseControlsHelper.getCountByName(vz_strings.settings_whatToBackUp) != 0);
        TestCase.assertTrue("How to Back Up missing? ",
                baseControlsHelper.getCountByName(vz_strings.settings_HowToBackUp) != 0);
        TestCase.assertTrue("Email Address missing? ",
                baseControlsHelper.getCountByName(vz_strings.my_Account) != 0);
        TestCase.assertTrue("manage storage missing? ",
                baseControlsHelper.getCountByName(vz_strings.settings_manageStorage) != 0);
        TestCase.assertTrue("notification manager missing? ",
                baseControlsHelper.getCountByName(vz_strings.settings_Notification_Manager) != 0);
        TestCase.assertTrue("tools missing? ",
                baseControlsHelper.getCountByName(vz_strings.navi_tools) != 0);
        TestCase.assertTrue("About missing? ",
                baseControlsHelper.getCountByName(vz_strings.settings_about) != 0);
        TestCase.assertTrue("About missing? ",
                baseControlsHelper.getCountByName(vz_strings.auc_appsusingcloud) != 0);
    }
}
