package com.sncr.verizon.appiumtests.cleanuptests.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.EmailAndMessageUtils;
import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.controls.Ologger;
import com.sncr.verizon.appiumtests.managers.iOSManager;
import junit.framework.TestCase;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static com.sncr.verizon.appiumtests.constants.vz_strings.*;

public class UserHasNoSupportedPhotosInAccount extends BaseTestClass {

    @BeforeMethod(groups = {"vznft", GroupNames.CTA})
    public void cleanUpPhotos() throws Exception {
        if (doATPAuthCall(msisdn)) {
            if (getMediaCount(ContentType.PHOTOS) > 0) {
                if (deleteAllFiles(ContentType.PHOTOS)) {
                    Ologger.log.info("Photos cleared");
                }
            }
        }
    }

    @Test(testName = "VZNFT-307", groups = {"vznft", GroupNames.CTA})
    public void testUserHasNoSupportedPhotosInAccount() throws Exception {

        iOSManager.runAppInBackground(-1);
        EmailAndMessageUtils.deleteAllMails();
        EmailAndMessageUtils.sendEmail("vz", vz_strings.Deeplinks.PRINTS_AND_GIFTS_CANVAS, EmailAndMessageUtils.username);

        nativeIosAppsView.openMailBox();
        baseControlsHelper.clickOnNameContains(vz_strings.Deeplinks.PRINTS_AND_GIFTS_CANVAS);
        baseControlsHelper.clickOn(vz_strings.Deeplinks.PRINTS_AND_GIFTS_CANVAS);

        TestCase.assertTrue(noPhotosTitle.concat(" not displayed"), baseControlsHelper.getCountByName(verizon_cloud) > 0);
        TestCase.assertTrue(noPhotosTitle.concat(" not displayed"), baseControlsHelper.getCountByName(noPhotosTitle) > 0);
        TestCase.assertTrue(noPhotosMessage.concat(" not displayed"), baseControlsHelper.getCountByName(noPhotosMessage) == 1);
    }
}
