package com.sncr.verizon.appiumtests.IV.tools;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
/**
 *  IV-2989
 * @author leletsn
 */
public class MergeContent extends BaseTestClass{
	@Test(testName = "IV-2989", groups = {"release", GroupNames.TOOLS})
	public void testMergeContent() throws Exception {
		SoftAssert softAssert = new SoftAssert();

		homeScreenView.navigateTo(vz_strings.navi_settings);
		baseControlsHelper.clickOn(vz_strings.navi_tools);
		baseControlsHelper.clickOn(vz_strings.tools_merge);
		
		softAssert.assertTrue(baseControlsHelper.getCountByName("Merge Content")!=0,
				"Merge Content Screen is not seen");
		softAssert.assertTrue(baseControlsHelper.getTextById(vz_strings.tools_MergeContent_MergeAccountText).contains(vz_strings.tools_MergeContent_MergeAccountText),
				"Merge Content text is not displayed as Expected");
		softAssert.assertTrue(baseControlsHelper.getCountByNameContains(vz_strings.tools_MergeContent_CurrentlySignedInText)!=0,
				"Currently Signed MDN text is not displayed as Expected");

		baseControlsHelper.clickOn(vz_strings.tools_LogIntoOtherCloudAccount);
		baseControlsHelper.waitForShow("Sign in");

		softAssert.assertTrue(baseControlsHelper.getCountByName("SyncDriveCore.SAMLWebViewLogin")!=0,
				"SAML WebView login Page is not loaded");

		baseControlsHelper.tapOnBackButton();

		softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.tools_merge)!=0,
				"Not directed to Tools Page");
		baseControlsHelper.tapOnBackButton();
		softAssert.assertTrue(baseControlsHelper.getCountByName("Merge Content")!=0,
			"Merge Content Screen is not seen");

        softAssert.assertAll();
    }
}


  



