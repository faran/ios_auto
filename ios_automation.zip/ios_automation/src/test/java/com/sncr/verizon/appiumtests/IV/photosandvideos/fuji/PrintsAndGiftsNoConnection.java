package com.sncr.verizon.appiumtests.IV.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class PrintsAndGiftsNoConnection extends BaseTestClass {

    @Test(testName = "IV-2481", groups = {GroupNames.FUJI, "release"})
    public void testPrintsAndGiftsNoConnection() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        
        baseControlsHelper.openContext(vz_strings.context_select);
        gridView.selectWithScroll(vz_strings.DataType.PHOTO, 2, 4);
        baseControlsHelper.clickOn(vz_strings.context_icon_printShop);

        nativeIosAppsView.turnOnAirplaneModeThroughSiri();
        baseControlsHelper.waitForShow(vz_strings.button_exit_shop);

        TestCase.assertTrue("Info message not found", baseControlsHelper.getTextFromAlertBox(0).equals(vz_strings.text_printShopNoConnection));
        TestCase.assertTrue("Progress icon is not found", baseControlsHelper.getCountByName(vz_strings.spinner) > 0);
        TestCase.assertTrue("Exit button not present ", baseControlsHelper.getCountByName(vz_strings.button_exit_shop) > 0);
    }

    @AfterMethod(alwaysRun = true)
    public void disableAirplaneMode() throws Exception {
        nativeIosAppsView.disableAirplaneMode();
    }
}
