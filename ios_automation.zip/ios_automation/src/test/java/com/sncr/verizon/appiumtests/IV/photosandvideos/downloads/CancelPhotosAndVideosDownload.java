package com.sncr.verizon.appiumtests.IV.photosandvideos.downloads;
import com.sncr.verizon.appiumtests.constants.GroupNames;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
/**
 * @author leletsn
 * IV847-CancelDownloading
 */
public class CancelPhotosAndVideosDownload extends BaseTestClass {

	private SoftAssert softAssert = new SoftAssert();

	@Test(testName = "IV-847", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.DOWNLOADS})
    public void testCancelPhotosAndVideosDownload() throws Exception {

         homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
         photosAndVideosView.selectTab(vz_strings.tab_all);
         baseControlsHelper.openContext(vz_strings.context_select);
         gridView.selectWithScroll(vz_strings.DataType.PHOTO, 1, 4);
         gridView.selectWithScroll(vz_strings.DataType.VIDEO, 1, 4);
         baseControlsHelper.openContext(vz_strings.context_download);
         baseControlsHelper.clickOn(vz_strings.cancel_progressbar);
         
         softAssert.assertTrue(baseControlsHelper.getTextById(vz_strings.dialog_cancelDownload).equals(vz_strings.dialog_cancelDownload), "There is no Cancel Download Label");
         softAssert.assertTrue(baseControlsHelper.getTextById(vz_strings.dialog_CancelDownload_message).equals(vz_strings.dialog_CancelDownload_message), "Text label does not match");
         softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.dialog_no)!=0,  "'No' button is not displayed" );
         softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.dialog_yes)!=0,  "'Yes' button is not displayed" );
         
         baseControlsHelper.clickOn(vz_strings.button_yes);
         
         softAssert.assertTrue((baseControlsHelper.getCountByName(vz_strings.cancel_progressbar))==0, "Download is still inProgress");
         softAssert.assertAll();
         }
}