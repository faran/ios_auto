/**
 * VZNFT - 109 Step 5
 */
package com.sncr.verizon.appiumtests.vznft.photosandvideos;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class MediaOpenHomeStory extends BaseTestClass {

    @Test(testName = "VZNFT-109", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS})
    public void testMediaOpenHomeStory() throws Exception {

        homeScreenView.clickOnStory(vz_strings.carousel_story);
        gridView.tapItem(vz_strings.DataType.PHOTO);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_mediaOpen);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaOpen + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaOpen) == 1);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaTypePhotos + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + vz_strings.logs_mediaTypePhotos) == 1);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_photosVideosStories + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_page + " = \"" + vz_strings.logs_photosVideosStories + "\"") == 1);
    }
}