//https://jira.synchronoss.net:8443/jira/browse/VZNFT-173 #2
package com.sncr.verizon.appiumtests.vznft.favorites;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.SortAndFilter;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;


public class FavoriteItemAddedPhotos extends BaseTestClass {

    @Test(testName = "VZNFT-173", groups = {"vznft", GroupNames.FAVORITES})
    public void testFavoriteItemAddedPhotos() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        precondition.removeAllFavoritesFromAlbum();
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.sortBy(SortAndFilter.PHOTOS);
        gridView.tapItemInSelectMode(vz_strings.DataType.PHOTO);
        baseControlsHelper.openContext(vz_strings.context_addFavorite);
        baseControlsHelper.waitForDismiss(vz_strings.toast_addtoFavorite);

        String logs = localyticsHelper.getLogs();

        TestCase.assertTrue("Localytics of " + vz_strings.logs_favItemAdded + " does not exist",
                localyticsHelper.isExisted(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_favItemAdded));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_count + " does not exist",
                localyticsHelper.isExisted(logs, vz_strings.logs_count + " = " + "1"));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + " does not exist",
                localyticsHelper.isExisted(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + vz_strings.logs_mediaTypePhotos));

    }
}