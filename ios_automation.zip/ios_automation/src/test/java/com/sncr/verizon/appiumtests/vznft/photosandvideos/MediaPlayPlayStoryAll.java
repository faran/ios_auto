package com.sncr.verizon.appiumtests.vznft.photosandvideos;

/**
 * VZNFT-111 Step 2
*/

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class MediaPlayPlayStoryAll extends BaseTestClass {

    @Test(testName = "VZNFT-111", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS})
    public void testMediaPlayPlayStoryAll() throws Exception {

        homeScreenView.fromHomeClickAt(vz_strings.home_photsAndVideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        gridView.tapItem(vz_strings.DataType.STORY);
        photosAndVideosView.playVideo();

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagEvent);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaPlay + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaPlay) == 1);

        TestCase.assertTrue(vz_strings.logs_mediaType + " more than 2",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\" = " + vz_strings.logs_mediaTypeStory) == 2);
    }
}
