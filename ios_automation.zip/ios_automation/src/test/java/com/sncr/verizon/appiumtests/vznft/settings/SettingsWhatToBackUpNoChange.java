package com.sncr.verizon.appiumtests.vznft.settings;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class SettingsWhatToBackUpNoChange extends BaseTestClass {

    @Test(testName = "VZNFT-11", groups = {"vznft", GroupNames.SETTINGS})
    public void testLocalyticsNavigateToSettings() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_settings);
        baseControlsHelper.clickOn(vz_strings.settings_whatToBackUp);
        baseControlsHelper.tapOnBackButton();

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_whatToBackupModification);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_whatToBackupModification + " was not found",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_whatToBackupModification) == 0);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_whatToBackupContacts + " was not found",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_whatToBackupContacts + " = " + vz_strings.logs_no_change) == 0);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_whatToBackupPhotos + " was not found",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_whatToBackupPhotos + " = " + vz_strings.logs_no_change) == 0);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_whatToBackupPhotosBackground + " was not found",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_whatToBackupPhotosBackground + " = " + vz_strings.logs_no_change) == 0);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_whatToBackupVideos + " was not found",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_whatToBackupVideos + " = " + vz_strings.logs_no_change) == 0);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_whatToBackupHowToBackup + " was not found",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_whatToBackupHowToBackup + " = " + vz_strings.logs_no_change) == 0);

    }

}
