package com.sncr.verizon.appiumtests.vznft.deeplinks.pushnotificaitons;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class PushNotificationKillStateFuji extends BaseTestClass {

    @Test(testName = "VZNFT-282", groups = {"vznft", GroupNames.DEEPLINKS, GroupNames.FUJI})
    public void testPushNotificationKillStateFuji() throws Exception {

        driver().terminateApp(vz_strings.BundleIds.VZ_ID);

        nativeIosAppsView.openDeeplink(vz_strings.Deeplinks.PRINTS_AND_GIFTS_CANVAS);

        baseControlsHelper.waitForShow(vz_strings.Canvas);

        TestCase.assertTrue("Did not open on canvas page",
                baseControlsHelper.getCountByName(vz_strings.Canvas) > 0);
    }
}
