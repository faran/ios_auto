//IV-2394
package com.sncr.verizon.appiumtests.IV.photosandvideos.flashbacks;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.HelperUtilities;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

import java.lang.invoke.MethodHandles;

import static com.sncr.verizon.appiumtests.constants.vz_serverConfigs.photoFileName;

public class FlashbacksContextMenu extends BaseTestClass {

    @Test(testName = "IV-2398", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.CONTEXT_MENU, GroupNames.FLASHBACKS})
    public void testFlashbacksContextMenu() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_flashbacks);
        baseControlsHelper.openContext(null);

        TestCase.assertTrue("Options missing ",
                contextualMenu.verifyOptions(vz_strings.DataType.PHOTO, vz_strings.view_Flashbacks, true));
        TestCase.assertTrue("Prints & Gifts Icon is missing", baseControlsHelper.getCountByName(vz_strings.context_icon_printShop) > 0);
    }
}
