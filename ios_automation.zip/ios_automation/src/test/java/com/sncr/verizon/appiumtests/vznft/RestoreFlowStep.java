package com.sncr.verizon.appiumtests.vznft;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class RestoreFlowStep extends BaseTestClass {

    @Test(testName = "VZNFT-14", groups = {"vznft", GroupNames.RESTORE, GroupNames.TOOLS})
    public void testRestoreFlowStep() throws Exception {

        toolsView.restoreMedia();

        String logs = localyticsHelper.getLogs();

        TestCase.assertTrue("Localytics of " + vz_strings.logs_tagScreen + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_restoreMediaView) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_tagEvent + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_restoreFlowStep) == 2);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_contentRestoreListItemClick + " is not 1 in logs",
                localyticsHelper.getCountOf(logs, vz_strings.logs_contentRestoreListItemClick) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_contentRestoreButtonClick + " is not 1 in logs",
                localyticsHelper.getCountOf(logs, vz_strings.logs_contentRestoreButtonClick) == 1);
    }
}
