/*
 * Step 3 VZNFT-10
 * Step 5 VZNFT-26
*/
package com.sncr.verizon.appiumtests.cleanuptests.cta;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LocalyticsHMContactsCTA extends BaseTestClass {

    @Test(testName = "VZNFT-10", groups = {"vznft", GroupNames.CTA})
    public void testLocalyticsHMContactsCTA() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_contacts);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagScreen);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaTypeDocument + " exists",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_contacts + " " + vz_strings.logs_CTA) == 1);
    }
}
