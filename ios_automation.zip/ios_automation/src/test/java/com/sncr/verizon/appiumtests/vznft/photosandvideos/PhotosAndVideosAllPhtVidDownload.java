//https://jira.synchronoss.net:8443/jira/browse/VZNFT-69/step-6
package com.sncr.verizon.appiumtests.vznft.photosandvideos;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

import java.util.List;

/**
 * Created by kram0003 on 28/02/18.
 */
public class PhotosAndVideosAllPhtVidDownload extends BaseTestClass {

    @Test(testName = "VZNFT-69", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS})
    public void photosandVideosPhtVidDwnld() throws Exception {

        homeScreenView.fromHomeClickAt(vz_strings.navi_Photosandvideos);
        baseControlsHelper.openContext(vz_strings.context_select);
        gridView.selectWithScroll(vz_strings.DataType.PHOTO, 1, 5);
        gridView.selectWithScroll(vz_strings.DataType.VIDEO, 1, 5);
        baseControlsHelper.openContext(vz_strings.context_download);
        photosAndVideosView.checkDownload();

        String logs = localyticsHelper.getLogs();

        List<String> mediaType = localyticsHelper.dynamicCount(logs, vz_strings.logs_mediaType);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaDownload + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaDownload) == 2);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_count + "  is not 2 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_count + " = 1") == 2);

        for (String mediatypes : mediaType) {
            if ((mediatypes.contains("Video")) || (mediatypes.contains("Photo"))) {
                TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + "is not 1 in logs",
                        localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\" " + mediatypes) == 1);
            } else TestCase.assertFalse("Localytics of " + vz_strings.logs_mediaType + " not matches", true);
        }
    }
}
