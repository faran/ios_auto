package com.sncr.verizon.appiumtests.vznft.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.EmailAndMessageUtils;
import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.managers.iOSManager;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 05/02/19.
 */
public class NavigateToFujiScreenFromSettings extends BaseTestClass {

    @Test(testName = "VZNFT-311", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI})
    public void testNavigateToFujiScreenFromSettings() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_settings);
        iOSManager.runAppInBackground(-1);
        EmailAndMessageUtils.deleteAllMails();
        EmailAndMessageUtils.sendEmail("vz", vz_strings.Deeplinks.PRINTS_AND_GIFTS_CANVAS, EmailAndMessageUtils.username);

        nativeIosAppsView.openMailBox();
        baseControlsHelper.clickOnNameContains(vz_strings.Deeplinks.PRINTS_AND_GIFTS_CANVAS);
        baseControlsHelper.clickOn(vz_strings.Deeplinks.PRINTS_AND_GIFTS_CANVAS);
        baseControlsHelper.waitForShow(vz_strings.printsAndGifts_Canvas);

        TestCase.assertTrue("text CANVAS not found after clicking deep link", baseControlsHelper.getCountByName(vz_strings.printsAndGifts_Canvas) == 1);
        baseControlsHelper.clickOn(vz_strings.button_exit);
        baseControlsHelper.clickOn(vz_strings.button_yes);
        TestCase.assertTrue("text CANVAS not found after clicking deep link", baseControlsHelper.getCountByName(vz_strings.navi_settings) > 0);
    }
}
