//https://jira.synchronoss.net:8443/jira/browse/VZNFT-313
package com.sncr.verizon.appiumtests.vznft.deeplinks;

import com.sncr.verizon.appiumtests.constants.EmailAndMessageUtils;
import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class MailPrintsCanvasFromKill extends BaseTestClass {

    @Test(testName = "VZNFT-313", groups = {GroupNames.DEEPLINKS, "vznft"})
    public void testMailPrintsCanvasFromKill() throws Exception {
        driver().terminateApp(vz_strings.BundleIds.VZ_ID);
        EmailAndMessageUtils.deleteAllMails();
        EmailAndMessageUtils.sendEmail("vz", vz_strings.Deeplinks.PRINTS_AND_GIFTS_CANVAS, EmailAndMessageUtils.username);
        nativeIosAppsView.openMailBox();
        baseControlsHelper.clickOnNameContains(vz_strings.Deeplinks.PRINTS_AND_GIFTS_CANVAS);
        baseControlsHelper.clickOn(vz_strings.Deeplinks.PRINTS_AND_GIFTS_CANVAS);
        baseControlsHelper.waitForDismiss(vz_strings.spinner);

        if(baseControlsHelper.getCountByName(vz_strings.button_acceptContinue) > 0)
            baseControlsHelper.clickOn(vz_strings.button_acceptContinue);

        baseControlsHelper.waitForShow(vz_strings.Canvas);
        TestCase.assertTrue("Canvas deep link did not work when clicking after killing app",
                baseControlsHelper.getCountByName(vz_strings.Canvas) <= 1);

        baseControlsHelper.clickOn(vz_strings.button_exit);
        baseControlsHelper.clickOn(vz_strings.button_yes);
        TestCase.assertTrue("Did not return to application after exiting fuji", baseControlsHelper.getCountByName(vz_strings.verizon_cloud) > 0);
    }
}
