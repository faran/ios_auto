/**
 * VZNFT-29 - Step 4
 * */
package com.sncr.verizon.appiumtests.vznft.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LocalyticsMusicSortZA extends BaseTestClass{

    @Test(testName = "VZNFT-29", groups = {"vznft", GroupNames.MUSIC})
    public void testLocalyticsMusicSortZA() throws Exception {

      precondition.clickMusicHeadFromHome();
      musicView.selectTab(vz_strings.tab_songs);
      baseControlsHelper.openContext(vz_strings.context_sort);
      baseControlsHelper.setPickerValue(vz_strings.sort_ZtoA);

      String logs = localyticsHelper.getLogs();
      localyticsHelper.print(logs, vz_strings.logs_tagEvent);

      TestCase.assertTrue("Localytics of " + vz_strings.logs_tagEvent + " is not 1 in logs",
              localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_sortMedia) == 1);

      TestCase.assertTrue("Localytics of " + vz_strings.logs_sortOption + " is not 1 in logs",
              localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_sortOption + "\" = " + "\"" + vz_strings.logs_sortZtoA + "\"") == 1);

    }
}
