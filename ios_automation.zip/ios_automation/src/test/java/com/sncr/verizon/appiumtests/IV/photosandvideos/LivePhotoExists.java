package com.sncr.verizon.appiumtests.IV.photosandvideos;

import com.sncr.verizon.appiumtests.accountdata.GalleryItemExists;
import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import junit.framework.TestCase;
import org.testng.annotations.Test;

import java.util.ArrayList;

/**
 * Uploads live photos to account
 */
public class LivePhotoExists extends GalleryItemExists {

    /**
     * Checks to see if live photo is present in account
     *
     * @return true if live photo is present, false otherwise
     * @throws Exception
     */
    @Override
    public boolean areItemsPresent() throws Exception {
        if (baseControlsHelper.getCountByName(vz_strings.text_photosAndVideos) == 0) {
            baseControlsHelper.swipe("up");
            Thread.sleep(2000);
        }

        return baseControlsHelper.getCountByNameLike(vz_strings.name_livePhotoGrid) >= 2;
    }

    @Test(groups = {"vznft", "snapshot", "release", GroupNames.LIVE_PHOTO_EXISTS})
    public void testLivePhotoExists() throws Exception {
        TestCase.assertTrue(testItemsExist());
    }

    /**
     * Uploads two live photos to account
     * Live photos are expected to be in form HEIC/MOV and in resources/live_photos folder.
     * For best results, manually capture a live photo and pull from device to live_photos folder
     * This is the easiest way to get both HEIC/MOV that will successfully play
     *
     * @throws Exception
     * @see com.sncr.verizon.appiumtests.controls.BaseMediaTest#uploadLivePhotos(String, String)
     * @see com.sncr.verizon.appiumtests.controls.BaseMediaTest#getFilesToUpload(vz_strings.DataType)
     */
    @Override
    public void uploadItems() throws Exception {
        if (doWsgGetTokenCall(msisdn, password)) {

            ArrayList<String> files = getFilesToUpload(vz_strings.DataType.LIVEPHOTO);
            // live photo requires photo + video -> Sort so that image/video will be paired [index,index + 1]
            files.sort(String::compareTo);
            for (int i = 0; i < files.size() - 1; i += 2) {

                uploadLivePhotos(testDataDirectory + "/live_photos/" + files.get(i),
                        testDataDirectory + "/live_photos/" + files.get(i + 1));
                // only keep reference to the img
                filesToUpload.add(files.get(i));
            }

        }
    }
}
