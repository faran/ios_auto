//VZNFT-4 STEP-1
package com.sncr.verizon.appiumtests.vznft.publicshare;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.servercalls.VZServerRequests;
import junit.framework.TestCase;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ShareSendContentEventForDocumentShare extends BaseTestClass {

    @BeforeMethod(groups = {"vznft", GroupNames.DOCUMENTS,GroupNames.PUBLIC_SHARE})
    public void uploadDocuments() throws Exception {
        if (doWsgGetTokenCall(msisdn, password)) {
            if (getMediaCount(ContentType.DOCUMENTS) < 2) {
                VZServerRequests server = new VZServerRequests();
                server.uploadFile(vz_strings.DataType.DOCUMENT);
                server.uploadFile(vz_strings.DataType.DOCUMENT, "api-design.pdf");
            }
        }
    }

    @Test(testName = "VZNFT-4", groups = {"vznft", GroupNames.DOCUMENTS,GroupNames.PUBLIC_SHARE})
    public void testShareSendContentEventForDocumentShare() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_documents);
        documentsView.shareDocuments(2);
        sharePane.shareViaEmail();

        String logs = localyticsHelper.getLogs();

        TestCase.assertTrue(vz_strings.LOGS_SHARE_SEND_CONTENT + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND_CONTENT) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareContentSize + " does not exist",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_shareContentSize) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareContentType + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareContentType + "\"" + " = " + vz_strings.logs_mediaTypeDocument) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareItemShared + " does not exist",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareItemShared + "\"" + " = " + "2") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_target + " is not 1",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_target + " = "
                        + "\"" + vz_strings.logs_NotApplicable + "\"") == 1);

        TestCase.assertTrue(vz_strings.LOGS_SHARE_SEND + " is not 1 in logs",
                localyticsHelper.isExisted(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND));
        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SUCCESSFUL + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.LOGS_STATUS + " = " + vz_strings.LOGS_SUCCESSFUL) == 1);


    }
}
