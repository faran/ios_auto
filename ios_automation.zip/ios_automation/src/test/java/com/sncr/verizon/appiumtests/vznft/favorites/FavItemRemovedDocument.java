/**
 * VZNFT-174 - Step 5-6
 */
package com.sncr.verizon.appiumtests.vznft.favorites;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class FavItemRemovedDocument extends BaseTestClass {

    private void preCondition() throws Exception {
        System.out.println("--Start Preconditions--");
        if (baseControlsHelper.getCountByName(vz_strings.group_favorites) == 0) {
            listView.selectFirstItemInSelectMode10();
            baseControlsHelper.openContext(vz_strings.context_addFavorite);
        }
        System.out.println("--End Preconditions--");
    }

    @Test(testName = "VZNFT-174", groups = {"vznft", GroupNames.FAVORITES})
    public void testFavItemRemovedDocument() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_documents);
        preCondition();
        listView.selectFirstItemInSelectMode10();
        baseControlsHelper.openContext(vz_strings.context_removeFavorite);
        baseControlsHelper.waitForDismiss(vz_strings.toast_removeFromFavorite);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_favItemRemoved);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_favItemRemoved + " does not exist",
                localyticsHelper.isExisted(logs, vz_strings.logs_favItemRemoved));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_tagEvent + " is not 1 in logs",
                localyticsHelper.getCountOf(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_favItemRemoved) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_count + " does not exist",
                localyticsHelper.isExisted(logs, vz_strings.logs_count + " = " + "1"));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + " does not exist",
                localyticsHelper.isExisted(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + vz_strings.logs_mediaTypeDocument));
    }
}