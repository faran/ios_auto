package com.sncr.verizon.appiumtests.cleanuptests.provisioning;

import com.sncr.verizon.appiumtests.constants.HelperUtilities;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class LoginWithSSO extends BaseTestClass {

    @Test(groups = {"release", "snapshot", "vznft"})
    public void testLoginWithSSO(ITestContext context) throws Exception {
        System.out.println(context.getCurrentXmlTest().getParameter("udid"));
        HelperUtilities.modifyPlist(context.getCurrentXmlTest().getParameter("udid"));
        provisioningView.signInToSSO();
    }

    @AfterMethod(alwaysRun = true)
    public void cleanUp() {
        HelperUtilities.unMountAndRemoveFolder();
    }
}
