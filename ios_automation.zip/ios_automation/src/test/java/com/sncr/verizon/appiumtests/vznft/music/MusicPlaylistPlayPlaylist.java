package com.sncr.verizon.appiumtests.vznft.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class MusicPlaylistPlayPlaylist extends BaseTestClass {

    @Test(groups = {"vznft", GroupNames.MUSIC})
    public void testMusicPlaylistPlayPlaylist() throws Exception {


        homeScreenView.navigateTo(vz_strings.navi_music);
        musicView.selectTab(vz_strings.tab_playlists);
        precondition.addNewPL();
        precondition.addSongToEmptyPlaylist();
        musicView.selectTab(vz_strings.tab_playlists);
        baseControlsHelper.clickOn(vz_strings.view_musicPlaylists);
        baseControlsHelper.openContext(vz_strings.context_playPlaylist);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_mediaPlay);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_musicPlaylists + " does not exist",
                localyticsHelper.isExisted(logs, vz_strings.logs_musicPlaylists));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_musicPlaylists + " is not 1 in logs",
                localyticsHelper.getCountOf(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_musicPlaylists) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_tagEvent + " is not 1 in logs",
                localyticsHelper.getCountOf(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaPlay) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + " is not 1 in logs",
                localyticsHelper.getCountOf(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + "Song") == 1);
    }

}
