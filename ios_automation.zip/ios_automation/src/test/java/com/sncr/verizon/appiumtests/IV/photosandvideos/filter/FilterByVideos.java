//IV-2266
package com.sncr.verizon.appiumtests.IV.photosandvideos.filter;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.SortAndFilter;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class FilterByVideos extends BaseTestClass {

    @Test(testName = "IV-182", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FILTER})
    public void testFilterByVideos() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.setPickWheelFilter(SortAndFilter.VIDEOS);

        TestCase.assertEquals("Didn't find Filter header", "Videos",
                baseControlsHelper.getTextById(vz_strings.filter_FilteredByVideos));
        TestCase.assertTrue("Live Photo inside album ? ",
                baseControlsHelper.getCountByNameLike("Live Photos") < 1);
        TestCase.assertTrue("Photo inside album ? ",
                baseControlsHelper.getCountByNameLike("Photo") < 1);
    }
}
