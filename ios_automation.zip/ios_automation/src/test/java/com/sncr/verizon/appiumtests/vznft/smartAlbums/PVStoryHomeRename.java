package com.sncr.verizon.appiumtests.vznft.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * * VZNFT - 82 Step 2
 */

public class PVStoryHomeRename extends BaseTestClass {

    @Test(testName = "VZNFT-82", groups = {"vznft", GroupNames.SMART_ALBUMS})
    public void testPVStoryHomeRename() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_home);
        homeScreenView.clickOnStory(vz_strings.carousel_story);
        baseControlsHelper.openContext(vz_strings.context_renameStory);
        baseControlsHelper.setValuetoTextFieldByName("Renamed Story", vz_strings.alertTextField);
        baseControlsHelper.clickOn(vz_strings.button_ok);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_storyRename);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_storyRename + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_storyRename) == 1);
    }
}


