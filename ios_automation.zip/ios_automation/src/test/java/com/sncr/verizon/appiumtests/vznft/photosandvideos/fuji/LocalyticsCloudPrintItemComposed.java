//VZNFT-245
package com.sncr.verizon.appiumtests.vznft.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.testng.annotations.Test;

public class LocalyticsCloudPrintItemComposed extends BaseTestClass {

    @Test(testName = "VZNFT-245", groups = {"vznft", GroupNames.FUJI, GroupNames.PHOTOS_AND_VIDEOS})
    public void testLocalyticsCloudPrintItemComposed() throws Exception {
        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.removeAllProductFromCart();
        Thread.sleep(3000);
        gridView.tapItemsInMultiSelectModeUniversal(1, vz_strings.DataType.PHOTO);
        photosAndVideosView.navigateToOrdersPage();
        baseControlsHelper.waitForShow(vz_strings.photoBucket_PlusOrCrossIcon);

        Dimension screenSize = baseControlsHelper.getDeviceSize();
        Point locationOfPlusIcon = baseControlsHelper.getCenterByID(vz_strings.photoBucket_PlusOrCrossIcon);
        //Tap on location opposite '+' icon where first photo is approximately
        baseControlsHelper.touchAndHoldOnCoordinate(screenSize.width - locationOfPlusIcon.x, screenSize.height - locationOfPlusIcon.y);
        baseControlsHelper.waitForShow(vz_strings.button_save);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_photoBucketCloudItemComposed);

        TestCase.assertTrue("Localytics of tagEvent " + vz_strings.logs_photoBucketCloudItemComposed + " is not 1",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_photoBucketCloudItemComposed) == 1);

        TestCase.assertTrue("Localytics of Attribute " + vz_strings.logs_CloudPrint_ItemBrowsed + " is not 1",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_CloudPrint_ItemBrowsed + "\"" + " = "
                        + "\"" + vz_strings.printsAndGrfts_4x6_Print + "\"") == 1);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketDeliveryType + " is not 1",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucketDeliveryType + "\"" + " = "
                        + "\"" + vz_strings.logs_photoBucketMailOrder + "\"") == 1);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketPickupLocation + " is not 1",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucketPickupLocation + "\"" + " = "
                        + "\"" + vz_strings.logs_NotApplicable + "\"") == 1);

        //Fuji analytics also sending a tag which will be caught without stricter regex
        TestCase.assertTrue("Localyics of " + vz_strings.logs_source + " is not 1",
                localyticsHelper.getPatternMatch(logs, "(^|[ ])" + vz_strings.logs_source + " = "
                        + "\"" + vz_strings.logs_photoBucketOrderPrintsPage + "\"") == 1);
    }
}
