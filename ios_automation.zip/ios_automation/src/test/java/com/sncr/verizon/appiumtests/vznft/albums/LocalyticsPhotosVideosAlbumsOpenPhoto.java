package com.sncr.verizon.appiumtests.vznft.albums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

//VZNFT-109 #step 7
public class LocalyticsPhotosVideosAlbumsOpenPhoto extends BaseTestClass {

	@Test(testName = "VZNFT-109", groups = {"vznft", GroupNames.ALBUMS})
	public void testLocalyticsPhotosVideosAlbumsOpenPhoto() throws Exception {
		homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
		photosAndVideosView.selectTab(vz_strings.tab_albums);
		precondition.createAlbum();
		photosAndVideosView.openAlbum();
		precondition.addPhotoToExistingAlbum();
		photosAndVideosView.openAlbum();
		gridView.tapItem(vz_strings.DataType.PHOTO);
		String logs = localyticsHelper.getLogs();
		localyticsHelper.print(logs, vz_strings.logs_mediaOpen);

		TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaOpen + " does not exist",
				localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaOpen) == 1);
		TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaType + " does not exist",
				localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + vz_strings.logs_mediaTypePhotos) == 1);
		TestCase.assertTrue("Localytics of " + vz_strings.logs_page + " does not exist",
				localyticsHelper.getPatternMatch(logs, vz_strings.logs_page + " = " + "\"" + vz_strings.logs_photosVideosAlbums + "\"") == 1);

	}
}
