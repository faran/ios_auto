package com.sncr.verizon.appiumtests.IV.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class GenresListingContextMenuOptions extends BaseTestClass {

    @Test(testName = "IV-700", groups = {"release", GroupNames.MUSIC, GroupNames.CONTEXT_MENU})
    public void testGenresListingContextMenuOptions() throws Exception {


        homeScreenView.navigateTo(vz_strings.navi_music);
        musicView.selectTab(vz_strings.tab_genres);
        listView.selectItem10("Unknown Genre");
        baseControlsHelper.openContext(null);

        TestCase.assertTrue("Options missing ", contextualMenu.verifyOptions(null, vz_strings.view_musicGenres, true));

    }
}
