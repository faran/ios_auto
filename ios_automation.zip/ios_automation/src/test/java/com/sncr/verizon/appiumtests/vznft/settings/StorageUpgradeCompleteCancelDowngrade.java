//https://jira.synchronoss.net:8443/jira/browse/VZNFT-384
package com.sncr.verizon.appiumtests.vznft.settings;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 09/07/18.
 */
public class StorageUpgradeCompleteCancelDowngrade extends BaseTestClass {

    @Test(testName = "VZNFT-384", groups = {"vznft", GroupNames.SETTINGS})
    public void testStorageUpgradeCompleteCancelDowngrade() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_settings);
        baseControlsHelper.waitForPresent(vz_strings.settings_manageStorage);
        baseControlsHelper.clickOnNameContainsAndVisibile(vz_strings.settings_manageStorage);

        if (settingsView.getCurrentStoragePlan().equalsIgnoreCase(vz_strings.settings_manageStorage_500GB_plan))
            settingsView.upgradeStorageToOneTB();

        baseControlsHelper.waitForPresent(vz_strings.settings_manageStorage_500GB_plan);
        baseControlsHelper.clickOnNameContainsAndVisibile(vz_strings.settings_manageStorage_500GB_plan);
        baseControlsHelper.clickOn(vz_strings.button_cancel);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_Storage_Upgrade);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_Storage_Upgrade + " does not exist",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_Storage_Upgrade) >= 1 &&
                        localyticsHelper.getPatternMatch(logs, vz_strings.logs_Storage_Upgrade) <= 4);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_Storage_No_Change + " does not exist",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_Storage_No_Change) >= 1 &&
                        localyticsHelper.getPatternMatch(logs, vz_strings.logs_Storage_No_Change) <= 4);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_Storage_Promotion + " does not exist",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_Storage_Promotion) >= 1 &&
                        localyticsHelper.getPatternMatch(logs, vz_strings.logs_Storage_Promotion) <= 4);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_Storage_Cancel_Status + " does not exist",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_Storage_Cancel_Status) >= 1 &&
                        localyticsHelper.getPatternMatch(logs, vz_strings.logs_Storage_Cancel_Status) <= 4);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_Storage_Downgrade_Type + " does not exist",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_Storage_Downgrade_Type) >= 1 &&
                        localyticsHelper.getPatternMatch(logs, vz_strings.logs_Storage_Downgrade_Type) <= 4);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_Storage_Source + " does not exist",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_Storage_Source) >= 1 &&
                        localyticsHelper.getPatternMatch(logs, vz_strings.logs_Storage_Source) <= 4);
    }
}
