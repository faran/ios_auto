package com.sncr.verizon.appiumtests.IV.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class MusicLastViewRetained extends BaseTestClass {

    @Test(testName = "IV-738", groups = {"release", GroupNames.MUSIC})
    public void testMusicLastViewRetained() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_music);
        musicView.selectTab(vz_strings.tab_songs);
        homeScreenView.navigateTo(vz_strings.navi_home);
        homeScreenView.navigateTo(vz_strings.navi_music);

        TestCase.assertTrue("Music view not selected ",
                baseControlsHelper.isSelectedByTypeAndName("XCUIElementTypeButton", "Songs"));
    }
}
