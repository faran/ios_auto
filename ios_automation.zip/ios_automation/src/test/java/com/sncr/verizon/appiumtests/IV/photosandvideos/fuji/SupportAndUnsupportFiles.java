//https://jira.synchronoss.net:8443/jira/browse/IV-2465
package com.sncr.verizon.appiumtests.IV.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by kram0003 on 23/01/18.
 */
public class SupportAndUnsupportFiles extends BaseTestClass {

    @Test(testName = "IV-2465", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI})
    public void supportAndUnSupport() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        baseControlsHelper.openContext(vz_strings.context_select);
        gridView.tapItems();
        photosAndVideosView.clickPrintsAndGift(vz_strings.context_printAndGifts, vz_strings.context_icon_printShop);
        baseControlsHelper.waitForDismiss(vz_strings.spinner);
        baseControlsHelper.clickOn(vz_strings.button_exit);
        baseControlsHelper.clickOn(vz_strings.button_yes);
        TestCase.assertTrue("Photos and Videos screen missing ", baseControlsHelper.getCountByClassName("XCUIElementTypeCell") > 0);
    }
}
