package com.sncr.verizon.appiumtests.vznft.deeplinks.pushnotificaitons;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class PushNotificationBackgroundOnSettings extends BaseTestClass {

    private SoftAssert softAssert = new SoftAssert();

    @Test(testName = "VZNFT-279", groups = {GroupNames.PUSH_NOTIFICATIONS, "vznft"})
    public void testPushNotificationBackgroundOnSettings() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_settings);

        nativeIosAppsView.openDeeplink(vz_strings.Deeplinks.PRINTS_AND_GIFTS_CANVAS);

        baseControlsHelper.waitForShow(vz_strings.Canvas);

        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.Canvas) > 0,
                "Deeplink did not open on prints and gifts canvas");

        //Exit Fuji and return to app
        baseControlsHelper.clickOn(vz_strings.button_exit);
        baseControlsHelper.clickOn(vz_strings.button_yes);

        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.navi_settings) > 0,
                "did not navigate back to settings");

        softAssert.assertAll();
    }
}
