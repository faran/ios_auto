//IV-144
package com.sncr.verizon.appiumtests.IV.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class CreateStoryFromAlbums extends BaseTestClass {

    private void preCondition() throws Exception {
        System.out.println("--Start Preconditions--");
        if (!photosAndVideosView.ifAnyAlbumExists()) {
            photosAndVideosView.createAlbumWithMultipleItems(vz_strings.create_newAlbumName);
        }
        System.out.println("--End Preconditions--");
    }

    private void preConditionPnV() throws Exception {
        System.out.println("--Start Preconditions--");
        if (baseControlsHelper.getCountByName(vz_strings.empty_albumTitle) != 0) {
            photosAndVideosView.addItemsFromAlbum();
        }
        System.out.println("--End Preconditions--");
    }

    @Test(testName = "IV-144", groups = {"release", GroupNames.SMART_ALBUMS})
    public void testCreateStoryFromAlbums() throws Exception {
        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_albums);
        preCondition();
        photosAndVideosView.openAlbum();
        preConditionPnV();
        baseControlsHelper.tapOnBackButton();
        gridView.tapFolderInSelectMode10("Photos albums folder");
        baseControlsHelper.openContext(vz_strings.context_createStory);
        baseControlsHelper.waitForShow("Edit scenes");

        for (int i = 0; i < vz_strings.realPlayerSave.length; i++) {
            TestCase.assertTrue(vz_strings.realPlayerSave[i] + " is not found.",
                    baseControlsHelper.getCountByName(vz_strings.realPlayerSave[i]) != 0);
        }
    }
}

