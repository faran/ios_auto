//https://jira.synchronoss.net:8443/jira/browse/VZNFT-335 - Step-3
package com.sncr.verizon.appiumtests.vznft.favorites;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.driver.BaseDriver;
import junit.framework.TestCase;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 18/10/2018.
 */
public class LocalyticsLivePhotosMediaPlayFavorites extends BaseTestClass {

    @Test(testName = "VZNFT-335", groups = {"vznft", GroupNames.FAVORITES})
    public void testLocalyticsLivePhotosMediaPlayFavorites() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.addLivePhotoToFavoritesAndPlay();

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaPlay);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaPlay + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaPlay) == 1);
        TestCase.assertTrue(vz_strings.logs_mediaType + " does not exist",
                localyticsHelper.isExisted(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + "\"" + vz_strings.logs_mediaTypeLivePhoto + "\""));

    }
}
