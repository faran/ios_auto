package com.sncr.verizon.appiumtests.vznft.albums;
/*https://jira.synchronoss.net:8443/jira/browse/VZNFT-215
 */

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class VZNFT215InvalidAlbumName extends BaseTestClass {

    @Test(testName = "VZNFT-215", groups = {"vznft", GroupNames.ALBUMS})
    public void testVZNFT215InvalidAlbumName() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_albums);

        if (baseControlsHelper.getCountByName(vz_strings.no_albumTitle) != 0) {
            baseControlsHelper.clickOn(vz_strings.context_newAlbum);
        } else {
            baseControlsHelper.openContext(vz_strings.context_newAlbum);
        }

        baseControlsHelper.setValuetoTextFieldByName(vz_strings.special_char[0], vz_strings.alertTextField);
        baseControlsHelper.clickOn(vz_strings.button_addItems);
        baseControlsHelper.clickOn(vz_strings.button_ok);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_appError);
        System.out.println("string value = " + vz_strings.logs_invalidAlbumName);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_appError + " does not exist",
                localyticsHelper.isExisted(logs, vz_strings.logs_appError));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_appError + " is not 1 in logs",
                localyticsHelper.getCountOf(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_appError) == 1);
        TestCase.assertTrue(vz_strings.logs_message + " does not exist",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_message + " = " + "\"" + vz_strings.logs_invalidAlbumName) == 1);

    }
}