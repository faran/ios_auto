//https://jira.synchronoss.net:8443/jira/browse/VZNFT-404
package com.sncr.verizon.appiumtests.vznft.deeplinks;

import com.sncr.verizon.appiumtests.constants.EmailAndMessageUtils;
import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.managers.iOSManager;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class MailFlashBackFromBackground extends BaseTestClass {

    @Test(groups = {"vznft", GroupNames.DEEPLINKS})
    public void testMailFlashBackFromBackground() throws Exception {

        iOSManager.runAppInBackground(-1);
        EmailAndMessageUtils.deleteAllMails();
        EmailAndMessageUtils.sendEmail("vz", vz_strings.Deeplinks.FLASH_BACK, EmailAndMessageUtils.username);

        nativeIosAppsView.openMailBox();
        baseControlsHelper.clickOnNameContains(vz_strings.Deeplinks.FLASH_BACK);
        baseControlsHelper.clickOn(vz_strings.Deeplinks.FLASH_BACK);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagEvent);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_tagEvent + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_flashBackTab) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_networkType + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_networkType + "\"" + " = " + "\"" + vz_strings.logs_networkTypeWifi + "\"") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_source + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_source + " = " + "\"" + vz_strings.logs_deeplink + "\"") == 2);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_sourceApplication + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_sourceApplication + "\"" + " = " + "\"" + vz_strings.BundleIds.APL_MAIL + "\"") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_target + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_target + " = " + "\"" + vz_strings.logs_gallery_flashbacks + "\"") == 1);
    }
}
