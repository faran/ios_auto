//https://jira.synchronoss.net:8443/jira/browse/IV-2483
package com.sncr.verizon.appiumtests.IV.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by kram0003 on 22/01/18.
 */
public class UnsupportedFiles extends BaseTestClass {

    //@Test(testName = "IV-2483", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI})
    public void unSupportFiles() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        baseControlsHelper.openContext(vz_strings.context_select);
        gridView.tapItems();
        baseControlsHelper.clickOn(vz_strings.button_cartIcon);

        TestCase.assertTrue("Some of your ",
                baseControlsHelper.getCountByName("Some of your selections cannot be printed") > 0);
        baseControlsHelper.clickOn(vz_strings.button_gotIt);

    }

}
