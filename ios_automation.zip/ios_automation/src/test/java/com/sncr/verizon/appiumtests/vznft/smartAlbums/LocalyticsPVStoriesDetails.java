/**
 * @author leletsn
 * VZNFT-79 P/V Story Detail - tagScreens for StoryDetail Step 1
 */
package com.sncr.verizon.appiumtests.vznft.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import org.testng.annotations.Test;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;

public class LocalyticsPVStoriesDetails extends BaseTestClass {

    @Test(testName = "VZNFT-79", groups = {"vznft", GroupNames.SMART_ALBUMS})
    public void testLocalyticsPVStoriesDetails() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_stories);
        photosAndVideosView.openStory10();

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_storyDetail);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_storyDetail + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_storyDetail) == 1);
    }
}
