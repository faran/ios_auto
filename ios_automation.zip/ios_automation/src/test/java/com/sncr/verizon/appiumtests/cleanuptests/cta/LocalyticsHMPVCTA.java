/*
 * VZNFT-75 - Step 1ish
 * */
package com.sncr.verizon.appiumtests.cleanuptests.cta;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.controls.Ologger;
import junit.framework.TestCase;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class LocalyticsHMPVCTA extends BaseTestClass {

    @BeforeMethod(groups = {"vznft", GroupNames.CTA})
    public void cleanUpPhotosAndVideos() throws Exception {
        if (doATPAuthCall(msisdn)) {
            deleteAllFiles(ContentType.ALL);
            if (getMediaCount(ContentType.PHOTOS) > 0) {
                if (deleteAllFiles(ContentType.PHOTOS)) {
                    Ologger.log.info("All photos cleared");
                }
            }
            if (getMediaCount(ContentType.VIDEOS) > 0) {
                if (deleteAllFiles(ContentType.VIDEOS)) {
                    Ologger.log.info("All videos cleared");
                }
            }
        }
    }

    @Test(testName = "VZNFT-75", groups = {"vznft", GroupNames.CTA})
    public void testLocalyticsHMPVCTA() throws Exception {

        driver().launchApp();
        baseControlsHelper.waitForShowByPredicate(vz_strings.noPhotosVideosText);
        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        baseControlsHelper.waitForShow(vz_strings.logs_whatToBackupPhotos);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagScreen);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaTypeDocument + " does not exist",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_mediaTypePhotosAndVideos + " " + vz_strings.logs_CTA) == 1);
        ;
    }
}
