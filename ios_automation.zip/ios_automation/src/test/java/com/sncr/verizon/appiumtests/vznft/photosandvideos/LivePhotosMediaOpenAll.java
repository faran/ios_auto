package com.sncr.verizon.appiumtests.vznft.photosandvideos;
/*
 * Step 1 VZNFT-482
 */

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.SortAndFilter;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LivePhotosMediaOpenAll extends BaseTestClass {

    @Test(testName = "VZNFT-482", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS})
    public void testLivePhotosMediaOpenAll() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.sortBy(SortAndFilter.DATE_UPLOADED);
        gridView.selectWithScroll(vz_strings.DataType.LIVEPHOTO, 1, 5);
        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaOpen);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaOpen + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaOpen) == 1);
        TestCase.assertTrue(vz_strings.logs_mediaType + " does not exist",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + "\"" + vz_strings.logs_mediaTypeLivePhoto + "\"") == 1);
        TestCase.assertTrue(vz_strings.logs_page + " does not exist",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_page + " = " + "\"" + vz_strings.logs_photosVideosAll + "\"") == 1);

    }
}

