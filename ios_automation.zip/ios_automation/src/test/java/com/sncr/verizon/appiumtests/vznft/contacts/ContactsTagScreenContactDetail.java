//https://jira.synchronoss.net:8443/jira/browse/VZNFT-9
package com.sncr.verizon.appiumtests.vznft.contacts;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.HelperUtilities;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 18/10/18.
 */
public class ContactsTagScreenContactDetail extends BaseTestClass {

    private void precondition() throws Exception {
        homeScreenView.navigateTo(vz_strings.navi_settings);
        settingsView.setWhatToBackUp(HelperUtilities.setArguments(vz_strings.settings_whatToBackUp_Contacts));
        settingsView.setWhatNotToBackUp(HelperUtilities.setArguments("", vz_strings.settings_whatToBackUp_Photos, vz_strings.settings_whatToBackUp_Videos));
        baseControlsHelper.tapOnBackButton();
    }

    //@Test(testName = "VZNFT-9", groups = {"vznft", GroupNames.CONTACTS})
    public void testContactsTagScreenContactDetail() throws Exception {

        try {
            precondition();
            contactsView.addRequiredNumberOfContacts(10);
            contactsView.clickOnContactsListView();
            String logs = localyticsHelper.getLogs();
            localyticsHelper.print(logs, vz_strings.logs_tagScreen);
            TestCase.assertTrue("Localytics of " + vz_strings.logs_contacts + " exists", localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_contacts) == 1);
            TestCase.assertTrue("Localytics of " + vz_strings.logs_Contact_Detail + " exists", localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_Contact_Detail) == 1);
        } finally {
            settingsView.tapOnBackButtonAndSetWhatToBackup(true, 1);
        }
    }
}
