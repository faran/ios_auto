package com.sncr.verizon.appiumtests.vznft.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import static com.sncr.verizon.appiumtests.constants.vz_strings.logs_mediaTypeSong;

public class PlaySongAndShareViaMail extends BaseTestClass {

    private SoftAssert softAssert = new SoftAssert();

    @Test(testName = "VZNFT-27", description = "STEP-2", groups = {"vznft", GroupNames.MUSIC})
    public void testPlaySongAndShareViaMail() throws Exception {

        homeScreenView.fromHomeClickAt(vz_strings.navi_music);
        musicView.selectTab(vz_strings.tab_songs);
        baseControlsHelper.clickOnNameContains("section - 0");
        baseControlsHelper.openContext(vz_strings.context_share);
        baseControlsHelper.waitForDismiss(vz_strings.toast_creatingSocialShareLink);

        String logs = localyticsHelper.getLogs();

        softAssert.assertTrue(localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND_CONTENT) == 1,
                "Localytics of " + vz_strings.LOGS_SHARE_SEND_CONTENT + " is not 1 in logs");
        softAssert.assertTrue(localyticsHelper.isExisted(logs, "\"" + vz_strings.logs_shareContentSize + "\""),
                "Localytics of " + vz_strings.logs_shareContentSize + " does not exist");
        softAssert.assertTrue(localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareItemShared + "\" = 1") == 1,
                "Localytics of " + vz_strings.logs_shareItemShared + "  items size is not 1 in logs");
        softAssert.assertTrue(localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareContentType + "\" = " + logs_mediaTypeSong) == 1,
                "Localytics of " + vz_strings.logs_shareContentType + " photo is not 1 in logs");
        softAssert.assertTrue(localyticsHelper.getPatternMatch(logs, vz_strings.logs_target + " = "
                + "\"" + vz_strings.logs_NotApplicable + "\"") == 1, "Localytics of " + vz_strings.logs_target + " is not 1");

        sharePane.shareViaEmail();
        baseControlsHelper.waitForShow(vz_strings.success_toast);

        logs = localyticsHelper.getLogs();

        softAssert.assertTrue(localyticsHelper.isExisted(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND),
                "Localytics of " + vz_strings.LOGS_SHARE_SEND + " is not 1 in logs");
        softAssert.assertTrue(localyticsHelper.getCountOf(logs, vz_strings.LOGS_STATUS + " = " + vz_strings.LOGS_SUCCESSFUL) == 1,
                "Localytics of " + vz_strings.LOGS_SUCCESSFUL + " is not 1 in logs");
        softAssert.assertAll();
    }
}
