//IV-2266
package com.sncr.verizon.appiumtests.IV.photosandvideos.filter;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.SortAndFilter;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class FilterByPhotos extends BaseTestClass {

    @Test(testName = "IV-181", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FILTER})
    public void testFilterByPhotos() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.setPickWheelFilter(SortAndFilter.PHOTOS);

        TestCase.assertEquals("Didn't find Filter header", "Photos",
                baseControlsHelper.getTextById(vz_strings.filter_FilteredByPhotos));
        TestCase.assertTrue("Video inside album ? ",
                baseControlsHelper.getCountByNameLike("Video") < 1);
    }
}
