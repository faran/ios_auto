package com.sncr.verizon.appiumtests.vznft.deeplinks.pushnotificaitons;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.junit.Assert;
import org.testng.annotations.Test;

public class PushNotificationMisspelledKeyFuji extends BaseTestClass {

    @Test(testName = "VZNFT-287", groups = {"vznft", GroupNames.PUSH_NOTIFICATIONS})
    public void testPushNotificationMisspelledKeyFuji() throws Exception {

        nativeIosAppsView.openDeeplink(vz_strings.Deeplinks.INVALID_LINK_FUJI);

        baseControlsHelper.waitForShow(vz_strings.text_printsAndGifts);

        Assert.assertTrue("Did not open on cloud home",
                baseControlsHelper.getCountByName(vz_strings.text_printsAndGifts) > 0);
    }
}
