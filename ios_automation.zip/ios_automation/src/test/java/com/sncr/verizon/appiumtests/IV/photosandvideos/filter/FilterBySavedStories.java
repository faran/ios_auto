//IV-2266
package com.sncr.verizon.appiumtests.IV.photosandvideos.filter;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.SortAndFilter;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class FilterBySavedStories extends BaseTestClass {

    @Test(testName = "IV-2266", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FILTER})
    public void testFilterBySavedStories() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.setPickWheelFilter(SortAndFilter.SAVED_STORIES);

        TestCase.assertEquals("Filter header doesn't match", "Saved Stories",
                baseControlsHelper.getTextById(vz_strings.filter_FilteredBySavedStories));
        TestCase.assertTrue("Photo inside album ? ",
                baseControlsHelper.getCountByNameLike("Photo") < 1);
        TestCase.assertTrue("Live Photo inside album ? ",
                baseControlsHelper.getCountByNameLike("Live Photos") < 1);
    }

}
