//VZNFT-18
package com.sncr.verizon.appiumtests.vznft.tools;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class VZNFT18LocalyticsMergeContent extends BaseTestClass {

    @Test(testName = "VZNFT-18", groups = {"vznft", GroupNames.TOOLS})
    public void testLocalyticsMergeContent() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_settings);
        baseControlsHelper.clickOn(vz_strings.navi_tools);
        baseControlsHelper.clickOn(vz_strings.tools_merge);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tools);
        localyticsHelper.print(logs, vz_strings.logs_mergeAccounts);

        TestCase.assertTrue(vz_strings.logs_mergeAccounts + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_mergeAccounts) == 1);
    }
}
