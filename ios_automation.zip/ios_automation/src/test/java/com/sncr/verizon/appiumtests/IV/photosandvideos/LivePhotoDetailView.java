package com.sncr.verizon.appiumtests.IV.photosandvideos;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.SortAndFilter;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.annotations.Test;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import junit.framework.TestCase;

/**
 * @author leletsn
 * IV-2626 Live Photos : Live Photos Detailed view in Photos & Videos section
 * pre-condition: Make sure you have Live Photos before running Scripts
 */
public class LivePhotoDetailView extends BaseTestClass {

    @Test(testName = "IV-2626", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS})
    public void testLivePhotoDetailView() throws Exception {
        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.sortBy(SortAndFilter.DATE_UPLOADED);
        gridView.selectWithScroll(vz_strings.DataType.LIVEPHOTO, 1, 5);
        TestCase.assertTrue("ImageView is not open", baseControlsHelper.getCountByClassName("XCUIElementTypeScrollView") != 0);
        TestCase.assertTrue("Missing livephoto icon", baseControlsHelper.getCountByName(vz_strings.button_livePhoto_Iris_badge) == 1);
    }
}

