package com.sncr.verizon.appiumtests.IV.delete;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class DeleteAlbumWithin extends BaseTestClass {

        @Test(groups = {"release", GroupNames.DELETE})
        public void testPhotoVideoAlbumsEmpty() throws Exception {

            homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
            photosAndVideosView.selectTab(vz_strings.tab_albums);
            precondition.createAlbum();
            photosAndVideosView.openAlbum();
            baseControlsHelper.openContext(vz_strings.context_deleteAlbum);
            baseControlsHelper.clickOn(vz_strings.button_yes);
            baseControlsHelper.waitForDismiss(vz_strings.toast_albumDeletedSuccessfully);

            TestCase.assertTrue("Image not found",
                    baseControlsHelper.getCountByName("add.png") != 0);
            TestCase.assertTrue("Button not found",
                    baseControlsHelper.getCountByName("New Album") != 0);
        }
}
