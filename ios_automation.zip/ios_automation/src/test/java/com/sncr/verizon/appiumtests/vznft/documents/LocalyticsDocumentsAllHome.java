//VZNFT-2 #1
package com.sncr.verizon.appiumtests.vznft.documents;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class LocalyticsDocumentsAllHome extends BaseTestClass {

    @Test(testName = "VZNFT-2", groups = {"vznft", GroupNames.DOCUMENTS})
    public void testLocalyticsDocumentsAll() throws Exception {

        homeScreenView.fromHomeClickAt(vz_strings.home_documents);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_allDocuments);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_allDocuments + " does not exist",
                localyticsHelper.isExisted(logs, vz_strings.logs_allDocuments));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_allDocuments + " is not 1 in logs",
                localyticsHelper.getCountOf(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_allDocuments) == 1);
    }
}