//https://jira.synchronoss.net:8443/jira/browse/VZNFT-250
package com.sncr.verizon.appiumtests.vznft.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.SortAndFilter;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;


/**
 * Created by ssam0003 on 21/09/18.
 */
public class LocalyticsCloudPrintShopExitCancel extends BaseTestClass {
    @Test(testName = "VZNFT-250", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI})
    public void testLocalyticsCloudPrintShopExitCancel() throws Exception {
        homeScreenView.fromHomeClickAt(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.setPickWheelFilter(SortAndFilter.PHOTOS);
        photosAndVideosView.removeAllProductFromCart();
        baseControlsHelper.openContext(vz_strings.context_select);
        gridView.selectWithScroll(vz_strings.DataType.PHOTO, 3, 4);
        photosAndVideosView.navigateToOrdersPage();
        baseControlsHelper.clickOn(vz_strings.button_exit);
        baseControlsHelper.clickOn(vz_strings.button_yes);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagEvent);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketExit + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_photoBucketExit) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketItemsPurchased + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucketItemsPurchased + "\"" + " = " + "0") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketExitPoint + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucketExitPoint + "\"" + " = " + "\"" + vz_strings.logs_photoBucketOrderPrintsPage + "\"") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketPromoCodeUsed + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucketPromoCodeUsed + "\"" + " = " + "\"" + vz_strings.logs_NotApplicable + "\"") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_AddressValidationError + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_AddressValidationError + "\"" + " = " + "0") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketExitMethod + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucketExitMethod + "\"" + " = " + "\"" + vz_strings.logs_photoBucketCancelButton + "\"") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketDeliveryType + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucketDeliveryType + "\"" + " = " + "\"" + vz_strings.logs_photoBucketMailOrder + "\"") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketPickupLocation + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucketPickupLocation + "\"" + " = " + "\"" + vz_strings.logs_NotApplicable + "\"") == 1);
    }
}
