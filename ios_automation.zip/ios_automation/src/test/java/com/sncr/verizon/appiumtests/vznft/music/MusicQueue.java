package com.sncr.verizon.appiumtests.vznft.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class MusicQueue extends BaseTestClass {

    @Test(groups = {"vznft", GroupNames.MUSIC})
    public void testMusicQueue() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_music);
        musicView.selectTab(vz_strings.tab_playlists);
        precondition.addNewPL();
        precondition.addSongToEmptyPlaylist();
        precondition.addSongToFavoriteFromSongs();
        baseControlsHelper.clickOn("Favorites");
        musicView.clickOnAllElementsInMusicList(vz_strings.MusicView.Favorites);
        baseControlsHelper.openContext(vz_strings.context_playSelected);
        baseControlsHelper.openContext(vz_strings.context_showQueue);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_musicQueue);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_tagEvent + " is not 1 in logs", localyticsHelper.getCountOf(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_musicQueue) == 1);
    }
}
