//https://jira.synchronoss.net:8443/jira/browse/VZNFT-50
package com.sncr.verizon.appiumtests.vznft.backup;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.driver.BaseDriver;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 10/01/19.
 */
public class CancelBackupFromBackUpProgressIcon extends BaseTestClass {
    @Test(testName = "VZNFT-50", groups = {"vznft", GroupNames.BACKUP})
    public void testCancelBackupFromBackUpProgressIcon() throws Exception {

        try {
            settingsView.enableOnlyPhotosBackup();
            baseControlsHelper.tapOnBackButton();
            nativeIosAppsView.capturePhotos(1);
            driver().launchApp();
            homeScreenView.cancelBackup();

            String logs = localyticsHelper.getLogs();

            TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaDownload + " is not 1 in logs",
                    localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_backup_complete) == 1);
            TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SUCCESSFUL + " is not 1 in logs",
                    localyticsHelper.getPatternMatch(logs, vz_strings.LOGS_STATUS + " = " + vz_strings.LOGS_CANCELLED) == 1);
        } finally {
            homeScreenView.backUp();
            settingsView.tapOnBackButtonAndSetWhatToBackup(true, 0);
        }
    }
}
