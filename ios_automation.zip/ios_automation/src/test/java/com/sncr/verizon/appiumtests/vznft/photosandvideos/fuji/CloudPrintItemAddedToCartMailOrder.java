//https://jira.synchronoss.net:8443/jira/browse/VZNFT-255
package com.sncr.verizon.appiumtests.vznft.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class CloudPrintItemAddedToCartMailOrder extends BaseTestClass {

    @Test(testName = "VZNFT-255", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI})
    public void testCloudPrintItemAddedToCartMailOrder() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);

        photosAndVideosView.removeAllProductFromCart();
        Thread.sleep(3000);
        gridView.tapItemsInMultiSelectModeUniversal(1, vz_strings.DataType.PHOTO);
        photosAndVideosView.selectAllAddToCart();
        baseControlsHelper.waitForShow(vz_strings.text_cart);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_PrintAddedToCart);

        TestCase.assertTrue("Localytics of delivery type is not 1",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucketDeliveryType + "\"" + " = "
                        + "\"" + vz_strings.logs_photoBucketMailOrder + "\"") == 1);

        TestCase.assertTrue("Localytics of Duration is not 1",
                localyticsHelper.isExisted(logs, "Duration" + " = "));

        TestCase.assertTrue("Localytics of Item Added is not 1",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucketItemAdded + "\"" + " = "
                        + "\"" + vz_strings.printsAndGifts_firstItem + "\"") == 1);

        TestCase.assertTrue("Localytics of Pickup Location is not 1",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucketPickupLocation + "\"" + " = "
                        + "\"" + vz_strings.logs_NotApplicable + "\"") == 1);

        TestCase.assertTrue("Localytics of Status is not 1",
                localyticsHelper.getPatternMatch(logs, vz_strings.LOGS_STATUS + " = " + vz_strings.LOGS_SUCCESSFUL) == 1);

    }
}
