package com.sncr.verizon.appiumtests.IV.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/* IV-146: Create Story: All Photos and Videos
 * https://jira.synchronoss.net:8443/jira/browse/IV-146
 * */

public class CreateStoryByPhotoAndVideo extends BaseTestClass {

    @Test(testName = "IV-146", groups = {"release", GroupNames.SMART_ALBUMS})
    public void testCreateStoryByPhotoAndVideo() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        baseControlsHelper.openContext(vz_strings.context_select);
        gridView.selectWithScroll(vz_strings.DataType.PHOTO, 1, 4);
        gridView.selectWithScroll(vz_strings.DataType.VIDEO, 1, 4);
        baseControlsHelper.openContext(vz_strings.context_createStory);
        baseControlsHelper.waitForShow("Edit scenes");

        for (int i = 0; i < vz_strings.realPlayerSave.length; i++) {
            TestCase.assertTrue(vz_strings.realPlayerSave[i] + " is not found.", baseControlsHelper
                    .getCountByNameUntilElementDisplay(vz_strings.realPlayerSave[i]) != 0);
        }

    }
}

