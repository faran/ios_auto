/**
 * VZNFT-111 Step 1
 */
package com.sncr.verizon.appiumtests.vznft.photosandvideos;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class MediaPlayAllPhoto extends BaseTestClass{

    @Test(testName = "VZNFT-111", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS})
    public void testMediaPlayAllPhoto() throws Exception {

        homeScreenView.fromHomeClickAt(vz_strings.home_photsAndVideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        gridView.tapItem(vz_strings.DataType.PHOTO);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagEvent);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaOpen + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_mediaOpen) == 1);

        TestCase.assertTrue(vz_strings.logs_mediaType + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\" = " + vz_strings.logs_mediaTypePhotos) == 1);
        System.out.println(vz_strings.logs_page + "\" = \"" + vz_strings.logs_photosVideosAll + "\"");
        TestCase.assertTrue(vz_strings.logs_page + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_page + " = \"" + vz_strings.logs_photosVideosAll + "\"") == 1);
    }
}
