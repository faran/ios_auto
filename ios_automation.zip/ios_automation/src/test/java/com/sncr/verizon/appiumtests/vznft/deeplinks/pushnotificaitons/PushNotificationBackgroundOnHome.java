package com.sncr.verizon.appiumtests.vznft.deeplinks.pushnotificaitons;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class PushNotificationBackgroundOnHome extends BaseTestClass {

    private SoftAssert softAssert = new SoftAssert();

    @Test(testName = "VZNFT-280", groups = {GroupNames.PUSH_NOTIFICATIONS, "vznft"})
    public void testPushNotificationBackgroundOnHome() throws Exception {

        nativeIosAppsView.openDeeplink(vz_strings.Deeplinks.PRINTS_AND_GIFTS_CANVAS);

        baseControlsHelper.waitForShow(vz_strings.Canvas);

        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.printsAndGifts_Canvas) > 0,
                "Did not open on canvas");

        baseControlsHelper.clickOn(vz_strings.button_exit);
        baseControlsHelper.clickOn(vz_strings.button_yes);

        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.verizon_cloud) > 0
                ,"Exiting fuji did not bring back to home");

        softAssert.assertAll();
    }
 }
