//https://jira.synchronoss.net:8443/jira/browse/IV-2456
package com.sncr.verizon.appiumtests.IV.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class PVAllMultiselect extends BaseTestClass {

    @Test(testName = "IV-2456", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI})
    public void testPVAllMultiselect() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.removeAllProductFromCart();
        gridView.tapItemsInMultiSelectModeUniversal(1, vz_strings.DataType.PHOTO);
        photosAndVideosView.accessPrintShopFromIcon();
        String pageTitle = baseControlsHelper.getNameByIndexfromClassName(0, "XCUIElementTypeNavigationBar");
        TestCase.assertEquals("Not in prints & gifts", pageTitle, vz_strings.navi_printshop);
        baseControlsHelper.clickOn(vz_strings.button_exit);
        baseControlsHelper.clickOn(vz_strings.button_yes);
        TestCase.assertTrue("Did not return to Photos and Videos view", baseControlsHelper.getCountByName(vz_strings.navi_Photosandvideos) > 0) ;
    }
}
