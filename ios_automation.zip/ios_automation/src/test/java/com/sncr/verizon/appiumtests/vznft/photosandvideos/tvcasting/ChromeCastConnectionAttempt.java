package com.sncr.verizon.appiumtests.vznft.photosandvideos.tvcasting;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class ChromeCastConnectionAttempt extends BaseTestClass {

    @Test(testName = "VZNFT-268", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS})
    public void testChromeCastConnectionAttempt() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        baseControlsHelper.openContext(vz_strings.context_connectToATV);

        String logs = localyticsHelper.getLogs();
        TestCase.assertTrue("Localytics of " + vz_strings.logs_tagEvent + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.screencast_Connection) == 1);

    }
}
