//https://jira.synchronoss.net:8443/jira/browse/VZNFT-72/step-9
package com.sncr.verizon.appiumtests.vznft.albums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

import java.util.List;

/**
 * Created by kram0003 on 23/02/18.
 */
public class AlbumSelectAllShare extends BaseTestClass {

    @Test(testName = "VZNFT-72", groups = {"vznft", GroupNames.ALBUMS})
    public void albumSelectAllSahre() throws Exception {

        homeScreenView.fromHomeClickAt(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_albums);
        precondition.createAlbum();
        photosAndVideosView.openAlbum();
        precondition.addPhotoToExistingAlbum();
        gridView.selectAllAlbums();
        photosAndVideosView.clickOnShareAndCopyShare(vz_strings.context_share);
        baseControlsHelper.waitForDismiss(vz_strings.toast_creatingSocialShareLink);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagEvent);
        List<String> contenttype = localyticsHelper.dynamicCount(logs, vz_strings.logs_shareContentType);
        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SHARE_SEND_CONTENT + " is not 2 in logs", localyticsHelper.isExisted(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND_CONTENT));
        for (String contentstype : contenttype) {
            if ((contentstype.contains("Video")) || (contentstype.contains("Photo"))) {
                TestCase.assertTrue("Localytics of " + vz_strings.logs_shareContentType + " photo is not 1 in logs", localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareContentType + "\" " + contentstype) == 1);
            } else
                TestCase.assertFalse("Localytics of " + vz_strings.logs_shareContentType + " not matches", true);
        }
    }
}


