package com.sncr.verizon.appiumtests.vznft.deeplinks.pushnotificaitons;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class PushNotificationBackgroundOnRealTimes extends BaseTestClass {

    private SoftAssert softAssert = new SoftAssert();

    @Test(testName = "VZNFT-284", groups = {GroupNames.PUSH_NOTIFICATIONS, "vznft"})
    public void testPushNotificationBackgroundOnRealTimes() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_stories);
        photosAndVideosView.openStory10();
        baseControlsHelper.clickOn(vz_strings.button_smartAlbumPlay);

        nativeIosAppsView.openDeeplink(vz_strings.Deeplinks.PRINTS_AND_GIFTS_CANVAS);

        baseControlsHelper.waitForShow(vz_strings.printsAndGifts_Canvas);

        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.printsAndGifts_Canvas) > 0,
                "Did not open on canvas screen");

        baseControlsHelper.clickOn(vz_strings.button_exit);
        baseControlsHelper.clickOn(vz_strings.button_yes);

        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.button_smartAlbumPlay) > 0,
                "did not return to stories view");
        softAssert.assertAll();
    }
}
