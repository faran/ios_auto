package com.sncr.verizon.appiumtests.IV.photosandvideos.flashbacks;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.HelperUtilities;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

import java.lang.invoke.MethodHandles;

import static com.sncr.verizon.appiumtests.constants.vz_serverConfigs.photoFileName;

public class FlashbacksMSContextMenu extends BaseTestClass {

    @Test(testName = "IV-2395", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.CONTEXT_MENU, GroupNames.FLASHBACKS})
    public void testFlashbacksContextMenu() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_flashbacks);
        gridView.tapItemsInMultiSelectMode(1, vz_strings.DataType.PHOTO);

        baseControlsHelper.openContext(null);
        Thread.sleep(1000);
        TestCase.assertTrue("Options missing ",
                contextualMenu.verifyOptions(vz_strings.DataType.PHOTO, vz_strings.view_Multi_Select_Flashbacks, false));
        TestCase.assertTrue("Prints & Gifts Icon is missing", baseControlsHelper.getCountByName(vz_strings.context_icon_printShop) > 0);
    }
}
