//VZNFT-212 step-1
package com.sncr.verizon.appiumtests.vznft.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;


public class CloudPrintUnsupportedMixed extends BaseTestClass {

    @Test(testName = "VZNFT-212", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI})
    public void testCloudPrintUnsupportedMixed() throws Exception {

            homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
            photosAndVideosView.selectTab(vz_strings.tab_all);
            baseControlsHelper.openContext(vz_strings.context_select);

            gridView.selectWithScroll(vz_strings.DataType.PHOTO, 1, 1);
            gridView.selectWithScroll(vz_strings.DataType.VIDEO, 1, 1);
            baseControlsHelper.clickOn(vz_strings.context_icon_printShop);

            String logs = localyticsHelper.getLogs();
            localyticsHelper.print(logs, vz_strings.logs_appError);

            TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketAppState + " is not 1",
                    localyticsHelper.getPatternMatch(logs, vz_strings.logs_photoBucketAppState + " = " + "\"" + vz_strings.logs_NotApplicable + "\"") == 1);

            TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucket_error_ErrorDescription + " is not 1",
                    localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucket_error_ErrorDescription + "\"" + " = "
                            + "\"" + vz_strings.logs_NotApplicable + "\"") == 1);

            //Using getCountOf instead of getPatternMatch because string exceeds max length
            TestCase.assertTrue("Localytics of " + vz_strings.logs_message + " is not 1",
                    localyticsHelper.getCountOf(logs, vz_strings.logs_message + " = " + "\"" + vz_strings.logs_photoBucket_error_UnsupportedContent + "\"") == 1);
    }
}
