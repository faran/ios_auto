//IV-4276 3/5
package com.sncr.verizon.appiumtests.IV.photosandvideos.flashbacks;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.HelperUtilities;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

import java.lang.invoke.MethodHandles;

import static com.sncr.verizon.appiumtests.constants.vz_serverConfigs.photoFileName;

public class CreateCollageMultiselectFB extends BaseTestClass {

    @Test(testName = "IV-4276", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.REAL, GroupNames.FLASHBACKS})
    public void testCreateCollageMultiselectFB() throws Exception {
        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_flashbacks);
        baseControlsHelper.openContext(vz_strings.context_select);
        gridView.selectWithScroll(vz_strings.DataType.PHOTO, 2, 4);
        baseControlsHelper.openContext(vz_strings.context_createcollage);
        String pageTitle = baseControlsHelper.getNameByIndexfromClassName(0, "XCUIElementTypeNavigationBar");
        TestCase.assertTrue("Create Collage view is not open", pageTitle.equals("Collage"));
    }
}
