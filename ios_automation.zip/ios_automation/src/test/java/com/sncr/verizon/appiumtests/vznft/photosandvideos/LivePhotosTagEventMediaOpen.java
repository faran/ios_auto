//https://jira.synchronoss.net:8443/jira/browse/VZNFT-334
package com.sncr.verizon.appiumtests.vznft.photosandvideos;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 17/01/19.
 */
public class LivePhotosTagEventMediaOpen extends BaseTestClass {

    @Test(testName = "VZNFT-334", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS})
    public void testLivePhotosTagEventMediaOpen() throws Exception {

            homeScreenView.fromHomeClickAt(vz_strings.name_livePhotoGrid);
            baseControlsHelper.swipe("right");

            String logs = localyticsHelper.getLogs();
            localyticsHelper.print(logs, vz_strings.logs_mediaOpen);

            TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaOpen + " does not exist",
                    localyticsHelper.getCountOf(logs, vz_strings.logs_mediaOpen) == 2);
            TestCase.assertTrue(vz_strings.logs_mediaType + " does not exist",
                    localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_mediaType + "\"" + " = " + "\"" + vz_strings.logs_mediaTypeLivePhoto + "\"") == 2);
            TestCase.assertTrue("Localytics of " + vz_strings.logs_homeScreen + " is not in logs",
                    localyticsHelper.getPatternMatch(logs, vz_strings.logs_page + " = " + "\"" + vz_strings.logs_homeScreen + "\"") == 1);
            TestCase.assertTrue("Localytics of " + vz_strings.logs_photosVideosDetail + " is not in logs",
                    localyticsHelper.getPatternMatch(logs, vz_strings.logs_page + " = " + "\"" + vz_strings.logs_photosVideosDetail + "\"") == 1);
    }
}
