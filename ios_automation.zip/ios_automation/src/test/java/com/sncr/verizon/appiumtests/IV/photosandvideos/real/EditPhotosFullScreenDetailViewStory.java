//IV-4275 step 3 - part 4/5
package com.sncr.verizon.appiumtests.IV.photosandvideos.real;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

import static com.sncr.verizon.appiumtests.constants.vz_strings.ab_btn_Edit;

public class EditPhotosFullScreenDetailViewStory extends BaseTestClass {

    @Test(testName = "IV-4275", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.REAL})
    public void testEditPhotosFullScreenDetailViewStory() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_stories);
        photosAndVideosView.openStory10();
        baseControlsHelper.waitForContent();
        gridView.tapItem(vz_strings.DataType.PHOTO);
        baseControlsHelper.clickOn(ab_btn_Edit);

        String pageTitle = baseControlsHelper.getNameByIndexfromClassName(0, "XCUIElementTypeNavigationBar");
        TestCase.assertTrue("Edit Photo view is not open", pageTitle.equals("Edit Photo"));
    }
}
