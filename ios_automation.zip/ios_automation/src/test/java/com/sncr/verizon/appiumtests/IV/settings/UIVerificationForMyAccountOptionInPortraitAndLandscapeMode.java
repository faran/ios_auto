package com.sncr.verizon.appiumtests.IV.settings;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.openqa.selenium.ScreenOrientation;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class UIVerificationForMyAccountOptionInPortraitAndLandscapeMode extends BaseTestClass {

    private SoftAssert softAssert = new SoftAssert();

    @Test(testName = "IV-4255", groups = {"release", GroupNames.SETTINGS})
    public void testUIVerificationForMyAccountOptionInPortraitAndLandscapeMode() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_settings);
        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.my_Account) > 0, "Settings page not displayed");
        softAssert.assertTrue(settingsView.isMyAccountOptionDisplayedInExpectedPlace(), "My Account option not displayed in portrait mode");
        baseControlsHelper.setOrientation(ScreenOrientation.LANDSCAPE);
        softAssert.assertTrue(settingsView.isMyAccountOptionDisplayedInExpectedPlace(), "My Account option not displayed in landscape mode");
        baseControlsHelper.clickOn(vz_strings.my_Account);
        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.complete_My_Profile) != 0, "Complete my profile not found ");
        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.delete_My_Account) != 0, "Delete my account not found ");
        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.settings_email) == 0, "Email addresses option is present");
        baseControlsHelper.clickOn(vz_strings.complete_My_Profile);
        baseControlsHelper.waitForDismiss(vz_strings.spinner);
        softAssert.assertTrue(baseControlsHelper.getCountByName(vz_strings.button_continue) != 0, "User is not navigated to web view");
        softAssert.assertAll();
    }

    @AfterMethod(alwaysRun = true)
    public void setToPortrait() {
        baseControlsHelper.setOrientation(ScreenOrientation.PORTRAIT);
    }
}
