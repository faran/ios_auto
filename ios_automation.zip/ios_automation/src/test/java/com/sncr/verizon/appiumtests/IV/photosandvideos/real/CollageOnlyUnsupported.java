//IV-4278
package com.sncr.verizon.appiumtests.IV.photosandvideos.real;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CollageOnlyUnsupported extends BaseTestClass {

    @Test(testName = "IV-4278", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.REAL})
    public void testCollageOnlyUnsupported() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);

        baseControlsHelper.openContext(vz_strings.context_select);
        gridView.selectWithScroll(vz_strings.DataType.VIDEO, 2, 5);

        baseControlsHelper.openContext(vz_strings.context_createcollage);
        baseControlsHelper.waitForShowByClassName("XCUIElementTypeAlert");

        TestCase.assertEquals("Title missing",baseControlsHelper.getTextFromAlertBox(0),
                vz_strings.text_unsupportedMediaTitle);
        TestCase.assertEquals("Message body missing", baseControlsHelper.getTextFromAlertBox(1),
                vz_strings.text_unsupportedMediaBodyNoPhoto);
    }
}
