package com.sncr.verizon.appiumtests.IV.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class PhotoBookMixedUnsupported extends BaseTestClass {

    @Test(testName = "IV-5137", groups = {GroupNames.FUJI, GroupNames.PHOTOBOOK, "release"})
    public void testPhotoBookMixedUnsupported() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        precondition.deleteAllAlbums();

        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.createAlbumByDataType(vz_strings.DataType.VIDEO, vz_strings.create_newAlbumName);
        photosAndVideosView.addItemsToExistingAlbum(vz_strings.DataType.PHOTO, 1);
        photosAndVideosView.selectTab(vz_strings.tab_albums);
        photosAndVideosView.openAlbum();

        baseControlsHelper.openContext(vz_strings.context_createPhotoBook);
        baseControlsHelper.waitForShow(vz_strings.button_gotIt);

        TestCase.assertTrue("Alert message title incorrect",
                baseControlsHelper.getTextFromAlertBox(0).equals(vz_strings.text_photobook_unsuported_mixed_title));

        TestCase.assertTrue("Alert message body incorrect",
                baseControlsHelper.getTextFromAlertBox(1).equals(vz_strings.text_photobook_unsuported_mixed_body));
    }
}
