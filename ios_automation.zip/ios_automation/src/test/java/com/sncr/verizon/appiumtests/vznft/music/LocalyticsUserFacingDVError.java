package com.sncr.verizon.appiumtests.vznft.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class LocalyticsUserFacingDVError extends BaseTestClass {

    @Test(testName = "VZNFT-214", groups = {"vznft", GroupNames.MUSIC, GroupNames.APP_ERROR})
    public void testLocalyticsUserFacingDVError() throws Exception {

        nativeIosAppsView.turnOnAirplaneModeThroughSiri();
        homeScreenView.navigateTo(vz_strings.navi_music);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_appError);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_appError + " is not 1", localyticsHelper.getPatternMatch(logs, vz_strings.logs_appError) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketAppState + " is not 1",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_photoBucketAppState + " = " + "\"" + vz_strings.logs_NotApplicable + "\"") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucket_error_ErrorDescription + " is not 1",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_photoBucket_error_ErrorDescription + "\"" + " = "
                        + "\"" + vz_strings.logs_NotApplicable + "\"") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logsExceptionDetails + " is not 1",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logsExceptionDetails + "\"" + " = " + "\"" + vz_strings.logs_NotApplicable + "\"") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logsHostDomain + " is not 1",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logsHostDomain + "\"" + " = " + "\"" + vz_strings.logs_NotApplicable + "\"") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_message + " is not 1",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_message + " = " + "\"" + vz_strings.logsCannotRefreshMusic + "\"") == 1);

    }

    @AfterMethod(alwaysRun = true)
    public void disableAirplaneMode() throws Exception {
        nativeIosAppsView.disableAirplaneMode();
    }
}
