package com.sncr.verizon.appiumtests.vznft.photosandvideos.flashbacks;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.HelperUtilities;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.driver.BaseDriver;
import junit.framework.TestCase;
import org.testng.annotations.Test;

import static com.sncr.verizon.appiumtests.constants.vz_serverConfigs.photoFileName;

/**
 * @author leletsn
 * VZNFT-218 FlashBack-HomeScreenCard
 */
public class LocalyticsFlashBackHomeScreenCard extends BaseTestClass {

    @Test(testName = "VZNFT-218", groups = {"vznft", GroupNames.HOME, GroupNames.FLASHBACKS})
    public void testVZNFT218LocalyticsFlashBackHomeScreenCard() throws Exception {

        homeScreenView.clickOnStory(vz_strings.carousel_flashbacks);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_flashBackTab);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_flashBackTab + " does not exist",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent
                        + ": " + vz_strings.logs_flashBackTab) >= 1 && localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent
                        + ": " + vz_strings.logs_flashBackTab) <= 2);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_HomeScreenCard + " is not 1 in logs", localyticsHelper.getPatternMatch(logs, vz_strings.logs_source
                + " = " + "\"" + vz_strings.logs_HomeScreenCard + "\"") == 1);
    }
}

