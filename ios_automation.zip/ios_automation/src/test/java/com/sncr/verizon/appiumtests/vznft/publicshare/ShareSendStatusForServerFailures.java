//https://jira.synchronoss.net:8443/jira/browse/VZNFT-126
package com.sncr.verizon.appiumtests.vznft.publicshare;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 11/12/18.
 */
public class ShareSendStatusForServerFailures extends BaseTestClass {

    @Test(testName = "VZNFT-126", groups = {"vznft", GroupNames.PUBLIC_SHARE})
    public void testShareSendStatusForServerFailures() throws Exception {

        photosAndVideosView.selectMultiplePhotosAndShare(5);
        nativeIosAppsView.turnOnAirplaneModeThroughSiri();

        String logs = localyticsHelper.getLogs();
        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SHARE_SEND_CONTENT + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND_CONTENT) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareContentSize + " does not exist",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_shareContentSize) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareContentType + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareContentType + "\"" + " = " + vz_strings.logs_mediaTypePhotos) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_shareItemShared + " does not exist",
                localyticsHelper.getPatternMatch(logs, "\"" + vz_strings.logs_shareItemShared + "\"" + " = " + "5") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.LOGS_SHARE_SEND + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.LOGS_SHARE_SEND + ",") == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_Storage_Failed_Status + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_Storage_Failed_Status) == 1);
    }

    @AfterMethod(alwaysRun = true)
    public void disableAirPlaneMode() throws Exception {
        nativeIosAppsView.disableAirplaneMode();
    }
    
}
