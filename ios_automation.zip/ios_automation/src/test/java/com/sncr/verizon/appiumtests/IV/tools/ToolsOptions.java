package com.sncr.verizon.appiumtests.IV.tools;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class ToolsOptions extends BaseTestClass {

    @Test(testName = "Tools Options",
            description = "Verify display of tools options ",
            groups = {"release", GroupNames.TOOLS})
    public void testToolsOptions() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_settings);
        baseControlsHelper.clickOn(vz_strings.navi_tools);

        TestCase.assertTrue("Restore Not Found",
                baseControlsHelper.getCountByName(vz_strings.tools_restore) != 0);
        TestCase.assertTrue("Sign in Not Found",
                baseControlsHelper.getCountByName(vz_strings.tools_signIn) != 0);
        TestCase.assertTrue("Merge Not Found",
                baseControlsHelper.getCountByName(vz_strings.tools_merge) != 0);
    }
}
