package com.sncr.verizon.appiumtests.IV.music;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class VerifyRemoveFromPlaylistPopUp extends BaseTestClass {

    @Test(groups = {"release", GroupNames.MUSIC})
    public void testVerifyRemoveFromPlaylistPopUp() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_music);
        musicView.selectTab(vz_strings.tab_playlists);
        precondition.addNewPL();
        precondition.addSongToEmptyPlaylist();
        musicView.openPlaylist(vz_strings.view_musicPlaylists);
        musicView.removeSongFromPlaylist();

        TestCase.assertTrue("Remove song(s)? ",
                baseControlsHelper.getCountByName("Remove song(s)?") != 0);
        TestCase.assertTrue("Are you sure ... missing",
                baseControlsHelper.getCountByName("Are you sure you want to remove the " +
                        "selected song(s) from the playlist?") != 0);

    }
}
