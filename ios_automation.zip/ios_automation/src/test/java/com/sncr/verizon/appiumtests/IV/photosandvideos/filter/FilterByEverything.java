//IV-2266
package com.sncr.verizon.appiumtests.IV.photosandvideos.filter;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.SortAndFilter;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class FilterByEverything extends BaseTestClass {

    private SoftAssert softAssert = new SoftAssert();

    @Test(testName = "IV-183", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FILTER})
    public void testFilterByEverything() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);

        photosAndVideosView.setPickWheelFilter(SortAndFilter.EVERYTHING);
        baseControlsHelper.openContext(vz_strings.context_select);

        gridView.selectWithScroll(vz_strings.DataType.PHOTO, 1, 5);
        softAssert.assertTrue(baseControlsHelper.getCountByName("1 Selected") > 0, "Photo not found");

        gridView.selectWithScroll(vz_strings.DataType.VIDEO, 1, 5);
        softAssert.assertTrue(baseControlsHelper.getCountByName("2 Selected") > 0, "video not found");

        gridView.selectWithScroll(vz_strings.DataType.STORY, 1, 5);
        softAssert.assertTrue(baseControlsHelper.getCountByName("3 Selected") > 0, "saved story not found");

        softAssert.assertAll();
    }
}
