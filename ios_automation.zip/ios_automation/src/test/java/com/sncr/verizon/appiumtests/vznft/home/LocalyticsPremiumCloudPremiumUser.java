//https://jira.synchronoss.net:8443/jira/browse/VZNFT-445
package com.sncr.verizon.appiumtests.vznft.home;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import com.sncr.verizon.appiumtests.driver.BaseDriver;
import com.sncr.verizon.appiumtests.managers.iOSManager;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by ssam0003 on 29/11/18.
 */
public class LocalyticsPremiumCloudPremiumUser extends BaseTestClass {

    @Test(testName = "VZNFT-445", groups = {"vznft", GroupNames.HOME})
    public void testLocalyticsPremiumCloudPremiumUser() throws Exception {

        iOSManager.runAppInBackground(-1);
        driver().launchApp();

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.user_Type_Premium_User);

        TestCase.assertTrue("Localytics of " + vz_strings.user_Type_Premium_User + " is not 1 in logs",
                localyticsHelper.isExisted(logs, vz_strings.user_Type_Premium_User));
    }
}
