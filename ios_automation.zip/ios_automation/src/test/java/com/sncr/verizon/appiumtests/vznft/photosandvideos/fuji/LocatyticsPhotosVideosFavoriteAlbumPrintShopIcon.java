package com.sncr.verizon.appiumtests.vznft.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.SortAndFilter;
import org.testng.annotations.Test;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.constants.vz_strings.DataType;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;

/**
 * @author leletsn
 * VZNFT-228 Localytics: tag event - Cloud Print Shop Entry - Photo Video Favorite
 */

public class LocatyticsPhotosVideosFavoriteAlbumPrintShopIcon extends BaseTestClass {
    
    @Test(testName = "VZNFT-228", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI})
    public void testVZNFT228LocatyticsPhotosVodeosFavoriteAlbumPrintShopIcon() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_albums);
        precondition.removeAllFavoritesFromAlbum();
        precondition.createFavoriteAlbum(DataType.PHOTO, SortAndFilter.PHOTOS);
        photosAndVideosView.selectFavoriteAlbum();
        photosAndVideosView.accessPrintShopFromIcon();

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_photoBucketEntry);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketEntry + " does not exist",
                localyticsHelper.isExisted(logs, vz_strings.logs_photoBucketEntry));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketEntry + " is not 1 in logs",
                localyticsHelper.getCountOf(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_photoBucketEntry) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketEntryPoint + " does not exist",
                localyticsHelper.isExisted(logs, "\"" + vz_strings.logs_photoBucketEntryPoint + "\" = \"" + vz_strings.logs_photosVideosFavorite + "\""));
        TestCase.assertTrue("Localytics of " + vz_strings.logs_photoBucketNumber + " does not exist",
                localyticsHelper.isExisted(logs, vz_strings.logs_photoBucketNumber));
    }
}
