package com.sncr.verizon.appiumtests.vznft.settings;
import com.sncr.verizon.appiumtests.constants.GroupNames;
import org.testng.annotations.Test;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;

/** 
 * @author leletsn
 */
public class LocalyticsSettingsManageStorageView extends BaseTestClass {

	@Test(groups = {"vznft", GroupNames.SETTINGS})
  public void testLocalyticsSettingsManageStorageVie() throws Exception {

	  homeScreenView.navigateTo(vz_strings.navi_settings);
	  baseControlsHelper.clickOnNameContainsAndVisibile(vz_strings.settings_manageStorage);
	  
	  String logs = localyticsHelper.getLogs();
	  localyticsHelper.print(logs, vz_strings.logs_ManageStorage);

	  TestCase.assertTrue("Localytics of " + vz_strings.settings_manageStorage+ " is not 1 in logs",
			  localyticsHelper.getCountOf(logs, vz_strings.logs_tagEvent + ": " + "Storage Upgrade Step") == 1);

      TestCase.assertTrue("Localytics of " + vz_strings.logs_settingsView
              + " is not 1 in logs", localyticsHelper.getCountOf(logs, vz_strings.logs_step
              + " = " + "\"" + vz_strings.logs_settingsView + "\"")==1);
  }
}
