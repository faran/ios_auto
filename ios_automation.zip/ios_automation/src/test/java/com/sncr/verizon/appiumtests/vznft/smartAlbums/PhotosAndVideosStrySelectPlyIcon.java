//https://jira.synchronoss.net:8443/jira/browse/VZNFT-73/step-4

package com.sncr.verizon.appiumtests.vznft.smartAlbums;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

/**
 * Created by kram0003 on 06/03/18.
 */
public class PhotosAndVideosStrySelectPlyIcon extends BaseTestClass {

    @Test(testName = "VZNFT-73", groups = {"vznft", GroupNames.SMART_ALBUMS})
    public void photosAndVideosStrySelectPlayIcon() throws Exception {

        homeScreenView.fromHomeClickAt(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_stories);
        photosAndVideosView.openStory10();
        baseControlsHelper.clickOn(vz_strings.button_smartAlbumPlay);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_tagEvent);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_realtimesLaunched + " is not 1 in logs",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_realtimesLaunched)==1);
    }
}
