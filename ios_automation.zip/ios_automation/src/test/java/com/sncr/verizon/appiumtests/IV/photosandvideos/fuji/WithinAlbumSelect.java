//https://jira.synchronoss.net:8443/jira/browse/IV-2453
package com.sncr.verizon.appiumtests.IV.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class WithinAlbumSelect extends BaseTestClass {

    @Test(testName = "IV-2453", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI})
    public void testWithinAlbumSelect() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        precondition.deleteAllAlbums();
        precondition.createAlbum();
        photosAndVideosView.openAlbum();
        precondition.addPhotoToExistingAlbum();
        photosAndVideosView.openAlbum();
        gridView.tapItemInSelectMode(vz_strings.DataType.PHOTO);
        photosAndVideosView.clickPrintsAndGift(vz_strings.context_printAndGifts, vz_strings.context_icon_printShop);
        baseControlsHelper.waitForDismiss(vz_strings.spinner);
        baseControlsHelper.clickOn(vz_strings.button_exit);
        baseControlsHelper.clickOn(vz_strings.button_yes);
        baseControlsHelper.tapOnBackButton();
        TestCase.assertTrue("Albums is not shown", baseControlsHelper.getCountByName(vz_strings.tab_albums) > 0);
    }
}
