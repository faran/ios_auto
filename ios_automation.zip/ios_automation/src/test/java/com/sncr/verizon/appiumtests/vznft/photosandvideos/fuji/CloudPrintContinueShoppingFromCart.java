//https://jira.synchronoss.net:8443/jira/browse/VZNFT-246
package com.sncr.verizon.appiumtests.vznft.photosandvideos.fuji;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class CloudPrintContinueShoppingFromCart extends BaseTestClass {

    @Test(testName = "VZNFT-246", groups = {"vznft", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.FUJI})
    public void testCloudPrintContinueShoppingFromCart() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        photosAndVideosView.removeAllProductFromCart();
        gridView.tapItemsInMultiSelectModeUniversal(1, vz_strings.DataType.PHOTO);
        photosAndVideosView.selectAllAddToCart();
        baseControlsHelper.waitForShow(vz_strings.text_cart);
        baseControlsHelper.clickOn(vz_strings.button_continue_shopping);
        baseControlsHelper.waitForShow(vz_strings.navi_printshop);

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_CloudPrint_ContinueShopping);

        TestCase.assertTrue("Localytics of Cloud Print Continue Shopping is not 1",
                localyticsHelper.getPatternMatch(logs, vz_strings.logs_tagEvent + ": " + vz_strings.logs_CloudPrint_ContinueShopping) == 1);
        //Latest Fuji SDK sends a tag which will be collected if we do not have stricter pattern
        TestCase.assertTrue("Localytics of Attribute is not 1",
                localyticsHelper.getPatternMatch(logs, "(^|[ ])" + vz_strings.LOGS_SCREEN + " = " + "\"" + vz_strings.logs_photoBucketCartPage + "\"") == 1);
    }
}
