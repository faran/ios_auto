/*IV-55 issues:
https://jira.synchronoss.net:8443/jira/browse/VPCIOS-5731
https://jira.synchronoss.net:8443/jira/browse/VPCIOS-7090
*/

package com.sncr.verizon.appiumtests.IV.home;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.openqa.selenium.ScreenOrientation;
import org.testng.annotations.Test;

public class ScrollingAndNavigation extends BaseTestClass {

    @Test(testName = "IV-55", groups = {"release", GroupNames.HOME})
    public void testScrollingAndNavigation() throws Exception {
        try {
            homeScreenView.navigateTo(vz_strings.navi_home);
            baseControlsHelper.setOrientation(ScreenOrientation.LANDSCAPE);
            baseControlsHelper.clickOn(vz_strings.navi_icon);
            baseControlsHelper.scroll(vz_strings.navi_Photosandvideos, "up");
            baseControlsHelper.clickOn(vz_strings.navi_help);
            baseControlsHelper.clickOn(vz_strings.navi_icon);
            baseControlsHelper.scroll(vz_strings.navi_Photosandvideos, "up");
            TestCase.assertTrue("Help Icon highlighted",
                    baseControlsHelper.getCountByName(vz_strings.navi_selectedItem) == 0);
            TestCase.assertTrue("Help Icon is not present",
                    baseControlsHelper.getCountByName(vz_strings.navi_help) == 1);
        }
        finally {
            baseControlsHelper.setOrientation(ScreenOrientation.PORTRAIT);
        }
    }
}
