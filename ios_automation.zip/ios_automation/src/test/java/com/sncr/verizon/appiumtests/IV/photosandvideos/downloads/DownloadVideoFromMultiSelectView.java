/**
 * IV-864
 * */
package com.sncr.verizon.appiumtests.IV.photosandvideos.downloads;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class DownloadVideoFromMultiSelectView extends BaseTestClass {

    private SoftAssert softAssert = new SoftAssert();

    @Test(testName = "IV-864", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.DOWNLOADS})
    public void testDownloadPhotoFromMultiSelectView() throws Exception {
        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        photosAndVideosView.selectTab(vz_strings.tab_all);
        baseControlsHelper.openContext(vz_strings.context_select);
        gridView.selectWithScroll(vz_strings.DataType.VIDEO, 1, 4);
        baseControlsHelper.openContext(vz_strings.context_download);

        softAssert.assertEquals("Downloading 1 of 1","Downloading 1 of 1");

        photosAndVideosView.checkDownload();
        softAssert.assertAll();
    }
}
