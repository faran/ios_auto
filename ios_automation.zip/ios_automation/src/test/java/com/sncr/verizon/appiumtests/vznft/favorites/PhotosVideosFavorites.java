//https://jira.synchronoss.net:8443/jira/browse/VZNFT-144
package com.sncr.verizon.appiumtests.vznft.favorites;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

public class PhotosVideosFavorites extends BaseTestClass {

    @Test(testName = "VZNFT-144", groups = {"vznft", GroupNames.FAVORITES})
    public void testPhotosVideosFavorites() throws Exception {

        homeScreenView.navigateTo(vz_strings.navi_Photosandvideos);
        precondition.removeAllFavoritesFromAlbum();
        photosAndVideosView.selectTab(vz_strings.tab_all);
        gridView.tapItemInSelectMode(vz_strings.DataType.PHOTO);
        baseControlsHelper.openContext(vz_strings.context_addFavorite);
        baseControlsHelper.waitForDismiss(vz_strings.toast_addtoFavorite);
        photosAndVideosView.selectFavoriteAlbum();

        String logs = localyticsHelper.getLogs();
        localyticsHelper.print(logs, vz_strings.logs_pvFavorites);

        TestCase.assertTrue("Localytics of " + vz_strings.logs_pvFavorites + " is not 1 in logs",
                localyticsHelper.getCountOf(logs, vz_strings.logs_tagScreen + ": " + vz_strings.logs_pvFavorites) == 1);
        TestCase.assertTrue("Localytics of " + vz_strings.logs_mediaGalleryOpen + " is not 1 in logs",
                localyticsHelper.isExisted(logs, vz_strings.logs_page + " = " + vz_strings.logs_album));

    }
}
