package com.sncr.verizon.appiumtests.IV.photosandvideos;

import com.sncr.verizon.appiumtests.accountdata.GalleryItemExists;
import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.accountdata.UploadsItems;
import com.sncr.verizon.appiumtests.servercalls.VZServerRequests;
import junit.framework.TestCase;
import org.testng.annotations.Test;

import java.util.ArrayList;

public class VideoExists extends GalleryItemExists implements UploadsItems {

    @Test(groups = {GroupNames.VIDEO_EXISTS, "snapshot", "release", "vznft"})
    public void testVideoExists() throws Exception {
        TestCase.assertTrue(testItemsExist());
    }

    /**
     * Check if two videos are present on the homescreen
     *
     * @return true if items are present, false otherwise
     * @throws Exception
     */
    @Override
    public boolean areItemsPresent() throws Exception {

        if (baseControlsHelper.getCountByName(vz_strings.text_photosAndVideos) == 0) {
            baseControlsHelper.swipe("up");
            Thread.sleep(2000);
        }

        return baseControlsHelper.getCountByNameLike(vz_strings.name_videoGrid) >= 2;
    }

    /**
     * upload .mov files found in resources folder
     *
     * @throws Exception
     * @see com.sncr.verizon.appiumtests.controls.BaseMediaTest#getFilesToUpload(vz_strings.DataType)
     * @see VZServerRequests#uploadFiles(vz_strings.DataType, ArrayList)
     */
    @Override
    public void uploadItems() throws Exception {
        ArrayList<String> videos = getFilesToUpload(vz_strings.DataType.VIDEO);

        if (doWsgGetTokenCall(msisdn, password)) {
            VZServerRequests vzServerRequests = new VZServerRequests();
            vzServerRequests.uploadFiles(vz_strings.DataType.VIDEO, videos);
            filesToUpload.addAll(videos);
        }
    }

}
