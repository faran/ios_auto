//IV-4275 step 3 - part 1/5
package com.sncr.verizon.appiumtests.IV.photosandvideos.real;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import junit.framework.TestCase;
import org.testng.annotations.Test;

import static com.sncr.verizon.appiumtests.constants.vz_strings.ab_btn_Edit;

public class EditPhotosFullScreenDetailViewHome extends BaseTestClass {

    @Test(testName = "IV-4275", groups = {"release", GroupNames.PHOTOS_AND_VIDEOS, GroupNames.REAL})
    public void testEditPhotosFullScreenDetailViewHome() throws Exception {

        homeScreenView.fromHomeClickOnGridCell(vz_strings.name_photoGrid);
        baseControlsHelper.clickOn(ab_btn_Edit);

        String pageTitle = baseControlsHelper.getNameByIndexfromClassName(0, "XCUIElementTypeNavigationBar");
        TestCase.assertTrue("Edit Photo view is not open", pageTitle.equals("Edit Photo"));
    }
}
