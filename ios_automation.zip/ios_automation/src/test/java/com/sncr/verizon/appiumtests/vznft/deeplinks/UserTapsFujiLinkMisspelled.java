package com.sncr.verizon.appiumtests.vznft.deeplinks;

import com.sncr.verizon.appiumtests.constants.GroupNames;
import com.sncr.verizon.appiumtests.constants.vz_strings;
import com.sncr.verizon.appiumtests.controls.BaseTestClass;
import org.junit.Assert;
import org.testng.annotations.Test;

public class UserTapsFujiLinkMisspelled extends BaseTestClass {

    @Test(testName = "VZNFT-319", groups = {"vznft", GroupNames.PUSH_NOTIFICATIONS})
    public void testUserTapsFujiLinkMisspelled() throws Exception {

        nativeIosAppsView.openDeeplink(vz_strings.Deeplinks.INVALID_LINK_FUJI);

        baseControlsHelper.waitForShow(vz_strings.text_printsAndGifts);

        Assert.assertTrue("Did not open on cloud home",
                baseControlsHelper.getCountByName(vz_strings.verizon_cloud) > 0);
    }
}
