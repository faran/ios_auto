#!/usr/bin/env bash
#Modifying plist
BASEDIR=$(dirname "$0")
FOLDER="iPhone"
VERIZON_BUNDLE_ID="com.synchronoss.vz.cloud"
if [[ ! -d ${FOLDER} ]]; then
    echo "Creating $FOLDER folder"
    mkdir ${FOLDER}
fi
ifuse -u $1 --documents ${VERIZON_BUNDLE_ID} "$FOLDER/"
cp "${BASEDIR}/modified.plist" "${FOLDER}/syncdrive-configuration.plist"